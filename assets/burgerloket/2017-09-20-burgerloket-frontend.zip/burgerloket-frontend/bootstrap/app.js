'use strict'

const path = require('path')

/*
|--------------------------------------------------------------------------
| Application Providers
|--------------------------------------------------------------------------
|
| Here we configure the providers required to run adonis application. They
| are registered only once and can be used inside any file using `use`
| keyword.
|
*/
const providers = [
  'adonis-framework/providers/ConfigProvider',
  'adonis-framework/providers/EnvProvider',
  'adonis-framework/providers/EventProvider',
  'adonis-framework/providers/HelpersProvider',
  'adonis-framework/providers/HashProvider',
  'adonis-framework/providers/MiddlewareProvider',
  'adonis-framework/providers/RequestProvider',
  'adonis-framework/providers/ResponseProvider',
  'adonis-framework/providers/RouteProvider',
  'adonis-framework/providers/ServerProvider',
  'adonis-framework/providers/SessionProvider',
  'adonis-framework/providers/StaticProvider',
  'adonis-framework/providers/ViewProvider',
  'adonis-cache/providers/CacheProvider',
  'adonis-middleware/providers/AppMiddlewareProvider',
  'adonis-websocket/providers/WsProvider',
  'adonis-scheduler/providers/SchedulerProvider',
  path.join(__dirname, '..', 'providers', 'VendorProvider'),
  path.join(__dirname, '..', 'providers', 'ApplicationProvider'),
  path.join(__dirname, '..', 'providers', 'AddonsProvider'),
  path.join(__dirname, '..', 'providers', 'AuthenticationProvider'),
  path.join(__dirname, '..', 'providers', 'AdonuxtProvider')
]

/*
|--------------------------------------------------------------------------
| Ace Providers
|--------------------------------------------------------------------------
|
| Ace providers are specific to ace, and are not registered when starting
| http server. It helps in reducing boot time.
|
*/
const aceProviders = [
  'adonis-cache/providers/CommandsProvider',
  'adonis-ace/providers/CommandProvider',
  'adonis-commands/providers/GeneratorsProvider',
  'adonis-commands/providers/HelperCommandsProvider',
  'adonis-commands/providers/ReplProvider',
  'adonis-scheduler/providers/CommandsProvider'
]

/*
|--------------------------------------------------------------------------
| Namespace Aliases
|--------------------------------------------------------------------------
|
| Each provider is registered with a long unique namespace. Here we alias
| them with a short unique name to keep our import statements short and
| sweet.
|
*/
const aliases = {
  Cache: 'Adonis/Addons/Cache',
  Command: 'Adonis/Src/Command',
  Config: 'Adonis/Src/Config',
  Env: 'Adonis/Src/Env',
  Event: 'Adonis/Src/Event',
  Factory: 'Adonis/Src/Factory',
  Hash: 'Adonis/Src/Hash',
  Helpers: 'Adonis/Src/Helpers',
  Middleware: 'Adonis/Src/Middleware',
  Route: 'Adonis/Src/Route',
  Scheduler: 'Adonis/Addons/Scheduler',
  Schema: 'Adonis/Src/Schema',
  View: 'Adonis/Src/View',
  Ws: 'Adonis/Addons/Ws'
}

/*
|--------------------------------------------------------------------------
| Ace Commands
|--------------------------------------------------------------------------
|
| Ace Commands are also are registered inside the IoC container. Here we
| register with Ace Kernel using their unique namespace.
|
*/
const commands = [
  'App/Commands/NuxtBuild',
  'Adonis/Commands/Cache:Table',
  'Adonis/Commands/Cache:Config',
  'Adonis/Commands/Repl',
  'Adonis/Commands/Make:Controller',
  'Adonis/Commands/Route:List',
  'Adonis/Commands/Make:Command',
  'Adonis/Commands/Make:Hook',
  'Adonis/Commands/Make:Middleware',
  'Adonis/Commands/Make:Listener',
  'Adonis/Commands/Key:Generate',
  'Adonis/Commands/Scheduler:Run'
]

module.exports = { providers, aceProviders, aliases, commands }
