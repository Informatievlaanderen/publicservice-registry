/* eslint-disable */
/**
* Gulp setup
*/

/**
* Project configuration
*/

// Load plugins
var gulp = require('gulp')
var autoprefixer = require('gulp-autoprefixer')
var uglify = require('gulp-uglify')
var rename = require('gulp-rename')
var concat = require('gulp-concat')
var notify = require('gulp-notify')
var sass = require('gulp-sass')
var plumber = require('gulp-plumber')
var cache = require('gulp-cache')
var sourcemaps = require('gulp-sourcemaps')
var iconfont = require('gulp-iconfont')
var iconfontCssAndTemplate = require('gulp-iconfont-css-and-template')
var stylelint = require('gulp-stylelint')
var svgstore = require('gulp-svgstore')
var svgmin = require('gulp-svgmin')
var path = require('path')

/**
* Sass
* Looking at src/sass and compiling the files into Expanded format, Autoprefixing and sending the files to the build folder
*/
gulp.task('sass', function () {
  gulp.src('./front/css/**/*.scss')
        .pipe(plumber())
        .pipe(sourcemaps.init())
        .pipe(sass({
          errLogToConsole: true,
          outputStyle: 'compact',
          precision: 10
        }))
        .pipe(autoprefixer('last 2 version', '> 1%', 'safari 6', 'ie 9', 'opera 12.1', 'ios 7', 'android 4'))
        .pipe(plumber.stop())
        .pipe(gulp.dest('./resources/assets/css'))
        .pipe(notify({ message: 'sass task complete', onLast: true }))
})

/**
* Scripts: Vendors
*
* Look at src/js and concatenate those files, send them to assets/js where we then minimize the concatenated file.
*/
gulp.task('vendorsJs', function () {
  return gulp.src(['./front/js/vendor/*.js'])
      .pipe(concat('vendors.js'))
      .pipe(gulp.dest('./resources/assets/js'))
      .pipe(rename({
        basename: 'vendors',
        suffix: '.min'
      }))
      .pipe(uglify())
      .pipe(gulp.dest('./resources/assets/js'))
      .pipe(notify({ message: 'Vendor scripts task complete', onLast: true }))
})

/**
* Scripts: Custom
*
* Look at src/js and concatenate those files, send them to assets/js where we then minimize the concatenated file.
*/
gulp.task('scriptsJs', function () {
  return gulp.src('./front/js/custom/*.js')
      .pipe(concat('custom.js'))
      .pipe(gulp.dest('./resources/assets/js'))
      .pipe(rename({
        basename: 'custom',
        suffix: '.min'
      }))
      .pipe(uglify())
      .pipe(gulp.dest('./resources/assets/js'))
      .pipe(notify({ message: 'Custom scripts task complete', onLast: true }))
})

/**
* Generate SVG sprite
*
* Gulp task to generate an SVG sprite by the input of svg files
*/
gulp.task('svgstore', function () {
  return gulp
    .src('./front/icons/*.svg')
    .pipe(svgmin(function (file) {
      var prefix = path.basename(file.relative, path.extname(file.relative))
      return {
        plugins: [{
          cleanupIDs: {
            prefix: prefix + '-',
            minify: true
          }
        }]
      }
    }))
    .pipe(svgstore())
    .pipe(gulp.dest('./resources/static/svg'))
})

gulp.task('lintCss', function lintCssTask() {
  return gulp
    .src('./front/css/**/*.scss')
    .pipe(stylelint({
      reporters: [
        {formatter: 'string', console: true}
      ]
    }))
})

/**
* Clean gulp cache
*/
gulp.task('clear', function () {
  cache.clearAll()
})

// Watch Task
gulp.task('default', ['sass', 'vendorsJs', 'scriptsJs'], function () {
  gulp.watch('./front/css/**/*.scss', ['sass'])
  gulp.watch('./front/js/**/*.js', ['scriptsJs'])
})
