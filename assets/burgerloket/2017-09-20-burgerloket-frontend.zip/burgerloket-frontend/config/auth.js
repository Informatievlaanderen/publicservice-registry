'use strict'

const Env = use('Env')

module.exports = {

  /*
  |--------------------------------------------------------------------------
  | Administrator Users
  |--------------------------------------------------------------------------
  |
  | Define a list of tokens which grant users administrator priviledges.
  |
  */
  adminUsers: JSON.parse(Env.get('AUTH_ADMIN_USERS', '[]')),

  /*
  |--------------------------------------------------------------------------
  | Request Timeout
  |--------------------------------------------------------------------------
  |
  | This option controls the maximum amount of minutes a SAML request ID
  | should be available until auto invalidated.
  |
  */
  requestTimeout: parseInt(Env.get('AUTH_REQUEST_TIMEOUT', '60')),

  /*
  |--------------------------------------------------------------------------
  | Service Provider Configuration
  |--------------------------------------------------------------------------
  |
  | This option contains the service provider configuration which is used
  | for SSO functionality of the application. The certificates may contains
  | a filepath or the content of a certificate.
  |
  */
  serviceProviderConfig: Env.get('AUTH_SP_CONFIG'),

  /*
  |--------------------------------------------------------------------------
  | Identity Provider Configuration
  |--------------------------------------------------------------------------
  |
  | This option contains the identity provider configuration which is used
  | for SSO functionality of the application.
  |
  */
  identityProviderConfig: Env.get('AUTH_IDP_CONFIG')

}
