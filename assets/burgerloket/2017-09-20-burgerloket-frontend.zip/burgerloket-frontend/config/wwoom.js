'use strict'

const Env = use('Env')

module.exports = {

  /**
   * Protocol which should be used during communication with the
   * Dosis API.
   */
  protocol: Env.get('WWOOM_PROTOCOL'),

  /**
   * Domain which should be used during communication with the
   * Dosis API.
   */
  domain: Env.get('WWOOM_DOMAIN')

}
