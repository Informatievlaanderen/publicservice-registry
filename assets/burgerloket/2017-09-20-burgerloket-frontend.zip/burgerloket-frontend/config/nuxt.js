'use strict'

const resolve = require('path').resolve
const ExtractTextPlugin = require('extract-text-webpack-plugin')

module.exports = {
  /*
  ** Headers of the page
  */
  head: {
    title: 'Burgerloket - Vlaanderen.be',
    htmlAttrs: {
      lang: 'nl-BE'
    },
    meta: [
      {
        charset: 'utf-8'
      },
      {
        name: 'viewport',
        content: 'width=device-width, initial-scale=1'
      },
      {
        name: 'description',
        content: 'Burgerloket - Vlaanderen.be'
      },
      {
        name: 'theme-color',
        content: '#FFE615'
      }
    ],
    link: [
      {
        rel: 'icon',
        type: 'image/x-icon',
        href: 'favicon.ico'
      },
      {
        rel: 'stylesheet',
        href: 'https://dij151upo6vad.cloudfront.net/2.latest/css/vlaanderen-ui.css'
      },
      {
        rel: 'stylesheet',
        href: 'https://dij151upo6vad.cloudfront.net/2.latest/css/vlaanderen-ui-corporate.css'
      }
    ],
    script: [
      {
        type: 'text/javascript',
        src: 'https://dij151upo6vad.cloudfront.net/2.latest/js/vlaanderen-ui.js',
        defer: 'defer'
      }
    ]
  },
  /*
  ** Global CSS
  */
  css: [
    '~assets/css/burgerloket.css'
  ],
  loading: false,
  srcDir: resolve(__dirname, '..', 'resources'),
  store: true,
  offline: false,
  build: {
    // analyze: true,
    rules: [
      {
        test: /\.vue$/,
        loader: 'vue-loader',
        options: {
          loaders: {
            sass: ExtractTextPlugin.extract({
              use: 'css-loader!sass-loader?indentedSyntax',
              fallback: 'vue-style-loader'
            }),
            i18n: '@kazupon/vue-i18n-loader'
          }
        }
      }
    ],
    vendor: [
      'babel-polyfill',
      'axios',
      'moment',
      'vue-clickaway',
      '~plugins/i18n.js'
    ],
    extend (config) {
      const vueLoader = config.module.rules.find((rule) => rule.loader === 'vue-loader')
      vueLoader.query.loaders.scss = 'vue-style-loader!css-loader!sass-loader?' + JSON.stringify({
        data: `@import '~assets/css/global.scss';`
      })
    }
  },
  router: {
    middleware: []
  },
  plugins: [
    { src: '~plugins/i18n', injectAs: 'i18n' },
    '~plugins/bl-components',
    '~plugins/date'
  ]
}
