'use strict'

const Env = use('Env')

module.exports = {

  dosis: {
    batchSize: parseInt(Env.get('DOSIS_BATCH_SIZE')) || 0,
    protocol: Env.get('DOSIS_PROTOCOL'),
    domain: Env.get('DOSIS_DOMAIN'),
    port: parseInt(Env.get('DOSIS_PORT')) || 0,
    basePath: Env.get('DOSIS_BASE_PATH'),
    cacheExpire: parseInt(Env.get('DOSIS_CACHE_EXPIRE')) || 0
  },

  profile: {
    protocol: Env.get('PROFILE_PROTOCOL'),
    domain: Env.get('PROFILE_DOMAIN'),
    port: parseInt(Env.get('PROFILE_PORT')) || 0,
    basePath: Env.get('PROFILE_BASE_PATH'),
    cacheExpire: parseInt(Env.get('PROFILE_CACHE_EXPIRE')) || 0
  },

  education: {
    protocol: Env.get('EDUCATION_PROTOCOL'),
    domain: Env.get('EDUCATION_DOMAIN'),
    port: parseInt(Env.get('EDUCATION_PORT')) || 0,
    basePath: Env.get('EDUCATION_BASE_PATH'),
    cacheExpire: parseInt(Env.get('EDUCATION_CACHE_EXPIRE')) || 0
  },

  notification: {
    protocol: Env.get('NOTIFICATION_PROTOCOL'),
    domain: Env.get('NOTIFICATION_DOMAIN'),
    port: parseInt(Env.get('NOTIFICATION_PORT')) || 0,
    basePath: Env.get('NOTIFICATION_BASE_PATH'),
    cacheExpire: parseInt(Env.get('NOTIFICATION_CACHE_EXPIRE')) || 0
  },

  audit: {
    protocol: Env.get('AUDIT_PROTOCOL'),
    domain: Env.get('AUDIT_DOMAIN'),
    port: parseInt(Env.get('AUDIT_PORT')) || 0,
    basePath: Env.get('AUDIT_BASE_PATH'),
    cacheExpire: parseInt(Env.get('AUDIT_CACHE_EXPIRE')) || 0
  },

  person: {
    protocol: Env.get('PERSON_PROTOCOL'),
    domain: Env.get('PERSON_DOMAIN'),
    port: parseInt(Env.get('PERSON_PORT')) || 0,
    basePath: Env.get('PERSON_BASE_PATH'),
    cacheExpire: parseInt(Env.get('PERSON_CACHE_EXPIRE')) || 0,
    warnMonthsUntilExpires: parseInt(Env.get('PERSON_ID_EXPIRE_WARN_MONTHS')) || 0
  },

  accommodation: {
    protocol: Env.get('ACCOMMODATION_PROTOCOL'),
    domain: Env.get('ACCOMMODATION_DOMAIN'),
    port: parseInt(Env.get('ACCOMMODATION_PORT')) || 0,
    basePath: Env.get('ACCOMMODATION_BASE_PATH'),
    cacheExpire: parseInt(Env.get('ACCOMMODATION_CACHE_EXPIRE')) || 0
  },

  tax: {
    protocol: Env.get('TAX_PROTOCOL'),
    domain: Env.get('TAX_DOMAIN'),
    port: parseInt(Env.get('TAX_PORT')) || 0,
    basePath: Env.get('TAX_BASE_PATH'),
    cacheExpire: parseInt(Env.get('TAX_CACHE_EXPIRE')) || 0
  }

}
