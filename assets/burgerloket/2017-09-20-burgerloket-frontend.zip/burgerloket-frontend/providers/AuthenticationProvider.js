'use strict'

const ServiceProvider = require('adonis-fold').ServiceProvider

/**
 * Service provider which provides authentication functionality.
 */
class AuthenticationProvider extends ServiceProvider {

  /**
   * {@inheritdoc}
   */
  * register () {
    // Bind "App/Auth/AuthManager" to our auth manager defintion.
    this.app.bind('App/Auth/AuthManager', () => require('../app/Auth/AuthManager'))
    this.app.singleton('App/Auth/IdentityProviderStore', () => require('../app/Auth/IdentityProviderStore'))
  }

}

module.exports = AuthenticationProvider
