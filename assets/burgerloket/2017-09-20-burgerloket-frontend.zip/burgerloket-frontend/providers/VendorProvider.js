'use strict'

const ServiceProvider = require('adonis-fold').ServiceProvider

/**
 * Service provider which exposes third party modules using the DI container.
 */
class VendorProvider extends ServiceProvider {

  /**
   * {@inheritdoc}
   */
  * register () {
    // Bind "Exceptions" to the "node-exceptions" module.
    this.app.bind('Exceptions', () => require('node-exceptions'))
    // Bind "httpClient" to the "axios" module.
    this.app.bind('HttpClient', () => require('axios'))
    // Bind "QueryString" to the "querystring" module.
    this.app.bind('QueryString', () => require('querystring'))
    // Bind "HashObject" to the "hash-object" module.
    this.app.bind('HashObject', () => require('hash-object'))
  }

}

module.exports = VendorProvider
