'use strict'

const ServiceProvider = require('adonis-fold').ServiceProvider

/**
 * Service provider which provides application related services.
 */
class ApplicationProvider extends ServiceProvider {

  /**
   * {@inheritdoc}
   */
  * register () {
    // Bind "AppLog" to a custom CatLog instance.
    this.app.bind('AppLog', () => {
      // Get the CatLog library.
      const CatLog = require('cat-log')
      // Create a CatLog instance with given name.
      return new CatLog('burgerloket-frontend')
    })
  }

}

module.exports = ApplicationProvider
