'use strict'

const ServiceProvider = require('adonis-fold').ServiceProvider

/**
 * Service provider which provides access to the Addons that
 * cannot use the dependency injection.
 */
class AddonsProvider extends ServiceProvider {

  /**
   * {@inheritdoc}
   */
  * register () {
    // Register the addon "SAML".
    this.app.bind('App/Addons/SAML', () => require('../app/Addons/SAML'))
  }

}

module.exports = AddonsProvider
