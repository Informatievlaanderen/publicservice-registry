'use strict'

const ServiceProvider = require('adonis-fold').ServiceProvider

/**
 * Service provider which provides authentication functionality.
 */
class AdonuxtProvider extends ServiceProvider { }

module.exports = AdonuxtProvider
