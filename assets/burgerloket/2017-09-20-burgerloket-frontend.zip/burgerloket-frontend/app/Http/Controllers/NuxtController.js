'use strict'

const Env = use('Env')
const Config = use('Config')
const Nuxt = require('nuxt')

class NuxtController {

  constructor () {
    // Get the nuxt configuration.
    let config = Config.get('nuxt')
    // Determine whether we should run in development mode.
    config.dev = Env.get('NODE_ENV') === 'development'
    // Create a Nuxt instance using specified configuration.
    this.nuxt = new Nuxt(config)
    // Check whether development mode is active.
    if (config.dev) {
      // Build the application at runtime.
      this.nuxt.build()
    }
  }

  * render (request, response) {
    // Perform default nuxt server side redering.
    this.nuxt.render(request.request, response.response)
  }
}

module.exports = new NuxtController()
