'use strict'

/**
 * Abstract definition of a service controller.
 */
class AbstractServiceController {

  /**
   * Create an AbstractServiceController object.
   *
   * @param {AbstractService} service
   *   An instance of AbstractService.
   */
  constructor (service) {
    // Setup object members.
    this._service = service
  }

  /**
   * Get the controller service.
   *
   * @returns {AbstractService}
   *   An instance of AbstractService.
   */
  get service () { return this._service }

}

module.exports = AbstractServiceController
