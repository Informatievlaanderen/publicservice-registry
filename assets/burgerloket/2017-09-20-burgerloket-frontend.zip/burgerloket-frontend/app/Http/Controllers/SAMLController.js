'use strict'

/**
 * Controller which performs SAML request/response handling.
 */
class SAMLController {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['App/Auth/ServiceProvider']
  }

  /**
   * Create a SAMLController object.
   *
   * @param {ServiceProvider} serviceProvider
   *   An instance of ServiceProvider.
   */
  constructor (serviceProvider) {
    // Setup object members.
    this._sp = serviceProvider
  }

  * authenticate (request, response, samlAttributes) {
    // Initialize variable to an empty object. This will hold the converted
    // SAML attributes into key/value pairs.
    var attributes = { };
    // Iterate through the SAML attributes.
    (samlAttributes || []).forEach((attribute) => {
      // Assign the attribute name/value to the object.
      attributes[attribute.name] = attribute.value
    })

    // Validate the user attributes, they should include the following
    // attributes:
    //  * urn:be:vlaanderen:acm:rrn
    //  * urn:be:vlaanderen:acm:voornaam
    //  * urn:be:vlaanderen:acm:familienaam
    if (attributes['urn:be:vlaanderen:acm:rrn'] === undefined ||
        attributes['urn:be:vlaanderen:acm:voornaam'] === undefined ||
        attributes['urn:be:vlaanderen:acm:familienaam'] === undefined) {
      // Raise error due to missing SAML attributes.
      throw new Error('Authentication failed due to missing required SAML attributes')
    }

    // Login the user using the information provided with given attributes:
    yield request.auth.login({
      token: attributes['urn:be:vlaanderen:acm:rrn'],
      firstName: attributes['urn:be:vlaanderen:acm:voornaam'],
      lastName: attributes['urn:be:vlaanderen:acm:familienaam']
    })

    // @todo Remove this once test page is no longer required.
    response.redirect('/login')
  }

  * login (request, response) {
    // Get the Identity Provider entity ID from the query parameter.
    const entityID = request.param('idp', null)
    // Create the SAML authentication request.
    const samlAuthRequest = yield this._sp.produceAuthnRequest(entityID)
    // Check whether the a POST binding is should be performed.
    if (samlAuthRequest.method === 'POST') {
      // Raise error due to unsupported SAML protocol binding.
      throw new Error('SAML POST Binding is currently not supported')
    }
    // Redirect the client to the SSO login page.
    response.redirect(samlAuthRequest.url.href + '?' + use('QueryString').stringify(samlAuthRequest.url.query))
  }

  * consumer (request, response) {
    // Initialize the result variable to null as default behavior.
    let result = null
    // Check whether a 'POST' request was performed.
    if (request.method() === 'POST') {
      // Consume SAML response using form data.
      result = yield this._sp.consumePostResponse(request.all())
    } else {
      // Consume SAML response using query params.
      result = yield this._sp.consumeRedirectResponse(request.params())
    }
    // Authenticate the user with given attributes.
    yield this.authenticate(request, response, result.attributes || [])
  }

  * logout (request, response) {
    // Logout the current user session.
    yield request.auth.logout()
    // Redirect to the front page.
    response.redirect('/')
  }

  * metadata (request, response) {
    // Get the service provider metadata.
    const metadata = yield this._sp.produceSPMetadata()
    // Send the Service Provider metadata.
    response
      .header('Content-Type', 'text/xml')
      .send(metadata)
  }

}

module.exports = SAMLController
