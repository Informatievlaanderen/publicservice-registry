'use strict'

class SessionController {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['Config']
  }

  /**
   * Create a SessionController object.
   *
   * @param {Config} config
   *   The application runtime configuration.
   */
  constructor (config) {
    // Setup object members.
    this._config = config
  }

  * login (request, response) {
    // Get the redirect path.
    const redirectPath = request.input('redirectPath')
    // Validate the redirectPath argument.
    if (redirectPath === undefined || redirectPath === null) {
      // Raise error due to invalid or missing redirectPath argument.
      throw new Error('Invalid or missing redirectPath argument')
    }

    // Get the simulated user is available.
    const simulatedUser = this._config.get('session.simulate')
    // Check whether the user session should be simulated.
    if (simulatedUser !== null) {
      // Login with simulated user information.
      yield request.auth.login(simulatedUser)
    }

    // Determine whether an authenticated user session is available.
    const authenticated = yield request.auth.isAuthenticated()
    // Check whether an authenticated user session is available.
    if (authenticated) {
      return response.json({
        type: 'session',
        user: yield request.auth.getUser(),
        redirectUrl: '/login' // @todo Replace with redirect path.
      })
    }

    // Assign the redirectPath to the current session.
    yield request.session.put('session/redirectPath', redirectPath)
    // Redirect the user to the SAML Login service.
    return response.json({
      type: 'externalRedirect',
      redirectUrl: '/saml/services/login'
    })
  }

  * logout (request, response) {
    //
    // @todo Should we notify ACM to perform a global logout?
    //
    // Logout the current user session.
    yield request.auth.logout()
    // Respond with the given session information.
    return response.json({
      type: 'session',
      profile: yield request.auth.getUser()
    })
  }

  /**
   * @todo This should be removed from production version!
   */
  * switchToken (request, response) {
    // Get the token from the request input.
    const token = request.input('token')
    // Check whether token is available.
    if (token === undefined || token === null) {
      // Raise error due to missing token.
      throw new Error('Invalid or missing token')
    }

    // Get the current user session.
    const user = yield request.auth.getUser()
    // Check whether no user session is available.
    if (user === null) {
      // Raise error due to missing user session.
      throw new Error('No authenticated user session available')
    }

    // Overwrite the user token with the submitted token.
    user.token = token
    // Ensure the modified user object is applied.
    yield request.auth.login(user)

    // Get the redirect path.
    // const redirectPath = yield request.session.pull('session/redirectPath')
    // Redirect to the original destination or fallback to root directory.
    // @todo Should be configuration or helper.
    return response.redirect('/meest-recent')
  }

}

module.exports = SessionController
