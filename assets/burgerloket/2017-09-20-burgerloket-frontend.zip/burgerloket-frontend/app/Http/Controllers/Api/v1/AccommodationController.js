'use strict'

const AbstractServiceController = require('../../AbstractServiceController')

/**
 * Controller which provides access to accommodation data.
 */
class AccommodationController extends AbstractServiceController {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['App/Service/AccommodationService']
  }

  /**
   * Route callback: Retrieves the accommodation test cases.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * testCases (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }

    try {
      // Get a list of test case groups.
      obj.result = yield this.service.getTestCases().exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    // Send the resolved test case groups.
    return response.json(obj)
  }

  /**
   * Route callback: Retrieves the residence data.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * residence (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    const user = yield request.auth.getUser()
    const token = user.token

    try {
      // Get the user residence for given token.
      obj.result = yield this.service.getResidence(token).exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    // Send the resolved files to the client.
    return response.json(obj)
  }

  /**
   * Route callback: Retrieves the property data.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * property (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    const user = yield request.auth.getUser()
    const token = user.token

    try {
      // Get the user residence for given token.
      obj.result = yield this.service.getProperty(token).exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    // Send the resolved files to the client.
    return response.json(obj)
  }

}

module.exports = AccommodationController
