'use strict'

const AbstractServiceController = require('../../AbstractServiceController')

/**
 * Controller which provides access to photos.
 */
class PhotoController extends AbstractServiceController {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['App/Service/PersonService']
  }

  /**
   * Route callback: Retrieves the passport photo.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * passport (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    const user = yield request.auth.getUser()
    const token = user.token

    try {
      // Get the user passport photo for given token.
      obj.result = yield this.service.getPassportPhoto(token).exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    return response.json(obj)
  }

  /**
   * Route callback: Retrieves the profile photo.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * profile (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    const user = yield request.auth.getUser()
    const token = user.token

    try {
      // Get the user profile photo for given token.
      obj.result = yield this.service.getProfilePhoto(token).exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    return response.json(obj)
  }

  /**
   * Route callback: Updates the profile photo.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * updateProfile (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    const user = yield request.auth.getUser()
    const token = user.token

    try {
      // Get the submitted request data.
      const resource = request.only('content', 'reference')
      // Set the user profile photo for given token.
      yield this.service.setProfilePhoto(token, resource).exec()
      // Get the resulting user profile photo for given token.
      obj.result = yield this.service.getProfilePhoto(token).exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    return response.json(obj)
  }

  /**
   * Route callback: Removes the profile photo.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * removeProfile (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    const user = yield request.auth.getUser()
    const token = user.token

    try {
      // Get the user profile photo for given token.
      obj.result = yield this.service.unsetProfilePhoto(token).exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    return response.json(obj)
  }

}

module.exports = PhotoController
