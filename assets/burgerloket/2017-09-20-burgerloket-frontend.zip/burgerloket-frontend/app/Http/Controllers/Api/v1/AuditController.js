'use strict'

const AbstractServiceController = require('../../AbstractServiceController')

/**
 * Controller which provides access to audit data.
 */
class AuditController extends AbstractServiceController {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['App/Service/AuditService']
  }

  /**
   * Route callback: Retrieves the audit test cases.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * testCases (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }

    try {
      // Get a list of test case groups.
      obj.result = yield this.service.getTestCases().exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    // Send the resolved test case groups.
    return response.json(obj)
  }

  /**
   * Route callback: Retrieves the audit extractions.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * extractions (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    // Get the current user.
    const user = yield request.auth.getUser()

    try {
      // Get the user profile for given token.
      obj.result = yield this.service.getAuditData(user.token).exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    // Send the resolved files to the client.
    return response.json(obj)
  }

  /**
   * Route callback: Retrieves the dashboard status for audit icon.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * dashboardStatus (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    // Get the current user.
    const user = yield request.auth.getUser()

    try {
      // Get the dashboard status for given user session.
      obj.result = yield this.service.getDashboardStatus(user.token).exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    return response.json(obj)
  }

}

module.exports = AuditController
