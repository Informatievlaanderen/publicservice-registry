'use strict'

const AbstractServiceController = require('../../AbstractServiceController')

/**
 * Controller which provides access to the Dosis Service.
 */
class DosisController extends AbstractServiceController {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['App/Service/DosisService']
  }

  /**
   * Route callback: Retrieves the Dosis files using the underlying service.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * files (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    // Get the current user.
    const user = yield request.auth.getUser()

    try {
      // Get a list of files for given user session.
      obj.result = yield this.service.getFiles(user.token, 'nl').exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    // Send the resolved files to the client.
    return response.json(obj)
  }

}

module.exports = DosisController
