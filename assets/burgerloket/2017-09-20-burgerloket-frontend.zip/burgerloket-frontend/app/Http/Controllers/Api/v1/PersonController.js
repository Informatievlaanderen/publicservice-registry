'use strict'

const AbstractServiceController = require('../../AbstractServiceController')

/**
 * Controller which provides access to person data.
 */
class PersonController extends AbstractServiceController {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['App/Service/PersonService']
  }

  /**
   * Route callback: Retrieves the person test cases.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * testCases (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }

    try {
      // Get a list of test case groups.
      obj.result = yield this.service.getTestCases().exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    // Send the resolved test case groups.
    return response.json(obj)
  }

  /**
   * Route callback: Retrieves the personal particulars.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * particulars (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    const user = yield request.auth.getUser()
    const token = user.token

    try {
      // Get the user particulars for given token.
      obj.result = yield this.service.getParticulars(token).exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    // Send the resolved files to the client.
    return response.json(obj)
  }

  /**
   * Route callback: Retrieves the descent.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * descent (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    const user = yield request.auth.getUser()
    const token = user.token

    try {
      // Get the user descent for given token.
      obj.result = yield this.service.getDescent(token).exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    // Send the resolved files to the client.
    return response.json(obj)
  }

  /**
   * Route callback: Retrieves the family.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * family (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    const user = yield request.auth.getUser()
    const token = user.token

    try {
      // Get the user family for given token.
      obj.result = yield this.service.getFamily(token).exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    // Send the resolved files to the client.
    return response.json(obj)
  }

}

module.exports = PersonController
