'use strict'

const AbstractServiceController = require('../../AbstractServiceController')

/**
 * Controller which provides access to the Education Service.
 */
class EducationController extends AbstractServiceController {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['App/Service/EducationService']
  }

  * testCases (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }

    try {
      // Get a list of test case groups.
      obj.result = yield this.service.getTestCases().exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    // Send the resolved test case groups.
    return response.json(obj)
  }

  * events (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    // Get the current user.
    const user = yield request.auth.getUser()

    try {
      // Get a list of education events for given user session.
      obj.result = yield this.service.getEvents(user.token).exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    // Send the resolved education events.
    return response.json(obj)
  }

  * dashboardStatus (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    // Get the current user.
    const user = yield request.auth.getUser()

    try {
      // Get the dashboard status for given user session.
      obj.result = yield this.service.getDashboardStatus(user.token).exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    return response.json(obj)
  }

}

module.exports = EducationController
