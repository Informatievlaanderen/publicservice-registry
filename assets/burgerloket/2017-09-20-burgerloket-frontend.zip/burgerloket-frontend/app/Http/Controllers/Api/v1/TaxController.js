'use strict'

const AbstractServiceController = require('../../AbstractServiceController')

/**
 * Controller which provides access to tax/benefits data.
 */
class TaxController extends AbstractServiceController {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['App/Service/TaxService']
  }

  /**
   * Route callback: Retrieves the tax test cases.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * testCases (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }

    try {
      // Get a list of test case groups.
      obj.result = yield this.service.getTestCases().exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    // Send the resolved test case groups.
    return response.json(obj)
  }

  /**
   * Route callback: Retrieves the work assistance benefits.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * assistance (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    // Get the current user.
    const user = yield request.auth.getUser()
    const token = user.token

    try {
      // Get the user profile for given token.
      obj.result = yield this.service.getAssistance(token).exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    // Send the resolved files to the client.
    return response.json(obj)
  }

  /**
   * Route callback: Retrieves the career breaks.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * careerBreaks (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    // Get the current user.
    const user = yield request.auth.getUser()
    const token = user.token

    try {
      // Get the user profile for given token.
      obj.result = yield this.service.getCareerBreaks(token).exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    // Send the resolved files to the client.
    return response.json(obj)
  }

}

module.exports = TaxController
