'use strict'

const AbstractServiceController = require('../../AbstractServiceController')

/**
 * Controller which provides access to the Notification Service.
 */
class NotificationController extends AbstractServiceController {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['App/Service/NotificationService']
  }

  /**
   * Route callback: Retrieves the notifications using the underlying service.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * list (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    // Get the current user.
    const user = yield request.auth.getUser()

    try {
      // Get a list of notifications for given user session.
      obj.result = yield this.service.getNotifications(user.token).exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    // Send the resolved files to the client.
    return response.json(obj)
  }

  /**
   * Route callback: Mark a notification as marked using the underlying service.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * markAsRead (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    // Get the current user.
    const user = yield request.auth.getUser()

    try {
      // Get the request parameters.
      const params = request.all()
      // Mark the notification for given user and notification ID.
      obj.result = yield this.service.markNotificationAsRead(user.token, params.id || '').exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    // Send the updated notifications.
    return response.json(obj)
  }

}

module.exports = NotificationController
