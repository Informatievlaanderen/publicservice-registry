'use strict'

const AbstractServiceController = require('../../AbstractServiceController')

/**
 * Controller which provides access to profile information.
 */
class ProfileController extends AbstractServiceController {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['App/Service/ProfileService']
  }

  /**
   * Route callback: Retrieves the profile information.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * get (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    // Get the current user.
    const user = yield request.auth.getUser()

    try {
      // Get the user profile for given token.
      obj.result = yield this.service.createOrGetProfile(user.token, user)
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    // Send the resolved files to the client.
    return response.json(obj)
  }

  /**
   * Route callback: Update the profile information.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * update (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    // Get the current user.
    const user = yield request.auth.getUser()

    try {
      // Get the submitted request data.
      let profile = request.all()
      // Overwrite the firstName and lastName properties.
      profile.firstName = user.firstName
      profile.lastName = user.lastName

      // Update the user profile.
      obj.result = yield this.service.updateProfile(user.token, profile).exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    // Send the resolved files to the client.
    return response.json(obj)
  }

  /**
   * Route callback: Delete the profile information.
   *
   * @param {Request} request
   *   An object which represents the request.
   * @param {Response} response
   *   An object which represents the response.
   */
  * delete (request, response) {
    // Build the response object.
    const obj = { success: false, result: null }
    // Get the current user.
    const user = yield request.auth.getUser()

    try {
      // Update the user profile.
      obj.result = yield this.service.deleteProfile(user.token).exec()
      // Set the success flag.
      obj.success = true
    } catch (error) {
      // Use the error message as result.
      obj.result = error.message
      // Clear the success flag.
      obj.success = false
    }

    // Send the resolved files to the client.
    return response.json(obj)
  }

}

module.exports = ProfileController
