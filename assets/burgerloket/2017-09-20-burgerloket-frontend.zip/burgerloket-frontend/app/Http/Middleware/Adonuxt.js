'use strict'

/**
 * Middleware which exposes the Adonis framework through Nuxt requests.
 */
class Adonuxt {

  /**
   * {@inheritdoc}
   */
  * handle (request, response, next) {
    // Attach the Adonis components.
    yield this._attachAdonisComponents(request)

    yield next
  }

  /**
   * {@inheritdoc}
   */
  * handlews (socket, request, next) {
    // Attach the Adonis components.
    yield this._attachAdonisComponents(request)

    yield next
  }

  /**
   * Attach the Adonis framework.
   */
  * _attachAdonisComponents (request) {
    // Expose the Adonis Fold component (IoC/DI).
    request.request.app = { use, make }
  }

}

module.exports = Adonuxt
