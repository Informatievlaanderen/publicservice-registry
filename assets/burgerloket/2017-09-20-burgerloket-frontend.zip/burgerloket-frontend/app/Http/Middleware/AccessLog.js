'use strict'

/**
 * @todo Remove this once application is done
 */
class AccessLog {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['AppLog']
  }

  /**
   * Create an AccessLog instance.
   *
   * @param {CatLog} log
   *   An instance of CatLog.
   */
  constructor (log) {
    // Setup object members.
    this._log = log
  }

  /**
   * {@inheritdoc}
   */
  * handle (request, response, next) {
    this._log.info('[' + request.method() + '] ' + request.url())

    yield next
  }

  /**
   * {@inheritdoc}
   */
  * handlews (socket, request, next) {
    this._log.info(request.url())

    yield next
  }

}

module.exports = AccessLog
