'use strict'

/**
 * Middleware which provides the initial authentication setup.
 */
class AuthInit {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['Cache', 'Config']
  }

  /**
   * Create an AuthInit object.
   *
   * @param {Cache} cache
   *   The application cache layer.
   * @param {Config} config
   *   The application configuration.
   * @param {Function} AuthManager
   *   The AuthManager class definition.
   */
  constructor (cache, config, AuthManager) {
    // Setup object members.
    this._cache = cache
    this._config = config
  }

  /**
   * {@inheritdoc}
   */
  * handle (request, response, next) {
    // Attach the manager to the given request.
    yield this._attachManager(request)

    yield next
  }

  /**
   * {@inheritdoc}
   */
  * handlews (socket, request, next) {
    // Attach the manager to the given request.
    yield this._attachManager(request)

    yield next
  }

  /**
   * Attach the AuthManager.
   *
   * @param {Request} request
   *   An object which represents the request.
   */
  * _attachManager (request) {
    // Get the auth manager class definition.
    const AuthManager = use('App/Auth/AuthManager')
    // Attach the authentication manager to the request objects.
    request.auth = request.request.auth = new AuthManager(this._cache, this._config, request)
  }

}

module.exports = AuthInit
