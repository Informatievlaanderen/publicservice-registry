'use strict'

const NE = require('node-exceptions')

class Auth {

  /**
   * {@inheritdoc}
   */
  * handle (request, response, next) {
    // Determine whether current user session is authenticated.
    const authenticated = yield request.auth.isAuthenticated()
    // Check whether the current user session is authenticated.
    if (!authenticated) {
      // Raise Http exception due to unauthenicated state.
      throw new NE.HttpException('Forbidden', 403)
    }

    yield next
  }

  /**
   * {@inheritdoc}
   */
  * handlews (socket, request, next) {
    // Determine whether current user session is authenticated.
    const authenticated = yield request.auth.isAuthenticated()
    // Check whether the current user session is authenticated.
    if (!authenticated) {
      // Raise Http exception due to unauthenicated state.
      throw new NE.HttpException('Forbidden', 403)
    }

    yield next
  }

}

module.exports = Auth
