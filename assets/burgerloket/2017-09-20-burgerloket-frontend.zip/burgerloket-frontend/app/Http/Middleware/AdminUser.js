'use strict'

const NE = require('node-exceptions')

class AdminUser {

  /**
   * {@inheritdoc}
   */
  * handle (request, response, next) {
    // Determine whether current user session has administrator priviledges.
    const isAdminUser = yield request.auth.isAdmin()
    // Check whether the current user session has administrator priviledges.
    if (!isAdminUser) {
      // Raise Http exception due to unauthenicated state.
      throw new NE.HttpException('Forbidden', 403)
    }

    yield next
  }

  /**
   * {@inheritdoc}
   */
  * handlews (socket, request, next) {
    // Determine whether current user session has administrator priviledges.
    const isAdminUser = yield request.auth.isAdmin()
    // Check whether the current user session has administrator priviledges.
    if (!isAdminUser) {
      // Raise Http exception due to unauthenicated state.
      throw new NE.HttpException('Forbidden', 403)
    }

    yield next
  }

}

module.exports = AdminUser
