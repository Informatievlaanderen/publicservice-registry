'use strict'

/*
|--------------------------------------------------------------------------
| Router
|--------------------------------------------------------------------------
|
| AdonisJs Router helps you in defining urls and their actions. It supports
| all major HTTP conventions to keep your routes file descriptive and
| clean.
|
| @example
| Route.get('/user', 'UserController.index')
| Route.post('/user', 'UserController.store')
| Route.resource('user', 'UserController')
*/

const Route = use('Route')

// @todo Split the routes.js file up into seperate files.

// REST API v1 Session related operations:
Route
  .group('rest-api-v1-session', function () {
    Route.post('login', 'Api/v1/SessionController.login').formats(['json'])
    Route.post('logout', 'Api/v1/SessionController.logout').formats(['json'])
    // Only allow administrator users to perform token switching.
    Route.post('switch-token', 'Api/v1/SessionController.switchToken')
  })
  .prefix('api/v1/session')

// REST API v1 Dosis related operations:
Route
  .group('rest-api-v1-dosis', function () {
    Route.get('files', 'Api/v1/DosisController.files').middleware(['auth'])
  })
  .prefix('api/v1/dosis')
  .formats(['json'])

// REST API v1 Dosis related operations:
Route
  .group('rest-api-v1-profile', function () {
    Route.get('', 'Api/v1/ProfileController.get').middleware(['auth'])
    Route.route('', ['POST', 'PUT'], 'Api/v1/ProfileController.update').middleware(['auth'])
    Route.delete('', 'Api/v1/ProfileController.delete').middleware(['auth'])
  })
  .prefix('api/v1/profile')
  .formats(['json'])

// REST API v1 Education related operations:
Route
  .group('rest-api-v1-education', function () {
    Route.get('testCases', 'Api/v1/EducationController.testCases').middleware(['auth'])
    Route.get('events', 'Api/v1/EducationController.events').middleware(['auth'])
    Route.get('dashboardStatus', 'Api/v1/EducationController.dashboardStatus').middleware(['auth'])
  })
  .prefix('api/v1/education')
  .formats(['json'])

// REST API v1 Notification related operations:
Route
  .group('rest-api-v1-notification', function () {
    Route.get('list', 'Api/v1/NotificationController.list').middleware(['auth'])
    Route.post('markAsRead', 'Api/v1/NotificationController.markAsRead').middleware(['auth'])
  })
  .prefix('api/v1/notification')
  .formats(['json'])

// REST API v1 Audit related operations:
Route
  .group('rest-api-v1-audit', function () {
    Route.get('testCases', 'Api/v1/AuditController.testCases').middleware(['auth'])
    Route.get('extractions', 'Api/v1/AuditController.extractions').middleware(['auth'])
    Route.get('dashboardStatus', 'Api/v1/AuditController.dashboardStatus').middleware(['auth'])
  })
  .prefix('api/v1/audit')
  .formats(['json'])

// REST API v1 Person related operations:
Route
  .group('rest-api-v1-person', function () {
    Route.get('testCases', 'Api/v1/PersonController.testCases').middleware(['auth'])
    Route.get('particulars', 'Api/v1/PersonController.particulars').middleware(['auth'])
    Route.get('descent', 'Api/v1/PersonController.descent').middleware(['auth'])
    Route.get('family', 'Api/v1/PersonController.family').middleware(['auth'])
  })
  .prefix('api/v1/person')
  .formats(['json'])

// REST API v1 Accommodation related operations:
Route
  .group('rest-api-v1-accommodation', function () {
    Route.get('testCases', 'Api/v1/AccommodationController.testCases').middleware(['auth'])
    Route.get('residence', 'Api/v1/AccommodationController.residence').middleware(['auth'])
    Route.get('property', 'Api/v1/AccommodationController.property').middleware(['auth'])
  })
  .prefix('api/v1/accommodation')
  .formats(['json'])

// REST API v1 taxes/benefits related operations:
Route
  .group('rest-api-v1-tax', function () {
    Route.get('testCases', 'Api/v1/TaxController.testCases').middleware(['auth'])
    Route.get('assistance', 'Api/v1/TaxController.assistance').middleware(['auth'])
    Route.get('careerBreaks', 'Api/v1/TaxController.careerBreaks').middleware(['auth'])
  })
  .prefix('api/v1/tax')
  .formats(['json'])

// REST API v1 photo related operations:
Route
  .group('rest-api-v1-photo', function () {
    Route.get('passport', 'Api/v1/PhotoController.passport').middleware(['auth'])
    Route.get('profile', 'Api/v1/PhotoController.profile').middleware(['auth'])
    Route.put('profile', 'Api/v1/PhotoController.updateProfile').middleware(['auth'])
    Route.delete('profile', 'Api/v1/PhotoController.removeProfile').middleware(['auth'])
  })
  .prefix('api/v1/photo')
  .formats(['json'])

// SAML related operations:
Route
  .group('saml', function () {
    Route.get('login', 'SAMLController.login')
    Route.get('logout', 'SAMLController.logout')
    Route.route('consumer', ['GET', 'POST'], 'SAMLController.consumer')
  })
  .prefix('saml/services')
// SAML Service Provider metadata endpoint.
Route.get('saml/sp/metadata', 'SAMLController.metadata')

// Default fallback route for Server-Side rendering:
Route.any('*', 'NuxtController.render')
