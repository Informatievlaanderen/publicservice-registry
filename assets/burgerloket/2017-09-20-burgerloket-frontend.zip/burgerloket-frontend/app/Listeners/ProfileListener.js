'use strict'

const logger = use('AppLog')
const profileService = make('App/Service/ProfileService')
const ProfileListener = exports = module.exports = {}

/**
 * Event handler which triggers profile creation when a user logged in.
 */
ProfileListener.onLogin = function * (sessionId, user) {
  try {
    // Get the user profile for given token.
    yield profileService.createOrGetProfile(user.token, user)
    logger.debug('Login triggered for session ', sessionId)
  } catch (err) {
    logger.error(err, err.stack)
  }
}

ProfileListener.onLogout = function * (sessionId) {
  logger.debug('Logout triggered for session ', sessionId)
}
