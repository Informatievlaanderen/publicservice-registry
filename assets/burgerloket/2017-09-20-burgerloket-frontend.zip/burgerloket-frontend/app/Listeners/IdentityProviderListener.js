'use strict'

const Config = use('Config')
const ServiceProvider = make('App/Auth/ServiceProvider')
const IdentityProviderListener = exports = module.exports = {}

/**
 * Event handler which registers the configured identity provider.
 */
IdentityProviderListener.onHttpStart = function () {
  // Get the IdP metadata filepath.
  const content = Config.get('auth.identityProviderConfig')
  // Parse the configuration.
  const metadata = JSON.parse(content)
  // Add the IdP metadata to the Service Provider.
  const entityID = ServiceProvider.addIdentityProviderMetadata(metadata)
  // Set the default identity provider.
  ServiceProvider.setDefaultIdentityProvider(entityID)
}
