'use strict'

/**
 * Defines the identity provider store.
 */
class IdentityProviderStore {

  /**
   * Create an IdentityProviderStore object.
   */
  constructor () {
    this._idpConfigs = {}
    this._default = null
  }

  /**
   * Get the default entity ID.
   *
   * @returns {String|null}
   *   The entity ID if available, otherwise null.
   */
  getDefault () {
    return this._default
  }

  /**
   * Set the default entity ID.
   *
   * @param {String} entityID
   *   The entity ID
   */
  setDefault (entityID) {
    // Check whether the entity ID is missing.
    if (!this.has(entityID)) {
      // Raise error due to missing IdP config.
      throw new Error('Unknown identity provider')
    }
    // Set the default entity ID.
    this._default = entityID
  }

  /**
   * Get an indication whether the entityID is present.
   *
   * @param {String} entityID
   *   An IDP configuration entity identifier to validate.
   *
   * @returns {Boolean}
   *   True if the entity identifier is present, otherwise false.
   */
  has (entityID) {
    return this._idpConfigs.hasOwnProperty(entityID)
  }

  /**
   * Add a IDP configuration.
   *
   * This will override any existing configuration with same entity identifier.
   *
   * @param {Object} idpConfig
   *   An object which describes the IDP configuration.
   *
   * @returns {String}
   *   The entity identifier of the IdP configuration.
   */
  add (idpConfig) {
    // Get the entity identifier from the configuration.
    const entityID = idpConfig ? (idpConfig.entityID || null) : null
    // Check whether the entity identifier is missing.
    if (entityID === null) {
      // Raise error due to missing entity identifier.
      throw new Error('Missing entity identifier in IDP configuration')
    }
    // Assign the IdP configuration for given entity identifier.
    this._idpConfigs[entityID] = idpConfig

    return entityID
  }

  /**
   * Get an IDP configuration.
   *
   * @param {String} entityID
   *   The IDP entity identifier.
   *
   * @returns {Object|null}
   *   An object which contains the IDP configuration, otherwise null.
   */
  get (entityID) {
    return this._idpConfigs[entityID] || null
  }

}

module.exports = new IdentityProviderStore()
