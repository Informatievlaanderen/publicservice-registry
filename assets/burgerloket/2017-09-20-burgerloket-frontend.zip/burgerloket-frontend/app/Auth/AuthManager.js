'use strict'

const Event = use('Event')

/**
 * Manager for the authentication process.
 */
class AuthManager {

  /**
   * Create an AuthManager object.
   *
   * @param {Cache} cache
   *   The application cache layer.
   * @param {Config} config
   *   The application configuration.
   * @param {Request} request
   *   An object which represents the request.
   */
  constructor (cache, config, request) {
    // Setup object members.
    this._cache = cache
    this._config = config
    this._request = request
    this._user = null
  }

  /**
   * Get the application cache layer.
   *
   * @returns {Cache}
   *   An instance of Cache.
   */
  get cache () { return this._cache }

  /**
   * Get the application config.
   *
   * @returns {Config}
   *   An instance of Config.
   */
  get config () { return this._config }

  /**
   * Get the client request.
   *
   * @returns {Request}
   *   An instance of Request.
   */
  get request () { return this._request }

  /**
   * Get an indicatation whether current session is authenticated.
   *
   * @returns {Boolean}
   *   True if current user session is authenticated, otherwise false.
   */
  * isAuthenticated () {
    // Get the user from current session.
    const user = yield this.getUser()
    // Determine whether an authenticated user session is
    // present.
    return user !== null
  }

  /**
   * Get an indication whether the current user session has adminstrator
   * priviledges.
   *
   * @returns {Boolean}
   *   True if the user session has administrator priviledges, otherwise false.
   */
  * isAdmin () {
    // Determine whether the user session is authenticated.
    const authenticated = yield this.isAuthenticated()
    // Check whether the user session is authenticated.
    if (authenticated) {
      // Get the current user.
      const user = yield this.getUser()
      // Get the user token.
      const userToken = user.token || null
      // Check whether user token is resolved.
      if (userToken !== null) {
        // Determine whether the user token matches an admin user.
        return this.config.get('auth.adminUsers').indexOf(user.token || null) > -1
      }
    }

    return false
  }

  /**
   * Get the current user.
   *
   * @returns {Object}
   *   An object which represents the user.
   */
  * getUser () {
    // Check whether the user needs to be resolved.
    if (this._user === null) {
      // Get the current session identifier.
      const sessionId = this.request.session.sessionId
      // Get the user information from the given cache.
      this._user = yield this.cache.get('session__user__' + sessionId, null)
    }

    return this._user
  }

  /**
   * Start an authenticated session for given user.
   *
   * @param {Object} user
   *   An object which represents the user.
   */
  * login (user) {
    // Validate the user argument.
    if (user === null || user === undefined) {
      // Raise error due to missing or invalid user argument.
      throw new Error('Missing or invalid user')
    }

    // Validate the required user properties.
    if (!user.token || !user.firstName || !user.lastName) {
      // Raise error due to missing or invalid user properties.
      throw new Error('Missing or invalid user properties')
    }

    // Get the current session identifier.
    const sessionId = this.request.session.sessionId
    // Start a user session for given user information. Limit the user session
    // to specified age.
    yield this.cache.put('session__user__' + sessionId, user, this.config.get('session.age'))
    // Update the current user member.
    this._user = user
    // Notify listeners of login
    Event.fire('Session.login', sessionId, user)
  }

  /**
   * Stop an authentication session for current user.
   */
  * logout () {
    // Get the current session identifier.
    const sessionId = this.request.session.sessionId
    // Get the user information from the given cache.
    yield this.cache.forget('session__user__' + sessionId)
    // Update the current user member.
    this._user = null
    // Notify listeners of logout
    Event.fire('Session.logout', sessionId)
  }

}

module.exports = AuthManager
