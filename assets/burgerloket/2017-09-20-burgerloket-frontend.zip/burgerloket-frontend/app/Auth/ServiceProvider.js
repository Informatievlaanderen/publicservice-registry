'use strict'

const co = require('co')
const fs = require('fs')

/**
 * Defines a SAML service provider for an application.
 */
class ServiceProvider {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['App/Addons/SAML', 'Config', 'Cache', 'App/Auth/IdentityProviderStore']
  }

  /**
   * Create a ServiceProvider object.
   *
   * @param {SAML} SAML
   *   The SAML Protocol library.
   * @param {Config} config
   *   The application configuration.
   * @param {Cache} cache
   *   The application cache layer.
   * @param {IdPStore} idpStore
   *   A store which holds IDP configurations.
   */
  constructor (SAML, config, cache, idpStore) {
    // Setup object members.
    this._idpStore = idpStore
    this._config = config
    this._cache = cache
    this._sp = new SAML.ServiceProvider(this._createServiceProviderConfig(config), this)
  }

  /**
   * Create the service provider configuration;
   *
   * @param {Config} config
   *   The application configuration.
   * @param {IdPStore} idpStore
   *   The Identity Provider Store.
   *
   * @returns {Object}
   *   An object which represents the service provider configuration.
   */
  _createServiceProviderConfig (config) {
    // Load the service provider configuration.
    const serviceProviderConfig = JSON.parse(config.get('auth.serviceProviderConfig'))
    // Check whether the service provider configuration is available.
    console.log(config);
    if (serviceProviderConfig) {
      // Iterate through the certificates and upgrade to file content if required.
      serviceProviderConfig.credentials = serviceProviderConfig.credentials.map((obj) => {
        // Evaluate the credential type.
        switch (obj.type) {
          case 'file':
            // Load the certificate by filepath.
            obj.certificate = fs.readFileSync(obj.certificate).toString()
            // Load the private key by filepath.
            obj.privateKey = fs.readFileSync(obj.privateKey).toString()
            break
        }

        return obj
      })
    }

    return serviceProviderConfig || null
  }

  /**
   * Get the default identity provider.
   *
   * @returns {String|null}
   *   The identity provider entity ID.
   */
  getDefaultIdentityProvider () {
    return this._idpStore.getDefault()
  }

  /**
   * Set default identity provider.
   *
   * @param {String} entityID
   *   The identity provider entity ID.
   */
  setDefaultIdentityProvider (entityID) {
    this._idpStore.setDefault(entityID)
  }

  /**
   * Add an Identity Provider metadata by filepath.
   *
   * @param {String} filepath
   *   Path to the IdP metadata.
   *
   * @returns {String}
   *   The entity ID for the added Identity Provider.
   */
  addIdentityProviderMetadataByPath (filepath) {
    // Get the filecontent for given filepath.
    const content = fs.readFileSync(filepath).toString()
    // Add the Identity Provider metadata using specified content.
    return this.addIdentityProviderMetadataByContent(content)
  }

  /**
   * Add an Identity Provider metadata content.
   *
   * @param {Object} metadata
   *   An object which contains the IdP metadata.
   *
   * @returns {String}
   *   The entity ID for the added Identity Provider.
   */
  addIdentityProviderMetadataByContent (content) {
    // Get the Identity Provider metadata based on the content.
    const metadata = this._sp.getIDPFromMetadata(content)
    // Add the Identity provider metadata.
    return this.addIdentityProviderMetadata(metadata)
  }

  /**
   * Add an Identity Provider metadata.
   *
   * @param {Object} metadata
   *   An object which contains the IdP metadata.
   *
   * @returns {String}
   *   The entity ID for the added Identity Provider.
   */
  addIdentityProviderMetadata (metadata) {
    // Add the Identity provider metadata to the store.
    return this._idpStore.add(metadata)
  }

    /**
   * Resolves an IDPs config object by Entity ID.
   *
   * @param {String} entityID
   *   An IDP entity ID.
   *
   * @returns {Promise}
   *   A promise to resolve the IDP config.
   */
  getIdentityProvider (entityID) {
    // Create a promise to resolve the IDP configuration.
    return new Promise((resolve, reject) => {
      // Get the IDP configuration for given entity ID.
      const idpConfig = this._idpStore.get(entityID)
      // Check whether an IDP configuration exists.
      if (idpConfig === null) {
        // Raise error due to unknown entity identifier.
        reject(new Error('Unknown identity provider entity identifier'))
      } else {
        // Resolve with the IDP configuration for specified entity identifier.
        resolve(idpConfig)
      }
    })
  }

  /**
   * Store a request ID for later verification.
   *
   * @param {String} requestID
   *   A unique request identifier.
   * @param {Object} idpConfig
   *   An object which describes the IDP configuration.
   *
   * @returns {Promise}
   *   A promise to store the request identifier.
   */
  storeRequestID (requestID, idpConfig) {
    // Create a promise to store the request identifieer.
    return new Promise((resolve, reject) => {
      // Build the cache key based on the request identifier.
      const cacheKey = 'saml__request__' + requestID
      // Store the request identifier and configuration.
      this._cache
        .put(cacheKey, idpConfig, this._config.get('auth.requestTimeout'))
        .then(resolve)
        .catch(reject)
    })
  }

  /**
   * Verifies that a request with requestID was sent by the SP.
   *
   * @param {String} requestID
   *   A unique request identifier.
   * @param {Object} idpConfig
   *   An object which describes the IDP configuration.
   *
   * @returns {Promise}
   *   A promise to verify the request identifier.
   */
  verifyRequestID (requestID, idpConfig) {
    // Get a reference to ourself.
    const self = this
    // Convert generator into a promise.
    return co(function * () {
      // Build the cache key based on the request identifier.
      const cacheKey = 'saml__request__' + requestID
      // Get the IDP configuration for given cache key.
      const idpConfigCache = yield self._cache.get(cacheKey, null)

      // Get the HashObject library.
      const HashObject = use('HasHObject')
      // Check whether the configuration matches.
      if (HashObject(idpConfig) !== HashObject(idpConfigCache)) {
        // Raise error due to unknown request ID or IDP config mismatch.
        throw Error('Unknown request ID or IDP configuration mismatch')
      }
    })
  }

  /**
   * Invalidates a requestID after a response has been processed to prevent
   * duplicate assertion playback attacks.
   *
   * @param {String} requestID
   *   A unique request identifier.
   * @param {Object} idpConfig
   *   An object which describes the IDP configuration.
   *
   * @returns {Promise}
   *   A promise to invalidate the request identifier.
   */
  invalidateRequestID (requestID, idpConfig) {
    // Get a reference to ourself.
    const self = this
    // Convert generator function into a promise.
    return co(function * () {
      // Build the cache key based on the request identifier.
      const cacheKey = 'saml__request__' + requestID
      // Remove the cache key from cache.
      yield self._cache.forget(cacheKey)
    })
  }

  /**
   * Consume a POST response.
   *
   * @param {Object} formData
   *   An object which contains the form data.
   *
   * @returns {Object}
   *   An object which contains the SAML response result.
   */
  * consumePostResponse (formData) {
    // Perform passthrough to the underlying library.
    return yield this._sp.consumePostResponse(formData)
  }

  /**
   * Consume a redirect response.
   *
   * @param {Oject} queryParams
   *   An object which contains the query parameters.
   *
   * @returns {Object}
   *   An object which contains the SAML response result.
   */
  * consumeRedirectResponse (queryParams) {
    // Perform passthrough to the underlying library.
    return yield this._sp.consumeRedirectResponse(queryParams)
  }

  /**
   * Produce an authentication request for given IdP entity ID.
   *
   * @param {String} [idpEntityId=null]
   *   Optional. An IdP entity identifier.
   *
   * @returns {Object}
   *   An object which contains the authentication request information.
   */
  * produceAuthnRequest (idpEntityId) {
    // Check whether the argument is ommitted.
    if (idpEntityId === null || idpEntityId === undefined) {
      // Use the default identity provider.
      idpEntityId = this.getDefaultIdentityProvider()
    }

    // Resolve the IdP configuration based on given entity ID.
    const idpConfig = yield this.getIdentityProvider(idpEntityId)
    // Produce an authentication request for given configuration.
    return yield this._sp.produceAuthnRequest(idpConfig)
  }

  /**
   * Produce the metadata.
   *
   * @returns {String}
   *   The service provider metadata XML.
   */
  * produceSPMetadata () {
    // Perform passthrough to the underlying library.
    return yield this._sp.produceSPMetadata()
  }

}

module.exports = ServiceProvider
