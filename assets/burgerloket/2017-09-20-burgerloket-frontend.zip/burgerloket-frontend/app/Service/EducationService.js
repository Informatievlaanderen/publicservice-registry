'use strict'

const AbstractService = require('./AbstractService')

/**
 * Education Service definition.
 */
class EducationService extends AbstractService {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['Config', 'Cache', 'App/Service/Backend/EducationBackend', 'App/Service/DataMap/Education/EventDataMap', 'App/Service/DataMap/Common/ApplicationReferenceDataMap', 'App/Service/DataMap/TestCaseMap']
  }

  /**
   * Create a EducationService object.
   *
   * @param {Object} config
   *   The application configuration.
   * @param {Cache} cache
   *   The cache layer.
   * @param {AbstractBackend} backend
   *   An instance of AbstractBackend.
   * @param {AbstractDataMap} educationEventDataMap
   *   An instance of AbstractDataMap for converting education events.
   * @param {AbstractDataMap} appReferenceDataMap
   *   An instance of ApplicationReferenceDataMap.
   * @param {AbstractDataMap} testCaseDataMap
   *   An instance of TestCaseMap.
   */
  constructor (config, cache, backend, educationEventDataMap, appReferenceDataMap, testCaseDataMap) {
    // Perform default object creation.
    super(cache, backend)
    // Setup object members.
    this._config = config
    this._educationEventDataMap = educationEventDataMap
    this._appReferenceDataMap = appReferenceDataMap
    this._testCaseDataMap = testCaseDataMap
  }

  /**
   * {@inheritdoc}
   */
  get name () { return 'education' }

  /**
   * Get the application configuration.
   *
   * @returns {Config}
   *   An instance of Config.
   */
  get config () { return this._config }

  /**
   * Get a list of test case groups.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getTestCases () {
    // Build the read operation options.
    const options = {
      cacheExpire: this.config.get('service.education.cacheExpire')
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getEducationTestCases', options, {}, function * () {
      // Get the test cases from the backend.
      const testCases = yield this.service.backend.getTestCases()
      // Map the raw test case data structure onto a list of test case grouped by category.
      return this.service._testCaseDataMap.map(testCases)
    })
  }

  /**
   * Get a list of education events for specified token.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getEvents (token) {
    // Build the read operation options.
    const options = {
      cacheExpire: this.config.get('service.education.cacheExpire')
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getEvents', options, { token }, function * () {
      // Get the education events.
      const educationEvents = yield this.service.backend.getEvents(token)
      // Convert the educations events int our JSON structure.
      const events = this.service._educationEventDataMap.mapArray(educationEvents.onderwijsGebeurtenissen.lijst)
      // Build the default result object.
      const obj = {
        reference: this.service._appReferenceDataMap.map(educationEvents.onderwijsGebeurtenissen.referentie),
        events: this.service._educationEventDataMap.mapArray(educationEvents.onderwijsGebeurtenissen.lijst),
        timeline: [],
        dashboardStatus: {
          status: events.length > 0,
          meta: {
            integration: educationEvents.header.inburgeringsIndicatie
          }
        }
      }

      // Initialize the timeline groups to an empty object. This will
      // be used as temporary variable to perform fast lookup of groups
      // when rebuilding the timeline.
      const timelineGroups = { }
      // Iterate through the education event items.
      obj.events.forEach((item) => {
        // Check whether the group needs to be initialized.
        if (timelineGroups[item.year] === undefined) {
          // Initialize group with an empty array.
          timelineGroups[item.year] = []
        }
        // Append the item to the current group.
        timelineGroups[item.year].push(item)
      })
      // Convert the timeline groups into a more usable
      // structure for the frontend components.
      obj.timeline = Object
        .keys(timelineGroups)
        .map((year) => {
          return {
            // Convert the string value to integer.
            year: parseInt(year),
            items: timelineGroups[year]
          }
        })
        .sort((a, b) => b.year - a.year)

      return obj
    })
  }

  /**
   * Get the dashboard status for given user token.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getDashboardStatus (token) {
    // Build the read operation options.
    const options = {
      cacheExpire: this.config.get('service.education.cacheExpire')
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getEducationDashboardStatus', options, { token }, function * () {
      // Get the dashboard status for given user token.
      const rawDashboardStatus = yield this.service.backend.getDashboardStatus(token)

      // Initialize the variable to null as default behavior.
      let dashboardStatus = null
      // Check whether we need to resolve the education events to determine the
      // dashboard status.
      if (rawDashboardStatus.heeftOnderwijsInformatie === 'ONBEKEND' || rawDashboardStatus.heeftInburgeringInformatie === 'ONBEKEND') {
        // Get the education events.
        const events = yield this.service.getEvents(token)
        // Use the dashboard status from the events.
        dashboardStatus = events.dashboardStatus
      } else {
        // Build the default dashboard status structure.
        dashboardStatus = {
          status: rawDashboardStatus.heeftOnderwijsInformatie === 'BESCHIKBAAR' || rawDashboardStatus.heeftInburgeringInformatie === 'BESCHIKBAAR',
          meta: {
            integration: rawDashboardStatus.heeftInburgeringInformatie === 'BESCHIKBAAR'
          }
        }
      }

      return dashboardStatus
    })
  }

}

module.exports = EducationService
