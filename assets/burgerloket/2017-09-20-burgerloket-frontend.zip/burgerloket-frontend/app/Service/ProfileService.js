'use strict'

const AbstractService = require('./AbstractService')

/**
 * Profile service definition.
 */
class ProfileService extends AbstractService {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['Config', 'Cache', 'App/Service/Backend/ProfileBackend', 'App/Service/DataMap/ProfileMap']
  }

  /**
   * Create a Dosis object.
   *
   * @param {Object} config
   *   The application configuration.
   * @param {Cache} cache
   *   The cache layer.
   * @param {AbstractBackend} backend
   *   An instance of AbstractBackend.
   * @param {AbstractDataMap} dataMap
   *   An instance of AbstractDataMap.
   */
  constructor (config, cache, backend, dataMap) {
    // Perform default object creation.
    super(cache, backend)
    // Setup object members.
    this._config = config
    this._dataMap = dataMap
  }

  /**
   * {@inheritdoc}
   */
  get name () { return 'profile' }

  /**
   * Get the application configuration.
   *
   * @returns {Config}
   *   An instance of Config.
   */
  get config () { return this._config }

  /**
   * Create a profile for given token.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   * @param {Object} profile
   *   An object which represents the profile.
   *
   * @returns {WriteOperation}
   *   An instance of WriteOperation.
   */
  createProfile (token, profile) {
    // Build the write operation options.
    const options = {
      cacheExpire: this.config.get('service.profile.cacheExpire')
    }
    // Create a write operation for given worker.
    return this.createWriteOperation('createProfile', options, { token, profile }, function * () {
      // Update the profile for given token.
      const rawProfile = yield this.service.backend.createProfile(token, {
        voornaam: profile.firstName || '',
        familienaam: profile.lastName || '',
        roepnaam: profile.nickname || ''
      })

      // Map the raw profile data structure.
      const mappedProfile = this.service._dataMap.map(rawProfile)
      // Get the profile cache key.
      const cacheKey = this.service.getProfile(token).cacheKey
      // Update the existing cache data.
      yield this.service.cache.put(cacheKey, mappedProfile, options.cacheExpire)

      return mappedProfile
    })
  }

  /**
   * Retrieve a profile for given token, create it if it doesn't exist yet.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   * @param {Object} profileToBeCreated
   *   An object which represents the profile to be created.
   *
   * @returns {Object}
   *   The profile for the given token (either existing or newly created)
   */
  * createOrGetProfile (token, profileToBeCreated) {
    let profile = yield this.getProfile(token).exec()
    // @fixme Currently the backend service does not auto create profile due to no integration with ACM.
    if (profile === null) {
      // Create a new profile for this user.
      profile = yield this.createProfile(token, profileToBeCreated).exec()
    }
    return profile
  }

  /**
   * Retrieve a profile for given token.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getProfile (token) {
    // Build the read operation options.
    const options = {
      cacheExpire: this.config.get('service.profile.cacheExpire')
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getProfile', options, { token }, function * () {
      // Get the profile from the backend.
      const profile = yield this.service.backend.getProfile(token)
      // Map the raw profile data structure.
      return profile ? this.service._dataMap.map(profile) : null
    })
  }

  /**
   * Update profile for given token.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   * @param {Object} profile
   *   An object which represents the profile.
   *
   * @returns {WriteOperation}
   *   An instance of WriteOperation.
   */
  updateProfile (token, profile) {
    // Build the write operation options.
    const options = {
      cacheExpire: this.config.get('service.profile.cacheExpire')
    }
    // Create a write operation for given worker.
    return this.createWriteOperation('updateProfile', options, { token, profile }, function * () {
      // Update the profile for given token.
      const rawProfile = yield this.service.backend.updateProfile(token, {
        voornaam: profile.firstName || '',
        familienaam: profile.lastName || '',
        roepnaam: profile.nickname || ''
      })
      // Map the raw profile data structure.
      const mappedProfile = this.service._dataMap.map(rawProfile)
      // Get the profile cache key.
      const cacheKey = this.service.getProfile(token).cacheKey
      // Update the existing cache data.
      yield this.service.cache.put(cacheKey, mappedProfile, options.cacheExpire)

      return mappedProfile
    })
  }

  /**
   * Delete profile for given token.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   *
   * @returns {WriteOperation}
   *   An instance of WriteOperation.
   */
  deleteProfile (token) {
    // Build the write operation options.
    const options = { }
    // Create a write operation for given worker.
    return this.createWriteOperation('deleteProfile', options, { token }, function * () {
      // Delete the profile for given token.
      const success = yield this.service.backend.deleteProfile(token)
      // Check whether operation was successful.
      if (success) {
        // Get the profile cache key.
        const cacheKey = this.service.getProfile(token).cacheKey
        // Clear the profile cache.
        yield this.service.cache.forget(cacheKey)
      }

      return success
    })
  }

}

module.exports = ProfileService
