'use strict'

const moment = require('moment')
const AbstractService = require('./AbstractService')

/**
 * Audit data service definition.
 */
class AuditService extends AbstractService {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['Config', 'Cache', 'App/Service/Backend/AuditBackend', 'App/Service/DataMap/AuditMap', 'App/Service/DataMap/TestCaseMap']
  }

  /**
   * Create a Service object.
   *
   * @param {Object} config
   *   The application configuration.
   * @param {Cache} cache
   *   The cache layer.
   * @param {AbstractBackend} backend
   *   An instance of AbstractBackend.
   * @param {AbstractDataMap} dataMap
   *   An instance of AbstractDataMap.
   * @param {AbstractDataMap} testCaseDataMap
   *   An instance of TestCaseMap.
   */
  constructor (config, cache, backend, dataMap, testCaseDataMap) {
    // Perform default object creation.
    super(cache, backend)
    // Setup object members.
    this._config = config
    this._dataMap = dataMap
    this._testCaseDataMap = testCaseDataMap
  }

  /**
   * {@inheritdoc}
   */
  get name () { return 'audit' }

  /**
   * Get the application configuration.
   *
   * @returns {Config}
   *   An instance of Config.
   */
  get config () { return this._config }

  /**
   * Retrieve all audit data for given token.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getAuditData (token) {
    // Build the read operation options.
    const options = {
      cacheExpire: this.config.get('service.audit.cacheExpire')
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getAuditData', options, { token }, function * () {
      // Get the raw audit data from the backend.
      const rawAuditData = yield this.service.backend.getAuditData(token)

      // Map the raw profile data structure.
      const extractions = this.service._dataMap.mapArray(rawAuditData)

      // Group extractions by year
      const extractionsByYear = extractions.reduce((byYear, extraction) => {
        const year = moment(extraction.date).format('YYYY')
        byYear[year] = byYear[year] || []
        byYear[year].push(extraction)
        return byYear
      }, {})

      // Transform into timeline with { year, items } entries
      const timeline = Object.keys(extractionsByYear)
        .map((year) => ({ year: parseInt(year), items: extractionsByYear[year] }))
        .sort((a, b) => b.year - a.year)

      return { extractions, timeline }
    })
  }

  /**
   * Get a list of test case groups.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getTestCases () {
    // Build the read operation options.
    const options = {
      cacheExpire: this.config.get('service.audit.cacheExpire')
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getAuditTestCases', options, {}, function * () {
      // Get the test cases from the backend.
      const testCases = yield this.service.backend.getTestCases()
      // Map the raw test case data structure onto a list of test case grouped by category.
      return this.service._testCaseDataMap.map(testCases)
    })
  }

  /**
   * Get the dashboard status for given user token.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getDashboardStatus (token) {
    // Build the read operation options.
    const options = {
      cacheExpire: this.config.get('service.audit.cacheExpire')
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getAuditDashboardStatus', options, { token }, function * () {
      // Get the dashboard status for given user token.
      const rawDashboardStatus = yield this.service.backend.getDashboardStatus(token)

      return {
        status: rawDashboardStatus.heeftInformatie === 'BESCHIKBAAR'
      }
    })
  }

}

module.exports = AuditService
