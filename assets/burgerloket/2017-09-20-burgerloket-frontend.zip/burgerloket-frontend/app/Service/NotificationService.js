'use strict'

const AbstractService = require('./AbstractService')

/**
 * Notification service definition.
 */
class NotificationService extends AbstractService {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['Config', 'Cache', 'App/Service/Backend/NotificationBackend', 'App/Service/DataMap/NotificationMap']
  }

  /**
   * Create a Dosis object.
   *
   * @param {Object} config
   *   The application configuration.
   * @param {Cache} cache
   *   The cache layer.
   * @param {AbstractBackend} backend
   *   An instance of AbstractBackend.
   * @param {AbstractDataMap} dataMap
   *   An instance of AbstractDataMap.
   */
  constructor (config, cache, backend, dataMap) {
    // Perform default object creation.
    super(cache, backend)
    // Setup object members.
    this._config = config
    this._dataMap = dataMap
  }

  /**
   * {@inheritdoc}
   */
  get name () { return 'notification' }

  /**
   * Get the application configuration.
   *
   * @returns {Config}
   *   An instance of Config.
   */
  get config () { return this._config }

  /**
   * Get a list of notifications for given token.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getNotifications (token) {
    // Build the read operation options.
    const options = {
      cacheExpire: this.config.get('service.notification.cacheExpire')
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getNotifications', options, { token }, function * () {
      // Get a list of notifications for given token.
      const rawNotifications = yield this.service.backend.getNotifications(token)
      // Map the notifications list.
      return this.service._dataMap.mapArray(rawNotifications)
    })
  }

  /**
   * Mark a notification for given ID as read.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   * @param {String} id
   *   A unique identifier which represents a notification ID.
   *
   * @returns {WriteOperation}
   *   An instance of WriteOperation.
   */
  markNotificationAsRead (token, id) {
    // Build the write operation options.
    const options = { }
    // Create write operation for given worker.
    return this.createWriteOperation('markNotificationAsRead', options, { token, id }, function * () {
      // Mark the notification with specified ID as read.
      const success = yield this.service.backend.markNotificationAsRead(token, id)
      // Check whether the operation was successful.
      if (success) {
        // Reset the notifications cache.
        const cacheKey = this.service.getNotifications(token).cacheKey
        // Clear the notifications cache.
        yield this.service.cache.forget(cacheKey)
      }

      return success
    })
  }

}

module.exports = NotificationService
