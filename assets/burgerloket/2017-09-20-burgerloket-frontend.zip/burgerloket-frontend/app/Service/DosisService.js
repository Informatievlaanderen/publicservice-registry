'use strict'

const moment = require('moment')
const AbstractService = require('./AbstractService')

/**
 * Dosis service definition.
 */
class DosisService extends AbstractService {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['Config', 'Cache', 'App/Service/Backend/DosisBackend', 'App/Service/DataMap/DosisFileMap']
  }

  /**
   * Create a Dosis object.
   *
   * @param {Object} config
   *   The application configuration.
   * @param {Cache} cache
   *   The cache layer.
   * @param {AbstractBackend} backend
   *   An instance of AbstractBackend.
   * @param {AbstractDataMap} dataMap
   *   An instance of AbstractDataMap.
   */
  constructor (config, cache, backend, dataMap) {
    // Perform default object creation.
    super(cache, backend)
    // Setup object members.
    this._config = config
    this._dataMap = dataMap
  }

  /**
   * {@inheritdoc}
   */
  get name () { return 'dosis' }

  /**
   * Get the application configuration.
   *
   * @returns {Config}
   *   An instance of Config.
   */
  get config () { return this._config }

  /**
   * Get a list of files for given token and language.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   * @param {String} language
   *   Language for which the labels should be included.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getFiles (token, language) {
    // Build the read operation options.
    const options = {
      cacheExpire: this.config.get('service.dosis.cacheExpire')
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getFiles', options, { token, language }, function * () {
      // Build the default object structure.
      const obj = {
        timeline: [],
        files: []
      }

      // Get the maximum amount of items which should be processed
      // during each batch.
      const batchSize = this.service.config.get('service.dosis.batchSize')

      // Initialize variable to null
      let batch = null
      // Initialize temporary variable to an empty array. This will be used
      // to hold a list of raw files.
      let rawFiles = []
      // Loop until all Dosis files have been resolved.
      do {
        // Get the initial batch from the Dosis backend.
        batch = yield this.service.backend.getFiles(token, rawFiles.length, batchSize, true, language)
        // Merge the batch with the already resolved Dosis files.
        rawFiles = rawFiles.concat(batch.Lijst || [])
      } while (batch !== null && rawFiles.length < batch.AantalDossiers)

      // Map the resolved data to our custom data format. Keep
      // in mind currently we only support Dosis files of type
      // "DossierStatus".
      obj.files = this.service._dataMap.mapArray(rawFiles.filter((file) => file.TypeDossier.Code === 'DossierStatus'))

      // Initialize the timeline groups to an empty object. This will be used as temporary
      // variable to perform fast lookup of groups when rebuilding the timeline.
      const timelineGroups = { }

      obj.files.forEach((item) => {
        // Get the changed year as this will be used to determine the
        // group name.
        const year = moment(item.changed).format('YYYY')
        // Check whether the group needs to be initialized.
        if (timelineGroups[year] === undefined) {
          // Initilaize group with an empty array.
          timelineGroups[year] = []
        }
        // Append the item to group for given year.
        timelineGroups[year].push(item)
      })
      // Convert the timeline groups into a more usiable
      // structure for the frontend components.
      obj.timeline = Object
        .keys(timelineGroups)
        .map((year) => {
          return {
            // Convert the string value to integer.
            year: parseInt(year),
            items: timelineGroups[year]
          }
        })
        .sort((a, b) => b.year - a.year)

      return obj
    })
  }

}

module.exports = DosisService
