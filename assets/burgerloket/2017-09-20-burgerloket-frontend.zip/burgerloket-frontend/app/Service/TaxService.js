'use strict'

const AbstractService = require('./AbstractService')

/**
 * Tax data service definition.
 */
class TaxService extends AbstractService {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['Config', 'Cache', 'App/Service/Backend/TaxBackend', 'App/Service/DataMap/Tax/AssistanceMap', 'App/Service/DataMap/Tax/CareerBreaksMap', 'App/Service/DataMap/TestCaseMap']
  }

  /**
   * Create a Service object.
   *
   * @param {Object} config
   *   The application configuration.
   * @param {Cache} cache
   *   The cache layer.
   * @param {AbstractBackend} backend
   *   An instance of AbstractBackend.
   * @param {AbstractDataMap} assistanceMap
   *   An instance of AbstractDataMap.
   * @param {AbstractDataMap} careerBreaksMap
   *   An instance of AbstractDataMap.
   * @param {AbstractDataMap} testCaseDataMap
   *   An instance of TestCaseMap.
   */
  constructor (config, cache, backend, assistanceMap, careerBreaksMap, testCaseDataMap) {
    // Perform default object creation.
    super(cache, backend)
    // Setup object members.
    this._config = config
    this._assistanceMap = assistanceMap
    this._careerBreaksMap = careerBreaksMap
    this._testCaseDataMap = testCaseDataMap
  }

  /**
   * {@inheritdoc}
   */
  get name () { return 'tax' }

  /**
   * Get the application configuration.
   *
   * @returns {Config}
   *   An instance of Config.
   */
  get config () { return this._config }

  /**
   * Retrieve all assistance data for given token.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getAssistance (token) {
    // Build the read operation options.
    const options = {
      cacheExpire: this.config.get('service.tax.cacheExpire')
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getAssistance', options, { token }, function * () {
      // Get the raw assistance data from the backend.
      const rawAssistance = yield this.service.backend.getAssistance(token)

      // Map the raw assistance data structure.
      return this.service._assistanceMap.map(rawAssistance)
    })
  }

  /**
   * Retrieve all career break data for given token.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getCareerBreaks (token) {
    // Build the read operation options.
    const options = {
      cacheExpire: this.config.get('service.tax.cacheExpire')
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getCareerBreaks', options, { token }, function * () {
      // Get the raw assistance data from the backend.
      const rawCareerBreaks = yield this.service.backend.getCareerBreaks(token)

      // Map the raw career breaks data structure.
      return this.service._careerBreaksMap.map(rawCareerBreaks)
    })
  }

  /**
   * Get a list of test case groups.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getTestCases () {
    // Build the read operation options.
    const options = {
      cacheExpire: this.config.get('service.tax.cacheExpire')
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getTaxTestCases', options, {}, function * () {
      // Get the test cases from the backend.
      const testCases = yield this.service.backend.getTestCases()
      // Map the raw test case data structure onto a list of test case grouped by category.
      return this.service._testCaseDataMap.map(testCases)
    })
  }

}

module.exports = TaxService
