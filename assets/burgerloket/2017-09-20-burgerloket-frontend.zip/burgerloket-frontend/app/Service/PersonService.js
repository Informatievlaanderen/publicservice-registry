'use strict'

const CacheMode = require('./CacheMode')
const AbstractService = require('./AbstractService')

/**
 * Person data service definition.
 */
class PersonService extends AbstractService {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return [
      'Config',
      'Cache',
      'App/Service/Backend/PersonBackend',
      'App/Service/DataMap/Person/ParticularsMap',
      'App/Service/DataMap/Person/DescentMap',
      'App/Service/DataMap/Person/FamilyMap',
      'App/Service/DataMap/Person/PhotoMap',
      'App/Service/DataMap/TestCaseMap'
    ]
  }

  /**
   * Create a Service object.
   *
   * @param {Object} config
   *   The application configuration.
   * @param {Cache} cache
   *   The cache layer.
   * @param {AbstractBackend} backend
   *   An instance of AbstractBackend.
   * @param {AbstractDataMap} particularsMap
   *   An instance of AbstractDataMap.
   * @param {AbstractDataMap} descentMap
   *   An instance of AbstractDataMap.
   * @param {AbstractDataMap} familyMap
   *   An instance of AbstractDataMap.
   * @param {AbstractDataMap} photoMap
   *   An instance of AbstractDataMap.
   * @param {AbstractDataMap} testCaseDataMap
   *   An instance of TestCaseMap.
   */
  constructor (config, cache, backend, particularsMap, descentMap, familyMap, photoMap, testCaseDataMap) {
    // Perform default object creation.
    super(cache, backend)
    // Setup object members.
    this._config = config
    this._particularsMap = particularsMap
    this._descentMap = descentMap
    this._familyMap = familyMap
    this._photoMap = photoMap
    this._testCaseDataMap = testCaseDataMap
  }

  /**
   * {@inheritdoc}
   */
  get name () { return 'person' }

  /**
   * Get the application configuration.
   *
   * @returns {Config}
   *   An instance of Config.
   */
  get config () { return this._config }

  /**
   * Retrieve all personal particulars data for given token.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getParticulars (token) {
    // Build the read operation options.
    const options = {
      cacheExpire: this.config.get('service.person.cacheExpire')
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getParticulars', options, { token }, function * () {
      // Get the raw person data from the backend.
      const rawPerson = yield this.service.backend.getPerson(token)
      // Map the raw person structure.
      return this.service._particularsMap.map(rawPerson)
    })
  }

  /**
   * Retrieve descent data for given token.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getDescent (token) {
    // Build the read operation options.
    const options = {
      cacheExpire: this.config.get('service.person.cacheExpire')
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getDescent', options, { token }, function * () {
      // Get the raw person data from the backend.
      const rawPerson = yield this.service.backend.getPerson(token)
      // Map the raw person structure.
      return this.service._descentMap.map(rawPerson)
    })
  }

  /**
   * Retrieve family data for given token.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getFamily (token) {
    // Build the read operation options.
    const options = {
      cacheExpire: this.config.get('service.person.cacheExpire')
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getFamily', options, { token }, function * () {
      // Get the raw person data from the backend.
      const rawPerson = yield this.service.backend.getPerson(token)
      // Map the raw person structure.
      return this.service._familyMap.map(rawPerson)
    })
  }

  /**
   * Get a passport photo resource for a user.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getPassportPhoto (token) {
    // Build the read operation options.
    const options = {
      // For now, we disable any caching on photo resources (privacy concerns)
      // Can be revisited once performance impact is obvious
      defaultCacheMode: CacheMode.PASSTHROUGH
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getPassportPhoto', options, {}, function * () {
      // Get the photo data from the backend.
      const rawPhoto = yield this.service.backend.getPassportPhoto(token)
      // Map the raw photo data onto a mapped resource.
      return this.service._photoMap.map(rawPhoto)
    })
  }

  /**
   * Get a profile photo resource for a user.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getProfilePhoto (token) {
    // Build the read operation options.
    const options = {
      // For now, we disable any caching on photo resources (privacy concerns)
      // Can be revisited once performance impact is obvious
      defaultCacheMode: CacheMode.PASSTHROUGH
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getProfilePhoto', options, {}, function * () {
      // Get the photo data from the backend.
      const rawPhoto = yield this.service.backend.getProfilePhoto(token)
      // Map the raw photo data onto a mapped resource.
      return this.service._photoMap.map(rawPhoto)
    })
  }

  /**
   * Update a profile photo resource for a user.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   * @param {Object} resource
   *   An object containing either the encoded photo or a reference.
   *
   * @returns {WriteOperation}
   *   An instance of WriteOperation.
   */
  setProfilePhoto (token, resource) {
    // Build the read operation options.
    const options = {
      // For now, we disable any caching on photo resources (privacy concerns)
      // Can be revisited once performance impact is obvious
      defaultCacheMode: CacheMode.PASSTHROUGH
    }
    // Create a read operation for given worker.
    return this.createWriteOperation('setProfilePhoto', options, {}, function * () {
      // Get the photo data from the backend.
      let photo = resource.content
      if (!photo && resource.reference === 'passport') {
        const passportPhoto = yield this.service.getPassportPhoto(token).exec()
        photo = passportPhoto && passportPhoto.content
      }
      yield this.service.backend.setProfilePhoto(token, photo)
      return true
    })
  }

  /**
   * Remove a profile photo resource for a user.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   *
   * @returns {WriteOperation}
   *   An instance of WriteOperation.
   */
  unsetProfilePhoto (token) {
    // Build the read operation options.
    const options = {
      // For now, we disable any caching on photo resources (privacy concerns)
      // Can be revisited once performance impact is obvious
      defaultCacheMode: CacheMode.PASSTHROUGH
    }
    // Create a read operation for given worker.
    return this.createWriteOperation('unsetProfilePhoto', options, {}, function * () {
      // Get the photo data from the backend.
      yield this.service.backend.unsetProfilePhoto(token)
      return true
    })
  }

  /**
   * Get a list of test case groups.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getTestCases () {
    // Build the read operation options.
    const options = {
      cacheExpire: this.config.get('service.person.cacheExpire')
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getPersonTestCases', options, {}, function * () {
      // Get the test cases from the backend.
      const testCases = yield this.service.backend.getTestCases()
      // Map the raw test case data structure onto a list of test case grouped by category.
      return this.service._testCaseDataMap.map(testCases)
    })
  }

}

module.exports = PersonService
