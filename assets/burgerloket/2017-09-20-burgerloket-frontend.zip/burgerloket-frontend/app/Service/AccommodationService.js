'use strict'

const AbstractService = require('./AbstractService')

/**
 * Accommodation data service definition.
 */
class AccommodationService extends AbstractService {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return [
      'Config',
      'Cache',
      'App/Service/Backend/AccommodationBackend',
      'App/Service/DataMap/Accommodation/ResidenceMap',
      'App/Service/DataMap/Accommodation/PropertyMap',
      'App/Service/DataMap/TestCaseMap'
    ]
  }

  /**
   * Create a Service object.
   *
   * @param {Object} config
   *   The application configuration.
   * @param {Cache} cache
   *   The cache layer.
   * @param {AbstractBackend} backend
   *   An instance of AbstractBackend.
   * @param {AbstractDataMap} residenceMap
   *   An instance of AbstractDataMap.
   * @param {AbstractDataMap} propertyMap
   *   An instance of AbstractDataMap.
   * @param {AbstractDataMap} testCaseDataMap
   *   An instance of TestCaseMap.
   */
  constructor (config, cache, backend, residenceMap, propertyMap, testCaseDataMap) {
    // Perform default object creation.
    super(cache, backend)
    // Setup object members.
    this._config = config
    this._residenceMap = residenceMap
    this._propertyMap = propertyMap
    this._testCaseDataMap = testCaseDataMap
  }

  /**
   * {@inheritdoc}
   */
  get name () { return 'accommodation' }

  /**
   * Get the application configuration.
   *
   * @returns {Config}
   *   An instance of Config.
   */
  get config () { return this._config }

  /**
   * Retrieve all residence data for given token.
   *
   * @param {String} token
   *   A unique identifier which represents a user.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getResidence (token) {
    // Build the read operation options.
    const options = {
      cacheExpire: this.config.get('service.accommodation.cacheExpire')
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getResidence', options, { token }, function * () {
      // Get the raw residence data from the backend.
      const rawResidence = yield this.service.backend.getResidence(token)
      // Map the raw residence structure.
      return this.service._residenceMap.map(rawResidence)
    })
  }

  /**
   * Retrieve all property data for given token.
   *
   * @param {String} token
   *   A unique identifier which represents a user.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getProperty (token) {
    // Build the read operation options.
    const options = {
      cacheExpire: this.config.get('service.accommodation.cacheExpire')
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getProperty', options, { token }, function * () {
      // Get the raw residence data from the backend.
      const rawProperty = yield this.service.backend.getProperty(token)
      // Map the raw residence structure.
      return this.service._propertyMap.map(rawProperty)
    })
  }

  /**
   * Get a list of test case groups.
   *
   * @returns {ReadOperation}
   *   An instance of ReadOperation.
   */
  getTestCases () {
    // Build the read operation options.
    const options = {
      cacheExpire: this.config.get('service.accommodation.cacheExpire')
    }
    // Create a read operation for given worker.
    return this.createReadOperation('getAccommodationTestCases', options, {}, function * () {
      // Get the test cases from the backend.
      const testCases = yield this.service.backend.getTestCases()
      // Map the raw test case data structure onto a list of test case grouped by category.
      return this.service._testCaseDataMap.map(testCases)
    })
  }

}

module.exports = AccommodationService
