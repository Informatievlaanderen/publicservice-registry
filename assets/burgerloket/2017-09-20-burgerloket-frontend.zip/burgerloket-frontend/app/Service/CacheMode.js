'use strict'

/**
 * Definition of the allowed cache modes.
 */
module.exports = {

  /**
   * Service cache is ignored and backend will always be invoked.
   *
   * @var {Number}
   */
  PASSTHROUGH: 1,

  /**
   * Service cache is used and backend will never be invoked.
   *
   * @var {Number}
   */
  CACHE_ONLY: 2,

  /**
   * Service cache is used and when data is not available
   * the backend is invoked. (Cache-Aside pattern)
   *
   * @var {Number}
   */
  DEFAULT: 3,

  /**
   * Validate a given cache mode.
   *
   * @param {Number} mode
   *   The cache mode which needs to be validated.
   *
   * @returns {Boolean}
   *   True if cache mode is valid, otherwise false.
   */
  isValid: function (mode) {
    return typeof (mode) === 'number' && mode >= this.PASSTHROUGH && mode <= this.DEFAULT
  },

  /**
   * Determine whether cache can be used.
   *
   * @param {Number} mode
   *   The cache mode which needs to be evaluated.
   *
   * @returns {Boolean}
   *   True if cache can be used, otherwise false.
   */
  isCacheAllowed: function (mode) {
    return this.isValid(mode) && (mode & this.CACHE_ONLY) === this.CACHE_ONLY
  },

  /**
   * Determine whether backend can be used.
   *
   * @param {Number} mode
   *   The cache mode which needs to be evaluated.
   *
   * @returns {Boolean}
   *   True if backend can be used, otherwise false.
   */
  isBackendAllowed: function (mode) {
    return this.isValid(mode) && (mode & this.PASSTHROUGH) === this.PASSTHROUGH
  }

}
