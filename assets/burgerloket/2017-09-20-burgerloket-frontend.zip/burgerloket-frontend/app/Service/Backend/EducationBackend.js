'use strict'

const AbstractBackend = require('./AbstractBackend')

/**
 * Backend which communicates with the Education Rest API.
 */
class EducationBackend extends AbstractBackend {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['Config', 'HttpClient', 'QueryString']
  }

  /**
   * Create a EducationBackend object.
   *
   * @param {Object} config
   *   The application configuration.
   * @param {Object} httpClient
   *   An object which represents the HTTP Client.
   * @param {Object} queryString
   *   An object which provides query string operations.
   */
  constructor (config, httpClient, queryString) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._config = config
    this._httpClient = httpClient
    this._queryString = queryString
  }

  /**
   * Build a request URL for given path.
   *
   * @param {String} path
   *   Path to the Rest API.
   * @param {Object} [queryParams=null]
   *   Optional. An object which contains the query parameters.
   *
   * @returns {String}
   *   An absolute URL which represents the request URL.
   */
  * buildRequestUrl (path, queryParams) {
    // Build the request URL.
    const absoluteUrl = this._config.get('service.education.protocol') + '://' + this._config.get('service.education.domain') + ':' + this._config.get('service.education.port') + this._config.get('service.education.basePath') + path
    // Convert the query params into a query string.
    const queryString = this._queryString.stringify(queryParams || {})
    // Build the request URL and optionally include query string.
    return queryString ? absoluteUrl + '?' + queryString : absoluteUrl
  }

  /**
   * Get a map of test cases by category.
   *
   * @returns {Object}
   *   An object with test cases grouped by category.
   */
  * getTestCases () {
    // Build the request options.
    const options = { Headers: { Accept: 'application/json' } }
    // Build the request URL.
    const url = yield this.buildRequestUrl('api/v1/testdata')
    // Get the education test cases for given url an options.
    const response = yield this._httpClient.get(url, options)

    return response.data
  }

  /**
   * Get a list of education events.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   *
   * @returns {Object[]}
   *   An array of objects which describe the education events.
   */
  * getEvents (token) {
    // Build the request options.
    const options = { Headers: { Accept: 'application/json' } }
    // Build the request URL.
    const url = yield this.buildRequestUrl('api/v1/burgers/' + token + '/onderwijsgebeurtenissen')
    // Get the education events for given url and options.
    const response = yield this._httpClient.get(url, options)

    return response.data
  }

  /**
   * Get the dashboard status.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   *
   * @returns {Object}
   *   An object which describes the dashaboard status.
   */
  * getDashboardStatus (token) {
    // Build the request options.
    const options = { Headers: { Accept: 'application/json' } }
    // Build the request URL.
    const url = yield this.buildRequestUrl('api/v1/burgers/' + token + '/beschikbaarheid')
    // Get the dashboard status for given url and options.
    const response = yield this._httpClient.get(url, options)

    return response.data
  }

}

module.exports = EducationBackend
