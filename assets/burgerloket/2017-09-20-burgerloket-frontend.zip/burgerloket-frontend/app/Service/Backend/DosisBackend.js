'use strict'

const AbstractBackend = require('./AbstractBackend')

/**
 * Backend which communicates with the Dosis Rest API.
 */
class DosisBackend extends AbstractBackend {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['Config', 'HttpClient', 'QueryString']
  }

  /**
   * Create a DosisRestApi object.
   *
   * @param {Object} config
   *   The application configuration.
   * @param {Object} httpClient
   *   An object which represents the HTTP Client.
   * @param {Object} queryString
   *   An object which provides query string operations.
   */
  constructor (config, httpClient, queryString) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._config = config
    this._httpClient = httpClient
    this._queryString = queryString
  }

  /**
   * Build a request URL for given path.
   *
   * @param {String} path
   *   Path to the Rest API.
   * @param {Object} [queryParams=null]
   *   Optional. An object which contains the query parameters.
   *
   * @returns {String}
   *   An absolute URL which represents the request URL.
   */
  * buildRequestUrl (path, queryParams) {
    // Build the request URL.
    const absoluteUrl = this._config.get('service.dosis.protocol') + '://' + this._config.get('service.dosis.domain') + ':' + this._config.get('service.dosis.port') + this._config.get('service.dosis.basePath') + path
    // Convert the query params into a query string.
    const queryString = this._queryString.stringify(queryParams || {})
    // Build the request URL and optionally include query string.
    return queryString ? absoluteUrl + '?' + queryString : absoluteUrl
  }

  /**
   * Get a list of files for given token and language.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   * @param {Number} offset
   *   Offset in the data set.
   * @param {Number} size
   *   Maximum number of items to retrieve in a single data set.
   * @param {Boolean} includeHistory
   *   Flag which indicates whether history should be included.
   * @param {String} language
   *   Language for which the labels should be included.
   *
   * @returns {Object[]}
   *   An array of Dosis file objects.
   */
  * getFiles (token, offset, limit, includeHistory, language) {
    // Build the request options.
    const options = { Headers: { Accept: 'application/json', 'Accept-Language': language || 'en' } }
    // Build the request URL.
    const url = yield this.buildRequestUrl('api/ws/dosis/v1/dossiers/rijksregisternummer/' + token, {
      metHistoriek: includeHistory,
      offset: offset,
      limit: limit
    })

    // Get the Dosis files for given url and options.
    const response = yield this._httpClient.get(url, options)
    // Extract the data from the response.
    return response.data
  }

}

module.exports = DosisBackend
