'use strict'

/**
 * Abstract definition of service backend.
 */
class AbstractBackend {}

module.exports = AbstractBackend
