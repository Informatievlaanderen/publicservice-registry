'use strict'

const AbstractBackend = require('./AbstractBackend')

/**
 * Backend which communicates with the Profile Rest API.
 */
class ProfileBackend extends AbstractBackend {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['Config', 'HttpClient', 'QueryString']
  }

  /**
   * Create a DosisRestApi object.
   *
   * @param {Object} config
   *   The application configuration.
   * @param {Object} httpClient
   *   An object which represents the HTTP Client.
   * @param {Object} queryString
   *   An object which provides query string operations.
   */
  constructor (config, httpClient, queryString) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._config = config
    this._httpClient = httpClient
    this._queryString = queryString
  }

  /**
   * Build a request URL for given path.
   *
   * @param {String} path
   *   Path to the Rest API.
   * @param {Object} [queryParams=null]
   *   Optional. An object which contains the query parameters.
   *
   * @returns {String}
   *   An absolute URL which represents the request URL.
   */
  * buildRequestUrl (path, queryParams) {
    // Build the request URL.
    const absoluteUrl = this._config.get('service.profile.protocol') + '://' + this._config.get('service.profile.domain') + ':' + this._config.get('service.profile.port') + this._config.get('service.profile.basePath') + path
    // Convert the query params into a query string.
    const queryString = this._queryString.stringify(queryParams || {})
    // Build the request URL and optionally include query string.
    return queryString ? absoluteUrl + '?' + queryString : absoluteUrl
  }

  /**
   * Create the profile for given token.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   * @param {Object} profile
   *   An object which represents a profile.
   *
   * @returns {Object}
   *   An object which represents the create profile.
   */
  * createProfile (token, profile) {
    // Build the request options.
    const options = { Headers: { Accept: 'application/json', 'Content-Type': 'application/json' } }
    // Build the request URL.
    const url = yield this.buildRequestUrl('api/v1/burgers/' + token)
    // Get the profile for given URL and options.
    const response = yield this._httpClient.post(url, profile, options)

    return response.data
  }

  /**
   * Get the profile information for given token.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   *
   * @returns {Object}
   *   An object which contains the profile related information.
   */
  * getProfile (token) {
    // Build the request options.
    const options = { Headers: { Accept: 'application/json' } }
    // Build the request URL.
    const url = yield this.buildRequestUrl('api/v1/burgers/' + token)
    // Initialize variable to null as default behavior.
    let response = null

    try {
      // Get the profile for given URL and options.
      response = yield this._httpClient.get(url, options)
    } catch (error) {
      // Check whether error is not related to no profile being available.
      if (error.response.status !== 404) {
        // Rethrow the error as it is not in the range of valid response
        // status codes.
        throw error
      }
    }

    return response ? response.data : null
  }

  /**
   * Update the profile for given token.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   * @param {Object} profile
   *   An object which represents a profile.
   *
   * @returns {Boolean}
   *   True if profile was updated, otherwise false.
   */
  * updateProfile (token, profile) {
    // Build the request options.
    const options = { Headers: { Accept: 'application/json', 'Content-Type': 'application/json' } }
    // Build the request URL.
    const url = yield this.buildRequestUrl('api/v1/burgers/' + token)
    // Get the profile for given URL and options.
    const response = yield this._httpClient.put(url, profile, options)

    console.log(profile)

    return response.data
  }

  /**
   * Delete the profile for given token.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   *
   * @returns {Boolean}
   *   True if profile was removed, otherwise false.
   */
  * deleteProfile (token) {
    // Build the request URL.
    const url = yield this.buildRequestUrl('api/v1/burgers/' + token)
    // Get the profile for given URL and options.
    yield this._httpClient.delete(url)

    return true
  }

}

module.exports = ProfileBackend
