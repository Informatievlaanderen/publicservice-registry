'use strict'

const AbstractBackend = require('./AbstractBackend')

/**
 * Backend which communicates with the Tax/benefits (belastingen & voordelen) Rest API.
 */
class TaxBackend extends AbstractBackend {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['Config', 'HttpClient', 'QueryString']
  }

  /**
   * Create a Tax backend object.
   *
   * @param {Object} config
   *   The application configuration.
   * @param {Object} httpClient
   *   An object which represents the HTTP Client.
   * @param {Object} queryString
   *   An object which provides query string operations.
   */
  constructor (config, httpClient, queryString) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._config = config
    this._httpClient = httpClient
    this._queryString = queryString
  }

  /**
   * Build a request URL for given path.
   *
   * @param {String} path
   *   Path to the Rest API.
   * @param {Object} [queryParams=null]
   *   Optional. An object which contains the query parameters.
   *
   * @returns {String}
   *   An absolute URL which represents the request URL.
   */
  * buildRequestUrl (path, queryParams) {
    // Build the request URL.
    const absoluteUrl = this._config.get('service.tax.protocol') + '://' + this._config.get('service.tax.domain') + ':' + this._config.get('service.tax.port') + this._config.get('service.tax.basePath') + path
    // Convert the query params into a query string.
    const queryString = this._queryString.stringify(queryParams || {})
    // Build the request URL and optionally include query string.
    return queryString ? absoluteUrl + '?' + queryString : absoluteUrl
  }

  /**
   * Get the assistance data for given token.
   *
   * @param {String} token
   *   A unique identifier which represents a user.
   *
   * @returns {Object}
   *   An object containing assistance data known about the user.
   */
  * getAssistance (token, offset, limit, includeHistory, language) {
    // Build the request options.
    const options = { Headers: { Accept: 'application/json', 'Accept-Language': language || 'en' } }
    // Build the request URL.
    const url = yield this.buildRequestUrl(`api/v1/burgers/${token}/rechtondersteuningen`)

    // Get the residence data from given url and options.
    const response = yield this._httpClient.get(url, options)
    // Extract the data from the response.
    return response.data
  }

  /**
   * Get the career breaks data for given token.
   *
   * @param {String} token
   *   A unique identifier which represents a user.
   *
   * @returns {Object}
   *   An object containing assistance data known about the user.
   */
  * getCareerBreaks (token, offset, limit, includeHistory, language) {
    // Build the request options.
    const options = { Headers: { Accept: 'application/json', 'Accept-Language': language || 'en' } }
    // Build the request URL.
    const url = yield this.buildRequestUrl(`api/v1/burgers/${token}/loopbaanonderbrekingen`)

    // Get the residence data from given url and options.
    const response = yield this._httpClient.get(url, options)
    // Extract the data from the response.
    return response.data
  }

  /**
   * Get a map of test cases by category.
   *
   * @returns {Object}
   *   An object with test cases grouped by category.
   */
  * getTestCases () {
    // Build the request options.
    const options = { Headers: { Accept: 'application/json' } }
    // Build the request URL.
    const url = yield this.buildRequestUrl('api/v1/testdata')
    // Get the tax test cases for given url an options.
    const response = yield this._httpClient.get(url, options)

    return response.data
  }

}

module.exports = TaxBackend
