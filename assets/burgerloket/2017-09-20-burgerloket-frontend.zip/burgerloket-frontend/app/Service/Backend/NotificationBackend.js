'use strict'

const AbstractBackend = require('./AbstractBackend')

/**
 * Backend which communicates with the Notification Rest API.
 */
class NotificationBackend extends AbstractBackend {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['Config', 'HttpClient', 'QueryString']
  }

  /**
   * Create a DosisRestApi object.
   *
   * @param {Object} config
   *   The application configuration.
   * @param {Object} httpClient
   *   An object which represents the HTTP Client.
   * @param {Object} queryString
   *   An object which provides query string operations.
   */
  constructor (config, httpClient, queryString) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._config = config
    this._httpClient = httpClient
    this._queryString = queryString
  }

  /**
   * Build a request URL for given path.
   *
   * @param {String} path
   *   Path to the Rest API.
   * @param {Object} [queryParams=null]
   *   Optional. An object which contains the query parameters.
   *
   * @returns {String}
   *   An absolute URL which represents the request URL.
   */
  * buildRequestUrl (path, queryParams) {
    // Build the request URL.
    const absoluteUrl = this._config.get('service.notification.protocol') + '://' + this._config.get('service.notification.domain') + ':' + this._config.get('service.notification.port') + this._config.get('service.notification.basePath') + path
    // Convert the query params into a query string.
    const queryString = this._queryString.stringify(queryParams || {})
    // Build the request URL and optionally include query string.
    return queryString ? absoluteUrl + '?' + queryString : absoluteUrl
  }

  /**
   * Get a list of notifications for given token.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   *
   * @returns {Object[]}
   *   An array of notification objects.
   */
  * getNotifications (token) {
    // Build the request options.
    const options = { Headers: { Accept: 'application/json' } }
    // Build the request URL.
    const url = yield this.buildRequestUrl('api/ws/notificatie/v1/notificaties', {
      agent: token
    })

    // Get the notifications for given url and options.
    const response = yield this._httpClient.get(url, options)

    // Extract the data from the response.
    return response.data.filter(isPassiveNotification)
  }

  /**
   * Mark a notification for given ID as read.
   *
   * @param {String} token
   *   A unique identifier which represents a person.
   * @param {String} id
   *   A unique identifier which represents a notification ID.
   *
   * @returns {Boolean}
   *   True if operation was successful, otherwise false.
   */
  * markNotificationAsRead (token, id) {
    // Build the request URL for given notification ID.
    const url = yield this.buildRequestUrl('api/ws/notificatie/v1/notificaties/markeergelezen', {
      notificatieId: id
    })

    // Post the notification data.
    const response = yield this._httpClient.post(url)
    // Determine whether the operation was successful.
    return response.status === 200
  }

}

function isPassiveNotification (notification) {
  if (!notification || !notification.Kanalen) return false
  return notification.Kanalen.some((channel) => channel.Type === 'Passief')
}

module.exports = NotificationBackend
