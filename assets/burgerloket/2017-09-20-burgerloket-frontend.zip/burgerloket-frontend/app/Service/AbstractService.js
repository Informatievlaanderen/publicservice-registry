'use strict'

const ServiceReadOperation = require('./Operation/ReadOperation')
const ServiceWriteOperation = require('./Operation/WriteOperation')

/**
 * Abstract definition of a service.
 */
class AbstractService {

  /**
   * Create an AbstractService object.
   *
   * @param {Cache} cache
   *   The cache layer.
   * @param {AbstractBackend} backend
   *   An object which represents the service backend.
   */
  constructor (cache, backend) {
    // Setup object members.
    this._cache = cache
    this._backend = backend
  }

  /**
   * Get the cache layer.
   *
   * @returns {Cache}
   *   An instance of Cache.
   */
  get cache () { return this._cache }

  /**
   * Get the service backend.
   *
   * @returns {AbstractBackend}
   *   An instance of AbstractBackend.
   */
  get backend () { return this._backend }

  /**
   * Get the service name.
   *
   * @returns {String}
   *   Name of the service.
   */
  get name () { throw new Error('Not implemented') }

  /**
   * Create a service read operation.
   *
   * @param {String} operation
   *   Name of the operation.
   * @param {Object} options
   *   An object which contains the operation options.
   * @param {Object} args
   *   An object which holds the worker arguments.
   * @param {Generator} worker
   *   A generator function which performs the actual
   *   read operation.
   *
   * @returns {ServiceReadOperation}
   *   An instance of ServiceReadOperation.
   */
  createReadOperation (operation, options, args, worker) {
    return new ServiceReadOperation(this, operation, options, args, worker)
  }

  /**
   * Create a write operation.
   *
   * @param {String} operation
   *   Name of the operation.
   * @param {Object} options
   *   An object which contains the operation options.
   * @param {Object} args
   *   An object which holds the worker arguments.
   * @param {Generator} worker
   *   A generator function which performs the actual
   *   write operation.
   *
   * @returns {ServiceWriteOperation}
   *   An instance of ServiceWriteOperation.
   */
  createWriteOperation (operation, options, args, worker) {
    return new ServiceWriteOperation(this, operation, options, args, worker)
  }

}

module.exports = AbstractService
