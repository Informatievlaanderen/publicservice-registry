'use strict'

const AbstractDataMap = require('../AbstractDataMap')

/**
 * Map data related to person family data structures.
 */
class FamilyMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return [
      'App/Service/DataMap/Person/ParticularsMap',
      'App/Service/DataMap/Common/AddressDataMap'
    ]
  }

  /**
   * Create a DescentMap object.
   *
   * @param {ParticularsMap} particularsMap
   *   An instance of ParticularsMap.
   * @param {AddressDataMap} addressMap
   *   An instance of AddressDataMap.
   */
  constructor (particularsMap, addressMap) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._particularsMap = particularsMap
    this._addressMap = addressMap
  }

  /**
   * {@inheritdoc}
   */
  map (obj) {
    if (!obj) return null
    const incompleteData = this.mapIncompleteData(obj.redenGezinOntbreekt)
    if (!obj.isHoofdVan && !obj.isLidVan) return { incompleteData }

    const gezin = obj.isHoofdVan || obj.isLidVan
    const address = this._addressMap.map(gezin.gezinAdres)
    const accommodation = this.mapAccommodation(gezin.woonvorm)

    const persons = this.collectPersons(obj)
    const relations = this.collectRelations(obj)
    const self = persons[obj['@id']]
    let { reference, family } = this.mapFamily(gezin, persons, relations)

    family = family.reduce(this.groupFamily, [[], [], []])

    if (obj.isHoofdVan && !reference) {
      reference = self
    }
    reference.relation = gezin.typeHoofd.naam

    return {
      address, accommodation, reference, family, incompleteData
    }
  }

  /**
   * Map a 'woonvorm' object (backend) onto an accommodation object (api).
   *
   * @param {Object} woonvorm
   *   An object as returned by backend in 'gezin.woonvorm'
   *
   * @returns {String}
   *   The mapped accommodation name
   */
  mapAccommodation (woonvorm) {
    return woonvorm ? woonvorm.naam : null
  }

  /**
   * Map a 'redenGezinOntbreekt' object (backend) onto an incompleteData object (api).
   *
   * @param {Object} redenGezinOntbreekt
   *   An object as returned by backend in 'redenGezinOntbreekt'
   *
   * @returns {Object}
   *   An object that represents the mapped reason
   */
  mapIncompleteData (reden) {
    if (reden && reden.soortReden) {
      return reden.soortReden.naam
    }
    return undefined
  }

  /**
   * Map a 'gezin' object (backend) with relations onto a reference object and list of members.
   *
   * @param {Object} gezin
   *   An object as returned by backend in 'gezin'
   * @param {Object} persons
   *   A key/value store of persons indexed by id, as returned by #collectPersons
   * @param {Object} relations
   *   A key/value store of relations indexed by id, as returned by #collectRelations
   *
   * @returns {Object}
   *   The combination of the reference person in the family (if defined) and
   *   an array of all members (with their relation to reference)
   */
  mapFamily (gezin, persons, relations) {
    if (!gezin || !gezin['@reverse']) return { reference: null, family: [] }
    const references = gezin['@reverse'].isHoofdVan || []
    const members = gezin['@reverse'].isLidVan || []
    const reference = this.mapArray(references, this.mapFamilyMember, persons, relations)[0] || null
    const family = this.mapArray(members, this.mapFamilyMember, persons, relations)
    return { reference, family }
  }

  groupFamily ([partners, related, unrelated], member) {
    if (member.relation === 'echtgenoot' || member.relation === 'echtgenote') {
      partners.push(member)
    } else if (!member.relation) {
      unrelated.push(member)
    } else {
      related.push(member)
    }
    return [partners, related, unrelated]
  }

  /**
   * Map a person reference (with id and given relations/persons) on a family member object.
   *
   * @param {Object} personRef
   *   An object containing a person id
   * @param {Object} persons
   *   A key/value store of persons indexed by id, as returned by #collectPersons
   * @param {Object} relations
   *   A key/value store of relations indexed by id, as returned by #collectRelations
   *
   * @returns {Object}
   *   A family member object (a simplified person object with a relation)
   */
  mapFamilyMember (personRef, persons, relations) {
    if (!personRef) return null
    const id = personRef['@id']
    const person = persons[id]
    const relation = relations[id]

    if (!person) return null
    const member = Object.assign({}, person, { gender: undefined })
    if (relation) {
      member.relation = this.mapFamilyRelation(person, relation)
    }
    return member
  }

  /**
   * Map a 'persoon' object (backend) onto a simplified person object (api).
   *
   * @param {Object} persoon
   *   An object as returned by backend in root (uzelf) or in 'gerelateerdePersonen'
   *
   * @returns {Object}
   *   An object that represents the mapped person
   */
  mapParticulars (persoon) {
    const {
      firstNames, preferredFirstName, lastNames, gender, nationalId
    } = this._particularsMap.map(persoon)
    // @todo(adriaan): Map this once we have picture backend
    const photo = {
      url: 'http://via.placeholder.com/200/ffe615/b2b2b2.jpg?text=pasfoto',
      type: 'image/jpeg',
      width: 200,
      height: 200
    }
    return { firstNames, preferredFirstName, lastNames, gender, nationalId, photo }
  }

  /**
   * Convert a relation object and the related person into a relation string.
   *
   * @param {Object} person
   *   A person with a gender
   * @param {Object} relation
   *   A relation object with a code
   *
   * @returns {Object}
   *   A family member object (a simplified person object with a relation)
   */
  mapFamilyRelation (person, relation) {
    if (!person || !relation) return null
    const male = person.gender !== 'Vrouwelijk'
    // See http://www.ibz.rrn.fgov.be/fileadmin/user_upload/nl/rr/instructies/IT-lijst/IT141_Gezinslid.pdf
    switch (relation.code) {
      case '01': return 'referentiepersoon'
      case '02': return male ? 'echtgenoot' : 'echtgenote'
      case '03': return male ? 'zoon' : 'dochter'
      case '04': return male ? 'schoonzoon' : 'schoondochter'
      case '05': return male ? 'kleinzoon' : 'kleindochter'
      case '06': return male ? 'vader' : 'moeder'
      case '07': return male ? 'schoonvader' : 'schoonmoeder'
      case '08': return male ? 'grootvader' : 'grootmoeder'
      case '09': return male ? 'broer' : 'zus'
      case '10': return male ? 'schoonbroer' : 'schoonzus'
      case '11': return 'verwante'
      case '12': return null // niet verwant
      case '13': return male ? 'stiefzoon' : 'stiefdochter'
      case '14': return male ? 'achterkleinzoon' : 'achterkleindochter'
      case '15': return male ? 'oom' : 'tante'
      case '16': return male ? 'neef' : 'nicht'
      case '17': return male ? 'neef' : 'nicht'
      default: return null
    }
  }

  /**
   * Collect all related persons (including self) in a map by id.
   *
   * @param {Object} obj
   *   An object as returned by backend in root (uzelf)
   *
   * @returns {Object}
   *   An object that serves as a key/value map with the mapped particulars keyed by person id
   */
  collectPersons (obj) {
    const personen = [obj].concat(obj.gerelateerdePersonen || [])
    return personen.reduce((persons, persoon) => {
      const id = persoon['@id']
      const person = this.mapParticulars(persoon)
      if (id === obj['@id']) {
        person.self = true
      }
      persons[id] = person
      return persons
    }, {})
  }

  /**
   * Collect all relations in a map by id.
   *
   * @param {Object} obj
   *   An object as returned by backend in root (uzelf)
   *
   * @returns {Object}
   *   An object that serves as a key/value map with the mapped particulars keyed by person id
   */
  collectRelations (obj) {
    const relaties = obj.heeftRelatieMet || []
    return relaties
      .filter(isFamilyRelation)
      .reduce((relations, relatie) => {
        const id = relatie['@id']
        relations[id] = { code: relatie.soortGezinsRelatie.code }
        return relations
      }, {})
  }
}

function isFamilyRelation (relatie) {
  return relatie && relatie['@type'] === 'Gezinsrelatie'
}

module.exports = FamilyMap

