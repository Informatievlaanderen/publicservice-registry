'use strict'

const AbstractDataMap = require('../AbstractDataMap')

/**
 * Map data related to a passport/profile photo.
 */
class PhotoMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return [
      'App/Service/DataMap/Common/DateTimeDataMap'
    ]
  }

  /**
   * Create a PhotoMap object.
   *
   * @param {DateTimeDataMap} dateTimeDataMap
   *   An instance of DateTimeDataMap.
   */
  constructor (dateTimeDataMap) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._dateTimeDataMap = dateTimeDataMap
  }

  /**
   * {@inheritdoc}
   */
  map (obj) {
    if (!obj || !obj.foto) return null

    const content = obj.foto
    const contentType = obj['Content-Type']
    const meta = {
      width: obj.breedte || null,
      height: obj.hoogte || null,
      date: this._dateTimeDataMap.map(obj.datum)
    }

    return {
      content, contentType, meta
    }
  }

}

module.exports = PhotoMap
