'use strict'

const AbstractDataMap = require('../AbstractDataMap')
const moment = require('moment')

/**
 * Map data related to particulars (uzelf) data structures.
 */
class ParticularsMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return [
      'Config',
      'App/Service/DataMap/Common/AddressDataMap',
      'App/Service/DataMap/Common/DateTimeDataMap',
      'App/Service/DataMap/Common/ApplicationReferenceDataMap'
    ]
  }

  /**
   * Create an ParticularsMap object.
   *
   * @param {Object} config
   *   The application configuration.
   * @param {AddressDataMap} addressDataMap
   *   An instance of AddressDataMap.
   * @param {DateTimeDataMap} dateTimeDataMap
   *   An instance of DateTimeDataMap.
    @param {ApplicationReferenceDataMap} referenceMap
   *   An instance of ApplicationReferenceDataMap.
   */
  constructor (config, addressDataMap, dateTimeDataMap, referenceDataMap) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._config = config
    this._addressDataMap = addressDataMap
    this._dateTimeDataMap = dateTimeDataMap
    this._referenceDataMap = referenceDataMap
  }

  /**
   * {@inheritdoc}
   */
  map (obj) {
    if (!obj) return null
    const birth = this.mapBirth(obj.heeftGeboorte)
    const death = this.mapDeath(obj.heeftOverlijden)
    return {
      firstNames: obj.voornaam,
      preferredFirstName: obj.gebruikteVoornaam,
      lastNames: obj.achternaam,
      birthDate: birth.birthDate,
      birthPlace: birth.birthPlace,
      deathDate: death.deathDate,
      deathPlace: death.deathPlace,
      gender: obj.geslacht && obj.geslacht.naam,
      nationalities: obj.heeftNationaliteit && this.mapArray(obj.heeftNationaliteit, this.mapNationality, birth.birthDate),
      identification: this.mapIdentification(obj.identiteitsbewijs),
      nationalId: this.mapNationalId(obj.registratie && obj.registratie.identificator),
      registry: obj.ingeschrevenInRegister && obj.ingeschrevenInRegister.soort && obj.ingeschrevenInRegister.soort.naam,
      administration: this._addressDataMap.map(obj.beheerder && obj.beheerder.plaats),
      civilStatus: this.mapCivilStatus(obj.burgerlijkeStaat, birth.birthDate, obj.heeftRelatieMet, obj.gerelateerdePersonen),
      urlNationalRegister: this._referenceDataMap.map(obj.urlRijksregister)
    }
  }

  /**
   * Map a 'heeftGeboorte' object (backend) onto a birth object (api).
   *
   * @param {Object} geboorte
   *   An object as returned by backend in 'heeftGeboorte'
   *
   * @returns {Object}
   *   An object that represents the mapped birth properties
   */
  mapBirth (geboorte) {
    let birthDate = null
    let birthPlace = null
    if (geboorte) {
      birthDate = this._dateTimeDataMap.map(geboorte.datum)
      birthPlace = this._addressDataMap.map(geboorte.plaats)
    }
    return { birthDate, birthPlace }
  }

  /**
   * Map a 'heeftOverlijden' object (backend) onto a death object (api).
   *
   * @param {Object} overlijden
   *   An object as returned by backend in 'heeftOverlijden'
   *
   * @returns {Object}
   *   An object that represents the mapped death properties
   */
  mapDeath (geboorte) {
    let deathDate = null
    let deathPlace = null
    if (geboorte) {
      deathDate = this._dateTimeDataMap.map(geboorte.datum)
      deathPlace = this._addressDataMap.map(geboorte.plaats)
    }
    return { deathDate, deathPlace }
  }

  /**
   * Map a 'nationaliteit' object (backend) onto a nationality object (api).
   *
   * @param {Object} nationaliteit
   *   An object as returned by backend in 'heeftNationaliteit'
   * @param {Object} birthDate
   *   The mapped birthDate object (to check whether a nationality start date should be ignored)
   *
   * @returns {Object}
   *   An object that represents the mapped nationality properties
   */
  mapNationality (nationaliteit, birthDate) {
    if (!nationaliteit) return null

    let since = this._dateTimeDataMap.map(nationaliteit.datumBegin)
    if (since && birthDate && since.value === birthDate.value) {
      since = null
    }

    return {
      name: nationaliteit.naam,
      code: nationaliteit.code ? Number(nationaliteit.code) : null,
      since
    }
  }

  /**
   * Map a 'identiteitsbewijs' object (backend) onto an identification object (api).
   *
   * @param {Object} identiteitsbewijs
   *   An object as returned by backend in 'identiteitsbewijs'
   *
   * @returns {Object}
   *   An object that represents the mapped identification properties
   */
  mapIdentification (identiteitsbewijs) {
    if (!identiteitsbewijs) return null

    const idFormat = /^(\S{3})(\S{7})(\S{2})$/
    let id = identiteitsbewijs.nummerBewijs
    if (idFormat.test(id)) id = id.replace(idFormat, '$1-$2-$3')

    const expires = this._dateTimeDataMap.map(identiteitsbewijs.vervalDatum)
    let expiresWarning = false

    if (expires) {
      const monthsUntilExpires = moment(expires.value).diff(moment(), 'months')
      const threshold = this._config.get('service.person.warnMonthsUntilExpires')
      expiresWarning = monthsUntilExpires < threshold
    }
    return { id, expires, expiresWarning }
  }

  /**
   * Map a 'rijksregisternummer' (backend) onto a nationalId object (api).
   *
   * @param {Object} identiteitsbewijs
   *   An object as returned by backend in 'identiteitsbewijs'
   *
   * @returns {Object}
   *   An object that represents the mapped identification properties
   */
  mapNationalId (rrn) {
    if (!rrn) return null

    const rrnFormat = /^(\S{2})(\S{2})(\S{2})(\S{3})(\S{2})$/
    if (rrnFormat.test(rrn)) rrn = rrn.replace(rrnFormat, '$1.$2.$3-$4.$5')

    return rrn
  }

  /**
   * Map a 'burgerlijkeStaat' object (backend) onto a civilStatus object (api).
   *
   * @param {Object} burgerlijkeStaat
   *   An object as returned by backend in 'burgerlijkeStaat'
   * @param {Object} birthDate
   *   The mapped birthDate object (to check whether a nationality start date should be ignored)
   * @param {Object[]} relaties
   *   An array as returned by backend in 'heeftRelatieMet'
   * @param {Object[]} gerelateerdePersonen
   *   An array as returned by backend in 'gerelateerdePersonen'
   *
   * @returns {Object[]}
   *   An object that represents the mapped civil status properties
   */
  mapCivilStatus (burgerlijkeStaat, birthDate, relaties, gerelateerdePersonen) {
    // @todo(adriaan): Traversing relations is something that will be refined
    // for afstamming and gezin; when that's fully implemented, refactor this.
    if (!burgerlijkeStaat) return null
    relaties = relaties || []
    gerelateerdePersonen = gerelateerdePersonen || []

    const mainStatus = {
      label: burgerlijkeStaat.soortBurgerlijkeStaat.naam,
      since: this._dateTimeDataMap.map(burgerlijkeStaat.datumBegin),
      location: this._addressDataMap.map(burgerlijkeStaat.plaats),
      partner: null
    }
    // For marriages, we want to overwrite the civil status object
    relaties.filter(isMarriage).forEach((relatie) =>
      Object.assign(mainStatus, this.mapPartnership(relatie, gerelateerdePersonen))
    )
    const statuses = [ mainStatus ].concat(
      relaties.filter(isCohabitation).map((relatie) => {
        const partnership = this.mapPartnership(relatie, gerelateerdePersonen)
        partnership.label = 'wettelijk samenwonend'
        return partnership
      })
    )
    statuses.forEach((status) => {
      if (status.since && birthDate && status.since.value === birthDate.value) {
        status.since = null
      }
    })
    return statuses
  }

  /**
   * Map a 'relatie' object and its associated `gerelateerdePersoon` (backend) onto partnership object (api).
   *
   * @param {Object} relatie
   *   An object as returned by backend in 'heeftRelatieMet'
   * @param {Object[]} gerelateerdePersonen
   *   An array as returned by backend in 'gerelateerdePersonen'
   *
   * @returns {Object}
   *   An object that represents the mapped partnership
   */
  mapPartnership (relatie, gerelateerdePersonen) {
    const partnerPersoon = gerelateerdePersonen.filter(persoon => persoon['@id'] === relatie['@id'])[0]
    const { firstNames, preferredFirstName, lastNames } = this.map(partnerPersoon)
    return {
      since: this._dateTimeDataMap.map(relatie.datumBegin),
      location: this._addressDataMap.map(relatie.plaats),
      partner: { firstNames, preferredFirstName, lastNames }
    }
  }
}

function isMarriage (relatie) {
  return relatie && relatie['@type'] === 'Huwelijk'
}

function isCohabitation (relatie) {
  return relatie && relatie['@type'] === 'Samenwonen'
}

module.exports = ParticularsMap

