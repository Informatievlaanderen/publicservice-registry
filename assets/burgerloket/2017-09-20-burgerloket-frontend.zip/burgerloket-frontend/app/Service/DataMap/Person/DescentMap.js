'use strict'

const AbstractDataMap = require('../AbstractDataMap')

/**
 * Map data related to person descent data structures.
 */
class DescentMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return [
      'App/Service/DataMap/Person/ParticularsMap'
    ]
  }

  /**
   * Create a DescentMap object.
   *
   * @param {ParticularsMap} particularsDataMap
   *   An instance of ParticularsMap.
   */
  constructor (particularsMap) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._particularsMap = particularsMap
  }

  /**
   * {@inheritdoc}
   */
  map (obj) {
    if (!obj) return null
    const self = this.mapParticulars(obj)
    const { parents, children } = this.mapRelations(obj.heeftRelatieMet, obj.gerelateerdePersonen)
    return {
      self,
      parents,
      children,
      incompleteData: this.mapIncompleteData(obj.redenAfstammingOnvolledig)
    }
  }

  /**
   * Map a 'persoon' object (backend) onto a simplified person object (api).
   *
   * @param {Object} persoon
   *   An object as returned by backend in root (uzelf) or in 'gerelateerdePersonen'
   *
   * @returns {Object}
   *   An object that represents the mapped person
   */
  mapParticulars (persoon) {
    const {
      firstNames, preferredFirstName, lastNames, birthDate, deathDate, nationalId
    } = this._particularsMap.map(persoon)
    // @todo(adriaan): Map this once we have picture backend
    const photo = {
      url: 'http://via.placeholder.com/200/ffe615/b2b2b2.jpg?text=pasfoto',
      type: 'image/jpeg',
      width: 200,
      height: 200
    }
    return { firstNames, preferredFirstName, lastNames, birthDate, deathDate, nationalId, photo }
  }

  /**
   * Map a 'heeftRelatieMet' array (backend) onto an object with parent/children lists (api).
   *
   * @param {Object[]} relaties
   *   An array as returned by backend in 'heeftRelatieMet'
   * @param {Object[]} gerelateerdePersonen
   *   An array as returned by backend in 'gerelateerdePersonen'
   *
   * @returns {Object}
   *   An object that represents the mapped civil status properties
   */
  mapRelations (relaties, gerelateerdePersonen) {
    // @todo(adriaan): Use separate mapper for relations (reusable for particulars and family)
    relaties = relaties || []
    gerelateerdePersonen = gerelateerdePersonen || []

    return relaties.filter(relatie => isDescentRelation(relatie))
      .reduce((result, relatie) => {
        const personId = relatie['@id']
        const persoon = gerelateerdePersonen.filter(persoon => persoon['@id'] === personId)[0]
        if (persoon) {
          if (isParentRelation(relatie)) {
            result.parents.push(this.mapParent(persoon, relatie))
          } else if (isChildRelation(relatie)) {
            result.children.push(this.mapChild(persoon, relatie))
          }
        }
        return result
      }, { parents: [], children: [] })
  }

  /**
   * Map a persoon object with 'ouder' relation (backend) onto a parent object (api).
   *
   * @param {Object} ouder
   *   A persoon object as returned by backend in 'gerelateerdePersonen'
   * @param {Object} relatie
   *   A relatie object as returned by backend in 'heeftRelatieMet'
   *
   * @returns {Object}
   *   An object that represents the mapped parent object
   */
  mapParent (ouder, relatie) {
    const parent = this.mapParticulars(ouder)
    parent.relation = 'parent'
    if (ouder.geslacht) {
      if (ouder.geslacht.code === '1') {
        parent.relation = 'father'
      } else if (ouder.geslacht.code === '2') {
        parent.relation = 'mother'
      }
    }
    return parent
  }

  /**
   * Map a persoon object with 'kind' relation (backend) onto a child object (api).
   *
   * @param {Object} kind
   *   A persoon object as returned by backend in 'gerelateerdePersonen'
   * @param {Object} relatie
   *   A relatie object as returned by backend in 'heeftRelatieMet'
   *
   * @returns {Object}
   *   An object that represents the mapped child object
   */
  mapChild (kind, relatie) {
    const child = this.mapParticulars(kind)
    child.relation = 'child'
    if (kind.geslacht) {
      if (kind.geslacht.code === '1') {
        child.relation = 'son'
      } else if (kind.geslacht.code === '2') {
        child.relation = 'daughter'
      }
    }
    return child
  }

  /**
   * Map a 'redenAfstammingOnvolledig' object (backend) onto an incompleteData object (api).
   *
   * @param {Object} redenAfstammingOnvolledig
   *   An object as returned by backend in 'redenAfstammingOnvolledig'
   *
   * @returns {Object}
   *   An object that represents the mapped reason
   */
  mapIncompleteData (reden) {
    if (reden && reden.soortReden.code !== '0') {
      return reden.soortReden.naam
    }
    return undefined
  }

}

function isDescentRelation (relatie) {
  return relatie && relatie['@type'] === 'Afstamming'
}

function isParentRelation (relatie) {
  return isDescentRelation(relatie) && relatie.typeAfstamming && relatie.typeAfstamming.code === '1'
}

function isChildRelation (relatie) {
  return isDescentRelation(relatie) && relatie.typeAfstamming && relatie.typeAfstamming.code === '0'
}

module.exports = DescentMap

