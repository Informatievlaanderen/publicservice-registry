'use strict'

const AbstractDataMap = require('./AbstractDataMap')

/**
 * Map data related to audit data structures.
 */
class AuditMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return [
      'App/Service/DataMap/Common/DateTimeDataMap',
      'App/Service/DataMap/Common/ApplicationReferenceDataMap'
    ]
  }

  /**
   * Create an AuditMap object.
   *
   * @param {DateTimeDataMap} dateTimeDataMap
   *   An instance of DateTimeDataMap.
   */
  constructor (dateTimeDataMap, referenceDataMap) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._dateTimeDataMap = dateTimeDataMap
    this._referenceDataMap = referenceDataMap
  }

  /**
   * {@inheritdoc}
   */
  map (obj) {
    const date = this._dateTimeDataMap.map(obj.datum)
    const organization = this.mapOrganization(obj.organisatie)

    // Return an array with audit data for every 'dienstVerlening'
    return obj.dienstVerleningen.map((dienstVerlening) => ({
      date,
      organization,
      service: dienstVerlening.naam && dienstVerlening.naam.naam,
      queries: this.mapArray(dienstVerlening.opgevraagdeDiensten, this.mapQuery),
      permissions: this.mapArray(dienstVerlening.machtigingen, this.mapPermission)
    }))
  }

  /**
   * Map an 'organisatie' object (backend) onto an organization object (api).
   *
   * @param {Object} organisatie
   *   An object as returned by backend
   *
   * @returns {Object}
   *   An object that represents the mapped organization object
   */
  mapOrganization (organisatie) {
    if (!organisatie) return null

    const name = organisatie.actueel.naam
    const shortName = organisatie.actueelKort.naam

    if (!shortName || shortName === name) {
      return { name }
    }

    return { name, shortName }
  }

  /**
   * Map an 'opgevraagdeDienst' object (backend) onto a query object (api).
   *
   * @param {Object} opgevraagdeDienst
   *   An object as returned by backend in 'opgevraagdeDiensten'
   *
   * @returns {Object}
   *   An object that represents the mapped query object
   */
  mapQuery (opgevraagdeDienst) {
    return {
      title: opgevraagdeDienst.naam && opgevraagdeDienst.naam.naam,
      source: opgevraagdeDienst.bron && opgevraagdeDienst.bron.naam
    }
  }

  /**
   * Map a 'machtiging' object (backend) onto a permission object (api).
   *
   * @param {Object} machtiging
   *   An object as returned by backend in 'machtigingen'
   *
   * @returns {Object}
   *   An object that represents the mapped permission object
   */
  mapPermission (machtiging) {
    if (!machtiging) return null
    const permission = this._referenceDataMap.map(machtiging.referentie) || {}
    if (machtiging.naam) {
      permission.label = machtiging.naam.naam
    }
    return permission
  }

}

module.exports = AuditMap
