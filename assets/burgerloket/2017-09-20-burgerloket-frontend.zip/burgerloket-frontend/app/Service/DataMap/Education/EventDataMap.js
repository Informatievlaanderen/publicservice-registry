'use strict'

const AbstractDataMap = require('../AbstractDataMap')

/**
 * Map data related to Education events.
 */
class EventDataMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return [
      'App/Service/DataMap/Common/ApplicationReferenceDataMap',
      'App/Service/DataMap/Common/AddressDataMap',
      'App/Service/DataMap/Common/DateTimeDataMap',
      'App/Service/DataMap/Common/CodeNameDataMap',
      'App/Service/DataMap/Education/CertificateDataMap',
      'App/Service/DataMap/Education/RegistrationDataMap'
    ]
  }

  /**
   * Create an EducationRegistrationDataMap object.
   *
   * @param {ApplicationReferenceDataMap} appReferenceDataMap
   *   An instance of ApplicationReferenceDataMap.
   * @param {AddressDataMap} addressDataMap
   *   An instance of AddressDataMap.
   * @param {DateTimeDataMap} dateTimeDataMap
   *   An instance of DateTimeDataMap.
   * @param {CodeNameDataMap} codeNameDataMap
   *   An instance of CodeNameDataMap.
   * @param {EducationCertificateDataMap} certificateDataMap
   *   An instance of EducationCertificateDataMap.
   * @param {EducationRegistrationDataMap} registrationDataMap
   *   An instance of EducationRegistrationDataMap.
   */
  constructor (appReferenceDataMap, addressDataMap, dateTimeDataMap, codeNameDataMap, certificateDataMap, registrationDataMap) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._appReferenceDataMap = appReferenceDataMap
    this._addressDataMap = addressDataMap
    this._dateTimeDataMap = dateTimeDataMap
    this._codeNameDataMap = codeNameDataMap
    this._certificateDataMap = certificateDataMap
    this._registrationDataMap = registrationDataMap
  }

  /**
   * {@inheritdoc}
   */
  map (obj) {
    // Initialize variable to null as default behavior.
    let event = null
    // Get the event type.
    var eventType = getEventType.call(this, obj)

    // Only process events if a valid event type is available. This because UI mapping cannot
    // be performed if no event type is available.
    if (eventType !== null) {
      // Create default event structure.
      event = {
        id: Math.random().toString(36).slice(2),
        type: eventType,
        category: obj.categorie,
        year: obj.jaar,
        institute: null,
        education: obj.opleiding || null,
        icon: this.educationIcon(obj.categorie),
        reference: this._appReferenceDataMap.map(obj.referentie),
        meta: {
          grantsCertificateSecundary: obj.geeftRechtOpDiplomaSecundairOnderwijs || false
        }
      }

      //
      // The certificate and registration related properties should always be
      // performed before processing event type specific properties.
      //

      // Check whether an institute is available.
      if (obj.instelling !== null) {
        event.institute = {
          name: obj.instelling.naam,
          address: this._addressDataMap.map(obj.instelling.adres)
        }
      }

      // Attach the certificate related properties.
      attachCertificateProperties.call(this, event, obj.leerEnErvaringsBewijzen, 'default')
      // Attach the registration related properties.
      attachRegistrationProperties.call(this, event, obj.inschrijvingen)

      // Attach the dutch language course related properties.
      attacheDutchLanguageCourseProperties.call(this, event, obj.nederlandseTaalTraject)
      // Attach the integration course related properties.
      attachIntegrationCourseProperties.call(this, event, obj.inburgeringsTraject)
    }

    return event
  }

  educationIcon (category) {
    if (!category) return 'icon-education'
    switch (category) {
      case 'Secundair onderwijs':
        return 'icon-backpack'
      case 'Lager onderwijs':
        return 'icon-blackboard'
      case 'Kleuteronderwijs':
        return 'icon-apple'
      default:
        return 'icon-education'
    }
  }
}

/*
 * Utility functions
 */

/**
 * Get the event type based on given raw data.
 *
 * @param {Object} obj
 *   An object which represents the raw event data.
 *
 * @returns {String}
 *   Machine readable name of the event type.
 */
function getEventType (obj) {
  // Check whether the event type information is available.
  if (obj && obj.type) {
    // Evaluate the original event type.
    switch (obj.type.code) {
      // Dutch integration course for non-native speakers.
      case 'NT2':
        // Change type to 'dutch-language'
        return 'dutch-language'

      // Integration course.
      case 'INB':
        // Change type to 'integration'
        return 'integration'

      default:
        return 'default'
    }
  }

  return null
}

/**
 * Attach dutch language course related properties.
 *
 * @param {Object} event
 *   An object which represents the event.
 * @param {Object} obj
 *   An object which represents the dutch language course.
 */
function attacheDutchLanguageCourseProperties (event, obj) {
  // Check whether required format is provided.
  if (event.type === 'dutch-language' && obj) {
    // Check whether the optional property "adviesLesType" is available.
    if (obj.adviesLesType) {
      // Set the meta data related to the dutch language course.
      event.meta.shortName = obj.adviesLesType.korteNaam
      event.meta.longName = obj.adviesLesType.langeNaam
    }

    // Check whether most recent or highest level is available.
    if (obj.niveauMeestRecente || obj.hoogsteNiveau) {
      // Initialize the default object structure.
      event.meta.level = { mostRecent: null, highest: null }

      // Check whether most recent is available.
      if (obj.niveauMeestRecente) {
        event.meta.level.mostRecent = {
          shortName: obj.niveauMeestRecente.korteNaam,
          longName: obj.niveauMeestRecente.langeNaam
        }
      }

      // Check whether highest is available.
      if (obj.hoogsteNiveau) {
        event.meta.level.highest = {
          shortName: obj.hoogsteNiveau.korteNaam,
          longName: obj.hoogsteNiveau.langeNaam
        }
      }
    }
  }
}

/**
 * Attach integration course related properties.
 *
 * @param {Object} event
 *   An object which represents the event.
 * @param {Object} obj
 *   An object which represents the integration course.
 */
function attachIntegrationCourseProperties (event, obj) {
  // Check whether required format is provided.
  if (event.type === 'integration' && obj) {
    // Set the event reference.
    event.reference = this._appReferenceDataMap.map(obj.referentie)
    // Set the meta data related to the integration course.
    event.meta.status = this._codeNameDataMap.map(obj.status)
    event.meta.decision = {
      date: this._dateTimeDataMap.map(obj.datumBesluit),
      name: (obj.besluit ? obj.besluit.naam : null),
      code: (obj.besluit ? obj.besluit.code : null),
      reason: obj.redenBesluit
    }
    event.meta.careerOrientationAdvice = this._codeNameDataMap.map(obj.loopbaanorientatieAdvies)
    event.meta.target = {
      type: obj.doelgroep.doelgroepType,
      reason: {
        noTarget: obj.doelgroep.redenGeenDoelgroep || null,
        notMandatory: obj.doelgroep.redenVrijstellingVerplichting || null
      }
    }
    event.meta.violations = {
      reference: this._appReferenceDataMap.map(obj.inbreuken.referentie),
      items: []
    }

    // Check whether violations are present.
    if (obj.inbreuken.lijst.length > 0) {
      // Iterate through the violations.
      obj.inbreuken.lijst.forEach((item) => {
        // Push the converted violation to the list.
        event.meta.violations.items.push({
          type: this._codeNameDataMap.map(item.typeInbreuk),
          recordDate: this._dateTimeDataMap.map(item.datumVaststelling),
          noticeSendDate: this._dateTimeDataMap.map(item.datumIngebrekestellingVerzonden),
          sactioningOrganisation: this._codeNameDataMap.map(item.sanctionerendeOverheid)
        })
      })
    }

    // Rewrite the event certificates with the integration course related certificates.
    attachCertificateProperties.call(this, event, obj.behaaldeAttesten, 'integration-course')
  }
}

/**
 * Attach certificate related properties.
 *
 * @param {Object} event
 *   An object which represents the event.
 * @param {Object} obj
 *   An object which represents the certificates.
 * @param {String|null} [type='default']
 *   Optional. Type of certificates being processed.
 */
function attachCertificateProperties (event, obj, type) {
  // Build default certificates structure.
  event.certificates = {
    reference: null,
    items: [],
    meta: {}
  }

  // Check whether required format is available.
  if (obj) {
    // Set the collection reference.
    event.certificates.reference = this._appReferenceDataMap.map(obj.referentie)
    // Map the processed certificates.
    event.certificates.items = this._certificateDataMap.mapArray((obj.lijst || []).map((item) => {
      // Set the certificate type. Use default as fallback. We attach a custom property
      // to each item to help the data mapper to identify what type of certificate
      // it is processing.
      item.certificateTypeId = type || 'default'

      return item
    }))
  }
}

/**
 * Attach registration related properties.
 *
 * @param {Object} event
 *   An object which represents the event.
 * @param {Object} obj
 *   An object which represents the registrations.
 */
function attachRegistrationProperties (event, obj) {
  // Build default registrations structure.
  event.registrations = {
    reference: null,
    items: [],
    meta: {}
  }

  // Check whether required format is available.
  if (obj) {
    // Set the collection reference.
    event.registrations.reference = this._appReferenceDataMap.map(obj.referentie)
    // Map the processed registrations.
    event.registrations.items = this._registrationDataMap.mapArray(obj.lijst || [])

    // Set the first registration to null.
    let firstRegistration = null
    // Iterate through the registrations.
    event.registrations.items.forEach((registration) => {
      // Check whether the first registration should be update.
      if (registration.year !== null && (firstRegistration === null || registration.year < firstRegistration)) {
        // Set the current registration as first.
        firstRegistration = registration.year
      }
    })
    // Set the first registration as meta data.
    event.registrations.meta.firstRegistration = firstRegistration
  }
}

module.exports = EventDataMap
