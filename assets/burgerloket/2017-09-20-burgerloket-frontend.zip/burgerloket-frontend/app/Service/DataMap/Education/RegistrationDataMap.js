'use strict'

const AbstractDataMap = require('../AbstractDataMap')

/**
 * Map data related to education registration.
 */
class RegistrationDataMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return [
      'App/Service/DataMap/Common/DateTimeDataMap',
      'App/Service/DataMap/Common/ApplicationReferenceDataMap',
      'App/Service/DataMap/Common/CodeNameDataMap'
    ]
  }

  /**
   * Create an EducationRegistrationDataMap object.
   *
   * @param {DateTimeDataMap} dateTimeDataMap
   *   An instance of DateTimeDataMap.
   * @param {ApplicationReferenceDataMap} appReferenceDataMap
   *   An instance of ApplicationReferenceDataMap.
   * @param {CodeNameDataMap} codeNameDataMap
   *   An instance of CodeNameDataMap.
   */
  constructor (dateTimeDataMap, appReferenceDataMap, codeNameDataMap) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._dateTimeDataMap = dateTimeDataMap
    this._appReferenceDataMap = appReferenceDataMap
    this._codeNameDataMap = codeNameDataMap
  }

  /**
   * {@inheritdoc}
   */
  map (obj) {
    // Initialize variable to null as default behavior.
    let registration = null

    // Check whether required format is provided.
    if (obj && (obj.hogerOnderwijs || obj.volwassenenOnderwijs || obj.leerplichtOnderwijs)) {
      // Create default registration structure.
      registration = {
        year: getRegistrationStartYear.call(this, obj),
        unsubscribeDate: this._dateTimeDataMap.map(obj.datumUitschrijving),
        course: obj.academieJaar,
        type: null,
        reference: null,
        status: this._codeNameDataMap.map(obj.status),
        meta: {}
      }
      // Attach the related properties for given types:
      //  * Higher education
      attachHigherEductionProperties.call(this, registration, obj.hogerOnderwijs)
      //  * Adult Education
      attachAdultEductionProperties.call(this, registration, obj.volwassenenOnderwijs)
      //  * Compulsory Education
      attachCompulsoryEducationProperties.call(this, registration, obj.leerplichtOnderwijs)
    }

    return registration
  }

}

/*
 * Utility functions.
 */

/**
 * Get the registration year.
 *
 * @param {Object} obj
 *   An object which represents a registration.
 *
 * @returns {Number|null}
 *   The year of registration if available, otherwise null.
 */
function getRegistrationStartYear (obj) {
  // Initialize variable to null as default behavior.
  let year = null

  // Check whether academic periode is provided.
  if (obj.academieJaar && obj.academieJaar.start) {
    // Use the academic start year.
    year = obj.academieJaar.start
  } else if (obj.jaarInschrijving && obj.jaarInschrijving > 0) {
    // Use the registration year as fallback.
    year = obj.jaarInschrijving
  }

  return year
}

/**
 * Attach properties related to higher education.
 *
 * @param {Object} registration
 *   An object which represents the registration.
 * @param {Object} obj
 *   An object which represents a higher education registration.
 */
function attachHigherEductionProperties (registration, obj) {
  // Check whether higher education related information is available.
  if (obj) {
    // Change the registration type.
    registration.type = 'higher-education'
    // Set the education information.
    registration.meta.education = this._codeNameDataMap.map(obj.soortOpleiding)
    // Set the contract information.
    registration.meta.contract = this._codeNameDataMap.map(obj.soortContract)
    // Set the registration reference.
    registration.reference = this._appReferenceDataMap.map(obj.referentie)
  }
}

/**
 * Attach properties related to adult education.
 *
 * @param {Object} registration
 *   An object which represents the registration.
 * @param {Object} obj
 *   An object which represents a registration.
 */
function attachAdultEductionProperties (registration, obj) {
  // Check whether adult education related information is available.
  if (obj) {
    // Change the registration type.
    registration.type = 'adult-education'
    // Set the education module.
    registration.meta.module = this._codeNameDataMap.map(obj.module)
    // Set the grant certificate flag.
    registration.meta.grantsCertificateSecundary = obj.geeftRechtOpDiplomaSecundairOnderwijs || false
    // Set default result value.
    registration.meta.result = null
    // Check whether the evaluation result is available.
    if (obj.evaluatieResultaat !== null) {
      // Set the education result.
      registration.meta.result = this._codeNameDataMap.map(obj.evaluatieResultaat)
    }
  }
}

/**
 * Attach properties related to compulsory education.
 *
 * @param {Object} registration
 *   An object which represents the registration.
 * @param {Object} obj
 *   An object which represents a compulsory education registration.
 */
function attachCompulsoryEducationProperties (registration, obj) {
  // Check whether compulsory education related information is available.
  if (obj) {
    // Change the registration type.
    registration.type = 'compulsory-education'
    // Set the education program type.
    registration.meta.programType = this._codeNameDataMap.map(obj.soortProgramma)
    // Set the exceptional education to null by default.
    registration.meta.exceptionalEducation = null
    // Check whether excpetional education information is available.
    if (obj.typeBuitengewoonOnderwijs !== null) {
      // Set the exceptional education info.
      registration.meta.exceptionalEducation = this._codeNameDataMap.map(obj.typeBuitengewoonOnderwijs)
    }
  }
}

module.exports = RegistrationDataMap
