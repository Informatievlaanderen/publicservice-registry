'use strict'

const AbstractDataMap = require('../AbstractDataMap')

/**
 * Map data related to education certificates.
 */
class CertificateDataMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return [
      'App/Service/DataMap/Common/DateTimeDataMap',
      'App/Service/DataMap/Common/CountryDataMap',
      'App/Service/DataMap/Common/ApplicationReferenceDataMap'
    ]
  }

  /**
   * Create an EducationCertificateDataMap object.
   *
   * @param {DateTimeDataMap} dateTimeDataMap
   *   An instance of DateTimeDataMap.
   * @param {CountryDataMap} countryDataMap
   *   An instance of CountryDataMap.
   * @param {AppReferenceDataMap} appReferenceDataMap
   *   An instance of AppReferenceDataMap.
   */
  constructor (dateTimeDataMap, countryDataMap, appReferenceDataMap) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._dateTimeDataMap = dateTimeDataMap
    this._countryDataMap = countryDataMap
    this._appReferenceDataMap = appReferenceDataMap
  }

  /**
   * {@inheritdoc}
   */
  map (obj) {
    // Check whether the required format is provided.
    if (obj) {
      // Setup default object structure.
      const certificate = {
        type: null,
        label: null,
        issueDate: null,
        expireDate: null,
        reference: null,
        meta: { }
      }

      // Map the default certificate properties.
      mapDefaultCertificateProperties.call(this, certificate, obj)
      // Map the integration course properties.
      mapIntegrationCertificateProperties.call(this, certificate, obj)

      return certificate.type !== null ? certificate : null
    }

    return null
  }

}

/*
 * Utility functions
 */

/**
 * Map default certificate related properties.
 *
 * @param {Object} certificate
 *   An object which represents a certificate.
 * @param {Object} obj
 *   An object which contains the certificate information.
 */
function mapDefaultCertificateProperties (certificate, obj) {
  // Check whether object is in required format.
  if (obj && obj.certificateTypeId === 'default') {
    // Set the certificate type.
    certificate.type = obj.certificateTypeId
    // Set the certificate label.
    certificate.label = obj.omschrijving || ''
    // Set the certificate related dates.
    certificate.issueDate = this._dateTimeDataMap.map(obj.uitreikingsDatum)
    certificate.expireDate = this._dateTimeDataMap.map(obj.vervalDatum)
    // Set the certificate reference.
    certificate.reference = this._appReferenceDataMap.map(obj.referentie)
    // Set the country information as registration meta.
    // certificate.meta.country = this._countryDataMap.map(obj.land)
    // @Warre: verandert naar obj.land aangezien this._countryDataMap steeds null teruggaf.
    certificate.meta.country = obj.land
  }
}

/**
 * Map integration course related properties.
 *
 * @param {Object} certificate
 *   An object which represents a certificate.
 * @param {Object} obj
 *   An object which contains the certificate information.
 */
function mapIntegrationCertificateProperties (certificate, obj) {
  // Check whether object is in required format.
  if (obj && obj.certificateTypeId === 'integration-course') {
    // Set the certificate type.
    certificate.type = obj.certificateTypeId
    // Use the attest type name as label.
    certificate.label = obj.typeAttest.naam
    // Use the sign date as issue date.
    certificate.issueDate = this._dateTimeDataMap.map(obj.datumOndertekening)
    // Set the certificate reference.
    certificate.reference = this._appReferenceDataMap.map(obj.referentie)
    // Set the attest type code as meta data. This because we
    // have a default certificate structure which does not support
    // this property.
    certificate.meta.certificateTypeId = obj.typeAttest.code
    // Set the issuer of the label.
    certificate.meta.issuer = obj.aangemaaktDoor || null
  }
}

module.exports = CertificateDataMap
