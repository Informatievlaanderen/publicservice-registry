'use strict'

const AbstractDataMap = require('./AbstractDataMap')

/**
 * Keeps the original data structure.
 */
class PassthroughDataMap extends AbstractDataMap { }

module.exports = PassthroughDataMap
