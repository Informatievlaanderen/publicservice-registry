'use strict'

const moment = require('moment')
const AbstractDataMap = require('./AbstractDataMap')

/**
 * Map data related to Dosis file structures.
 */
class DosisFileMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  mapArray (items) {
    // Perform default array mapping and sort items
    // by change date.
    return super.mapArray(items).sort((a, b) => {
      // Convert the ISO format into a unix timestamp.
      const changedA = parseInt(moment(a.changed).format('x'))
      const changedB = parseInt(moment(b.changed).format('x'))
      // Determine the correct order for the items.
      return changedB - changedA
    })
  }

  /**
   * {@inheritdoc}
   */
  map (obj) {
    // Build the mapper function name.
    var mapFnName = 'map' + obj.TypeDossier.Code
    // Get the mapping function for given name.
    var mapFn = this[mapFnName] || null
    // Check whether the data mapping function is missing.
    if (mapFn === null) {
      // Raise error due to missing data mapper.
      throw new Error('Missing data mapper: ' + mapFnName)
    }
    // Perform the data mapping for given file.
    return mapFn.call(this, obj)
  }

  /**
   * Map Dosis file of type "DossierStatus".
   *
   * @param {Object} file
   *   An object which represents the Dosis file.
   *
   * @returns {Object}
   *   An object which represents the mapped data structure.
   */
  mapDossierStatus (file) {
    // Build the different Dosis file phases.
    const phases = (file.Producten[0].MogelijkeVlaamseFases || []).map((phase) => phase.Code)
    // Determine the current phase index.
    const currentPhaseIndex = phases.indexOf(file.Status.StatusVlaamsFase.Code)

    // Initialize the steps variable to an empty array. This will hold the changes made
    // in each phase but group them as one step.
    const steps = []
    // Iterate through the available phases.
    for (let i = 0; i < phases.length; i++) {
      // Append the step with grouped history records.
      steps.push({
        isActive: currentPhaseIndex >= i,
        isCurrent: currentPhaseIndex === i,
        phase: phases[i],
        // Only include history records which match the
        // current phase.
        history: file.Historieken.filter((historyRecord) => {
          return phases[i] === historyRecord.StatusVlaamsFase.Code
        })
      })
    }

    // Build our custom data structure for a Dosis file.
    return {
      id: file.Identificatie.DossierNummer,
      service: file.OrganisatieNaam,
      type: file.TypeDossier.Code,
      title: file.Producten[0].Titel || null,
      titleShort: file.Producten[0].TitelKort || null,
      reference: file.Producten[0].Link || null,
      name: file.Naam || null,
      admin: {
        name: file.DossierBeheerder.Naam || null,
        service: file.DossierBeheerder.Dienst || null,
        phone: file.DossierBeheerder.Telefoon || null,
        email: file.DossierBeheerder.Email || null,
        website: file.DossierBeheerder.Website || null
      },
      created: file.OntvangstDatum,
      changed: file.WijzigingsDatum,
      granularity: 3,
      // todo double check with Warre why this is needed:
      beforeChanged: 'Laatste wijziging',
      status: {
        code: file.Status.StatusVlaamsCode.Code,
        label: file.Status.StatusDetail1,
        requiresAction: file.Status.Actie.ActieNodig,
        message: file.Status.Actie.Actie
      },
      phase: {
        index: currentPhaseIndex,
        code: file.Status.StatusVlaamsFase.Code,
        label: file.Status.StatusVlaamsFase.Omschrijving
      },
      phases: phases,
      action: {
        required: file.Status.Actie.ActieNodig,
        label: file.Status.Actie.Actie
      },
      history: file.Historieken,
      steps: steps
    }
  }

}

module.exports = DosisFileMap
