'use strict'

const AbstractDataMap = require('./AbstractDataMap')

/**
 * Map data related to test case structures.
 */
class TestCaseMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  map (testCases = {}) {
    const result = []
    Object.keys(testCases).forEach((category) => {
      const categoryTestCases = testCases[category] || {}

      // Push the demo test cases for given category.
      result.push({
        label: `${category} - Demo Test Cases`,
        items: (categoryTestCases.demo || []).map(this.mapCase)
      })

      // Push the constructed test cases for given category.
      result.push({
        label: `${category} - Constructed Test Cases`,
        items: (categoryTestCases.constructed || []).map(this.mapCase)
      })

      // Push the happy test cases for given category.
      result.push({
        label: `${category} - Happy Test Cases`,
        items: (categoryTestCases.happy || []).map(this.mapCase)
      })

      // Push the unhappy test cases for given category.
      result.push({
        label: `${category} - Unhappy Test Cases`,
        items: (categoryTestCases.unhappy || []).map(this.mapCase)
      })
    })
    return result
  }

  /**
   * Map one specific test case onto an api testcase object.
   */
  mapCase (testCase) {
    return { token: testCase.insz, label: testCase.omschrijving }
  }

}

module.exports = TestCaseMap
