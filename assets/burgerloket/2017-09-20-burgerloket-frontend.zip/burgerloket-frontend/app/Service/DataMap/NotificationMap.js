'use strict'

const moment = require('moment')
const AbstractDataMap = require('./AbstractDataMap')

/**
 * Map data related to notification structures.
 */
class NotificationMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return [
      'App/Service/DataMap/Common/DateTimeDataMap'
    ]
  }

  /**
   * Create an NotificationMap object.
   *
   * @param {DateTimeDataMap} dateTimeDataMap
   *   An instance of DateTimeDataMap.
   */
  constructor (dateTimeDataMap) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._dateTimeDataMap = dateTimeDataMap
  }

  /**
   * {@inheritdoc}
   */
  mapArray (items) {
    // Map notification using default mapper, then sort by date, then group by transaction id
    return super.mapArray(items)
      .sort(inDescendingDateOrder)
      .reduce(this.addNotificationToGroup, [])
  }

  /**
   * {@inheritdoc}
   */
  map (obj) {
    if (!obj) return null
    // Create the default notification structure.
    return {
      id: obj.NotificatieId,
      // @todo(adriaan): Add mapping once we get this property from backend
      detailId: 'notificatie_DossierNummer_000000001',
      group: obj.TransactieId,
      title: obj.Titel || null,
      subtitle: this.findDataValue(obj, 'Merknaam'),
      body: obj.Body || null,
      date: this._dateTimeDataMap.map(obj.DatumNotificatie),
      urlMoreInfo: obj.UriMeerInfo,
      isRead: isReadNotification(obj),
      icon: this.mapIcon(obj.Categorie),
      requiresAction: obj.Categorie.Code === 'DossierGerelateerdBerichtActieNodig'
    }
  }

  /**
   * Group notifications by transaction id
   *
   * @param {Object[]} groupedNotifications
   *   A flat list of all notifications; should be sorted
   *
   * @returns {Object[]}
   *   The given notifications array, with the given notification added to the correct group
   */
  addNotificationToGroup (groupedNotifications, notification) {
    const groupContainer = groupedNotifications
      .find((n) => n.group === notification.group)

    if (!notification.group || !groupContainer) {
      return groupedNotifications.concat(notification)
    }

    if (!groupContainer.nested) {
      // Create copy of 'root' notification, and add it as the first element in the nested array.
      // To avoid json serialization issues (circular structure), we remove the nested property
      const firstOfGroup = Object.assign({}, groupContainer, { nested: undefined })
      // Add the parentId to the nested notification
      firstOfGroup.parentId = groupContainer.id
      groupContainer.nested = [ firstOfGroup ]
    }
    // Add the parentId to the nested notification
    notification.parentId = groupContainer.id
    // There is already a more recent notification in the same group.
    // We add the given notification to that group (but not to the main list).
    groupContainer.nested.push(notification)

    return groupedNotifications
  }

  /**
   * Map a 'Categorie' property (backend) onto an 'icon' (api) property
   *
   * @param {Object} categorie
   *   A Categorie codelijst object as returned by backend
   *
   * @returns {String}
   *   The corresponding notification icon for the given categorie
   */
  mapIcon (categorie) {
    if (!categorie) return ''
    switch (categorie.Code) {
      case 'DossierGerelateerdBerichtWijzigingDossier':
        return 'icon-document'
      case 'DossierGerelateerdBerichtActieNodig':
        return 'icon-document'
      default:
        return ''
    }
  }

  /**
   * Look up a 'SleutelWaardePaar' by given key as returned in a notification by backend
   *
   * @param {Object} notificatie
   *   A notificatie object as returned by backend
   * @param {String} key
   *   The key of the SleutelWaardePaar to find
   *
   * @returns {String|null}
   *   The corresponding value if the SleutelWaardePaar is defined for this notificatie
   */
  findDataValue (notificatie, key) {
    if (!notificatie || !notificatie.SleutelWaardeParen) return null
    const pair = notificatie.SleutelWaardeParen.find((paar) => paar.Sleutel === key)
    return pair ? pair.Waarde : null
  }
}

function isReadNotification (notification) {
  if (!notification) return false
  // Get the notification statuses.
  const statuses = notification.Statussen || []
  return statuses.some((status) =>
    status.NotificatieKanaal === 0 && status.Type === 'Geopend')
}

function inDescendingDateOrder (a, b) {
  // Convert the ISO format into a unix timestamp.
  const dateA = a.date ? parseInt(moment(a.date.value).format('x')) : 0
  const dateB = b.date ? parseInt(moment(b.date.value).format('x')) : 0
  // Determine the correct order for the items.
  return dateB - dateA
}

module.exports = NotificationMap
