'use strict'

const AbstractDataMap = require('../AbstractDataMap')

/**
 * Map data related to residence (woonst) data structures.
 */
class ResidenceMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return [
      'App/Service/DataMap/Common/AddressDataMap',
      'App/Service/DataMap/Accommodation/DiplomaticPostMap'
    ]
  }

  /**
   * Create an ResidenceMap object.
   *
   * @param {AddressDataMap} addressDataMap
   *   An instance of AddressDataMap.
   * @param {DiplomaticPostMap} diplomaticPostMap
   *   An instance of DiplomaticPostMap.
   */
  constructor (addressDataMap, diplomaticPostMap) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._addressDataMap = addressDataMap
    this._diplomaticPostMap = diplomaticPostMap
  }

  /**
   * {@inheritdoc}
   */
  map (obj) {
    if (!obj || !obj.woonst) return null
    const woonst = obj.woonst
    if (!woonst.hoofdverblijfplaats && !woonst.verblijfplaatsBuitenland) return null

    const verblijfplaats = woonst.hoofdverblijfplaats || woonst.verblijfplaatsBuitenland.verblijfplaats
    const isForeign = !woonst.hoofdverblijfplaats && !!woonst.verblijfplaatsBuitenland
    const isReference = !!verblijfplaats.referentieAdres
    const isAbsent = !!verblijfplaats.tijdelijkeAfwezigheid
    const isChanging = !!verblijfplaats.aangifteAdresWijziging
    const address = this._addressDataMap.map(verblijfplaats.adres)
    const diplomaticPost = isForeign ? this._diplomaticPostMap.map(woonst.verblijfplaatsBuitenland.diplomatiekePost) : null
    const postAddress = this._addressDataMap.map(woonst.postadresBuitenland && woonst.postadresBuitenland.adres)

    return {
      isForeign, address, isChanging, isReference, isAbsent, diplomaticPost, postAddress
    }
  }

}

module.exports = ResidenceMap

