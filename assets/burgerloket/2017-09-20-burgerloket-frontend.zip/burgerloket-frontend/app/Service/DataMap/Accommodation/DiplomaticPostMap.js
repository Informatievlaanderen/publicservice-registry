'use strict'

const AbstractDataMap = require('../AbstractDataMap')

/**
 * Map data related to diplomatic post data structures.
 */
class DiplomaticPostMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['App/Service/DataMap/Common/CountryDataMap']
  }

  /**
   * Create an DiplomaticPostMap object.
   *
   * @param {CountryDataMap} countryDataMap
   *   An instance of CountryDataMap.
   */
  constructor (countryDataMap) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._countryDataMap = countryDataMap
  }

  /**
   * {@inheritdoc}
   */
  map (obj) {
    // Check whether the required format is provided.
    if (!obj) return null
    if (!obj.standplaats && !obj.land) return null

    const post = {}
    if (obj.standplaats) {
      post.location = obj.standplaats.naam || `onbekend (${obj.standplaats.code})`
    }
    if (obj.land) {
      post.country = this._countryDataMap.map(obj.land)
    }
    return post
  }

}

module.exports = DiplomaticPostMap

