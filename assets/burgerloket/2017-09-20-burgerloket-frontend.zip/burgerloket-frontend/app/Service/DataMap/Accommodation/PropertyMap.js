'use strict'

const AbstractDataMap = require('../AbstractDataMap')

/**
 * Map data related to property (vastgoed) data structures.
 */
class PropertyMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return [
      'App/Service/DataMap/Common/DateTimeDataMap',
      'App/Service/DataMap/Common/AddressDataMap'
    ]
  }

  /**
   * Create an PropertyMap object.
   *
   * @param {DateTimeDataMap} dateTimeDataMap
   *   An instance of DateTimeDataMap.
   * @param {AddressDataMap} addressDataMap
   *   An instance of AddressDataMap.
   */
  constructor (dateTimeMap, addressDataMap) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._dateTimeMap = dateTimeMap
    this._addressDataMap = addressDataMap
  }

  /**
   * {@inheritdoc}
   */
  map (obj) {
    if (!obj || !obj.vastgoed || !obj.vastgoed.lijst) return []

    return this.mapArray(obj.vastgoed.lijst, this.mapProperty)
  }

  /**
   * Map an 'eigendom' object (backend) onto a property object (api).
   *
   * @param {Object} eigendom
   *   An object as returned by backend in 'vastgoed.lijst'
   *
   * @returns {Object}
   *   An object that represents the mapped property properties
   */
  mapProperty (eigendom) {
    if (!eigendom || !eigendom.patrimoniaalPerceel) return null

    const perceel = eigendom.patrimoniaalPerceel
    const type = this.mapType(perceel)
    const gronden = perceel.gebouweenheid || perceel.onbebouwd || []
    const address = this._addressDataMap.map(perceel)
    const since = this._dateTimeMap.map(eigendom.woontOpEigendom && eigendom.woontOpEigendom.sinds)
    const cadastre = this.mapCadastre(perceel.identificatie)
    const ownership = this.mapArray(eigendom.eigenaarsrecht, this.mapOwnership)
    const coOwners = eigendom.aantalMedeEigenaars
    const cadastralIncome = this.mapCadastralIncome(perceel.kadastraalInkomen)
    const yearOfConstruction = this.extractYearOfConstruction(gronden)
    const administration = this._addressDataMap.map(perceel.administratieveGemeente && perceel.administratieveGemeente.plaats)
    const plots = gronden.length <= 1 ? null : this.mapArray(gronden, this.mapPlot)

    return {
      type, address, since, cadastre, ownership, coOwners, cadastralIncome, yearOfConstruction, administration, plots
    }
  }

  /**
   * Map a 'patrimoniaalPerceel' object (backend) onto a type string (api).
   *
   * @param {Object} perceel
   *   An object as returned by backend in 'patrimoniaalPerceel'
   *
   * @returns {String|null}
   *   Either 'building', 'vacant' or null
   */
  mapType (perceel) {
    if (!perceel) return null

    if (perceel.gebouweenheid && perceel.gebouweenheid.length > 0) return 'building'
    if (perceel.onbebouwd && perceel.onbebouwd.length > 0) return 'vacant'

    return null
  }

  /**
   * Map an 'identificatie' object (backend) onto a cadastre object (api).
   *
   * @param {Object} identificatie
   *   An object as returned by backend in 'patrimoniaalPerceel.identificatie'
   *
   * @returns {Object}
   *   An object that represents the mapped cadastre properties
   */
  mapCadastre (identificatie) {
    if (!identificatie) return null

    const grondnr = identificatie.grondnummer || ''
    const bisnr = identificatie.bisnummer || ''
    const cijfer = identificatie.cijferexponent || ''
    const letter = identificatie.letterexponent || ''
    const lot = `${grondnr}${bisnr}${cijfer}${letter}`
    const partition = identificatie.partitie
    const section = identificatie.sectie
    const department = identificatie.kadastraleAfdeling && identificatie.kadastraleAfdeling.naam

    return {
      department, section, lot, partition
    }
  }

  /**
   * Map an 'eigenaarsrecht' object (backend) onto an ownership object (api).
   *
   * @param {Object} eigenaarsrecht
   *   An object as returned by backend in 'eigenaarsrecht'
   *
   * @returns {Object}
   *   An object that represents the mapped ownership properties
   */
  mapOwnership (eigenaarsrecht) {
    if (!eigenaarsrecht) return null

    const type = eigenaarsrecht.titularisType && eigenaarsrecht.titularisType.naam
    const rights = this.mapArray(eigenaarsrecht.zakelijkRecht, this.mapRight)

    return {
      type, rights
    }
  }

  /**
   * Map a 'kadastraalInkomen' object (backend) onto a cadastralIncome object (api).
   *
   * @param {Object} ki
   *   An object as returned by backend in 'patrimoniaalPerceel.kadastraalInkomen'
   *
   * @returns {Object}
   *   An object that represents the mapped ownership properties
   */
  mapCadastralIncome (ki) {
    if (!ki) return null

    const amount = ki.bedrag
    const end = this._dateTimeMap.map(ki.datumEindeVrijstelling)

    return {
      amount, end
    }
  }

  /**
   * Map a 'grond' object (backend) onto a plot object (api).
   *
   * @param {Object} grond
   *   An object as returned by backend in either
   *   'patrimoniaalPerceel.onbebouwd' or 'patrimoniaalPerceel.gebouweenheid'
   *
   * @returns {Object}
   *   An object that represents the mapped plot properties
   */
  mapPlot (grond) {
    if (!grond) return null

    const address = this._addressDataMap.map(grond.adres || grond)
    const yearOfConstruction = grond.gebouw && grond.gebouw.bouwjaar || null

    return {
      address, yearOfConstruction
    }
  }

  /**
   * Map an 'zakelijkrecht' object (backend) onto a right object (api).
   *
   * @param {Object} zakelijkrecht
   *   An object as returned by backend in 'zakelijkrecht'
   *
   * @returns {Object}
   *   An object that represents the mapped right properties
   */
  mapRight (zakelijkrecht) {
    if (!zakelijkrecht) return null

    const shares = this.mapShares(zakelijkrecht.aandeel)
    const type = zakelijkrecht.rechtType && zakelijkrecht.rechtType.naam
    const expires = this._dateTimeMap.map(zakelijkrecht.vervalDatum)

    return {
      type, shares, expires
    }
  }

  /**
   * Map a 'aandeel' object (backend) onto a shares object (api).
   *
   * @param {Object} aandeel
   *   An object as returned by backend in 'zakelijkrecht.aandeel'
   *
   * @returns {Object}
   *   An object that represents the mapped shares properties
   */
  mapShares (aandeel) {
    if (!aandeel) return null

    const owned = aandeel.teller
    const total = aandeel.noemer

    return {
      owned, total
    }
  }

  /**
   * Extract the bouwjaar from a list of 'gronden'.
   * Return null in case they are vacant or multiple plots exist.
   *
   * @param {Object[]} gronden
   *   An list of objects as returned by backend in 'patrimoniaalPerceel.gebouweenheid'
   *
   * @returns {String|null}
   *   The year of construction if there is exactly one plot with construction
   */
  extractYearOfConstruction (gronden) {
    if (!gronden || gronden.length !== 1) return null

    const grond = gronden[0]

    return grond.gebouw && grond.gebouw.bouwjaar || null
  }

}

module.exports = PropertyMap

