'use strict'

const AbstractDataMap = require('./AbstractDataMap')

/**
 * Map data related to profile structures.
 */
class ProfileMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  map (obj) {
    // Create the default notification structure.
    return {
      firstName: obj.voornaam || '',
      lastName: obj.familienaam || '',
      nickname: obj.roepnaam || ''
    }
  }

}

module.exports = ProfileMap
