'use strict'

const AbstractDataMap = require('../AbstractDataMap')

/**
 * Map data related to a code/name object.
 *
 * Use the OSLO² object definition to determine the format.
 */
class CodeNameDataMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  map (obj) {
    // Check whether the object is in the required format.
    if (obj && obj.naam) {
      return {
        name: obj.naam,
        code: obj.code
      }
    }

    return null
  }

}

module.exports = CodeNameDataMap
