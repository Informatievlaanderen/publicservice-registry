'use strict'

const AbstractDataMap = require('../AbstractDataMap')

/**
 * Map data related to an application reference.
 *
 * @todo Missing OSLO² object definition.
 */
class ApplicationReferenceDataMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  map (obj) {
    // Check whether the required format is provided.
    if (obj && obj.url) {
      return {
        url: obj.url,
        label: obj.omschrijving,
        type: obj['Content-Type']
      }
    }

    return null
  }

}

module.exports = ApplicationReferenceDataMap
