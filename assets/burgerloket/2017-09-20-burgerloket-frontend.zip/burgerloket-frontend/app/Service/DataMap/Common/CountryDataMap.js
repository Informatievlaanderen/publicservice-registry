'use strict'

const AbstractDataMap = require('../AbstractDataMap')

/**
 * Map data related to a country.
 *
 * Use the OSLO² object definition to determine the format.
 */
class CountryDataMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return [
      'App/Service/DataMap/Common/CodeNameDataMap'
    ]
  }

  /**
   * Create an EducationCertificateDataMap object.
   *
   * @param {CodeNameDataMap} codeNameDataMap
   *   An instance of CodeNameDataMap.
   */
  constructor (codeNameDataMap) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._codeNameDataMap = codeNameDataMap
  }

  /**
   * {@inheritdoc}
   */
  map (obj) {
    // Check whether the object is in the required format.
    if (!obj || !obj.naam) return null
    // Pass the object to our generic data map.
    return this._codeNameDataMap.map(obj)
  }

}

module.exports = CountryDataMap
