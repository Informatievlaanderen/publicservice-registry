'use strict'

const AbstractDataMap = require('../AbstractDataMap')

/**
 * Map data related to an address.
 */
class AddressDataMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return ['App/Service/DataMap/Common/CountryDataMap']
  }

  /**
   * Create an AddressDataMap object.
   *
   * @param {CountryDataMap} countryDataMap
   *   An instance of CountryDataMap.
   */
  constructor (countryDataMap) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._countryDataMap = countryDataMap
  }

  /**
   * {@inheritdoc}
   */
  map (obj) {
    // Check whether the required format is provided.
    if (!obj) return null

    const address = {}
    if (obj.locatienaam) {
      address.location = obj.locatienaam
    }
    if (obj.straatnaam || obj.huisnummer) {
      address.street = {
        name: obj.straatnaam && obj.straatnaam.naam,
        number: obj.huisnummer,
        box: obj.busnummer
      }
    }
    if (obj.gemeentenaam) {
      address.city = {
        name: obj.gemeentenaam.naam,
        code: obj.postcode
      }
    }
    if (obj.land) {
      address.country = this._countryDataMap.map(obj.land)
    }
    return address
  }

}

module.exports = AddressDataMap
