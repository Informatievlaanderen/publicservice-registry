'use strict'

const AbstractDataMap = require('../AbstractDataMap')
const moment = require('moment')

const YEAR = 'YEAR'
const MONTH = 'MONTH'
const DAY = 'DAY'
const TIME = 'TIME'

const stringGranularities = [
  { regex: /\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d/, granularity: TIME },
  { regex: /\d{4}-\d\d-\d\d/, granularity: DAY },
  { regex: /\d{4}-\d\d/, granularity: MONTH },
  { regex: /\d{4}/, granularity: YEAR }
]

/**
 * Map data related to a date time.
 *
 * @todo Missing OSLO² object definition.
 */
class DateTimeDataMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  map (obj) {
    if (!obj) return null
    if (obj.value && obj.granularity) return obj

    // Transform older API standard for datetimes
    if (obj.datumtijd) {
      return { value: obj.datumtijd, granularity: this.mapGranularity(obj.precisie) }

    // Date strings should be parsed according to API conventions.
    } else if (typeof obj === 'string') {
      for (let match of stringGranularities) {
        // Determine granularity based on first regex match.
        if (match.regex.test(obj)) {
          return { value: obj, granularity: match.granularity }
        }
      }

    // If obj is already a date, just assume datetime granularity.
    // If obj is a number, convert as if it's unix timestamp, assume datetime granularity.
    } else if (obj instanceof Date || typeof obj === 'number') {
      return { value: moment(obj).format(), granularity: TIME }
    }

    return null
  }

  mapGranularity (granularity) {
    switch (granularity) {
      case 0:
        return YEAR
      case 1:
        return MONTH
      case 2:
        return DAY
      case 3:
        return TIME
      default:
        return TIME
    }
  }

}

module.exports = DateTimeDataMap
