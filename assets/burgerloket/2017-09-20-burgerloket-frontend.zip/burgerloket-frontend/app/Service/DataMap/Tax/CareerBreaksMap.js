'use strict'

const AbstractDataMap = require('../AbstractDataMap')

/**
 * Map data related to career breaks (loopbaanonderbreking) data structures.
 */
class CareerBreaksMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return [
      'App/Service/DataMap/Common/DateTimeDataMap'
    ]
  }

  /**
   * Create an CareerBreaksMap object.
   *
   * @param {DateTimeDataMap} dateTimeMap
   *   An instance of DateTimeDataMap.
   */
  constructor (dateTimeMap) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._dateTimeMap = dateTimeMap
  }

  /**
   * {@inheritdoc}
   */
  map (obj) {
    if (!obj || !obj.loopbaanonderbrekingen) return null

    return this.mapArray(obj.loopbaanonderbrekingen.lijst, this.mapBreak)
  }

  mapBreak (onderbreking) {
    if (!onderbreking) return null

    const category = onderbreking.categorie && onderbreking.categorie.naam
    const context = onderbreking.reden && onderbreking.reden.naam
    const dossierId = onderbreking.dossierNummer
    const source = onderbreking.bron && onderbreking.bron.naam
    const reduction = onderbreking.vermindering && onderbreking.vermindering.naam
    const from = this._dateTimeMap.map(onderbreking.periode && onderbreking.periode.van)
    const until = this._dateTimeMap.map(onderbreking.periode && onderbreking.periode.tot)
    const amount = onderbreking.bedragMaandelijkseUitkering
    const additionalActivity = onderbreking.bijkomendeActiviteit && onderbreking.bijkomendeActiviteit.naam

    return {
      category, context, dossierId, source, reduction, from, until, amount, additionalActivity
    }
  }

}

module.exports = CareerBreaksMap

