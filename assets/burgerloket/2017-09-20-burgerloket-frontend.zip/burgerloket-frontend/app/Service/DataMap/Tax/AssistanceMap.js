'use strict'

const AbstractDataMap = require('../AbstractDataMap')

/**
 * Map data related to assistance (recht ondersteuningen) data structures.
 */
class AssistanceMap extends AbstractDataMap {

  /**
   * {@inheritdoc}
   */
  static get inject () {
    return [
      'App/Service/DataMap/Common/DateTimeDataMap'
    ]
  }

  /**
   * Create an AssistanceMap object.
   *
   * @param {DateTimeDataMap} dateTimeMap
   *   An instance of DateTimeDataMap.
   */
  constructor (dateTimeMap) {
    // Perform default object creation.
    super()
    // Setup object members.
    this._dateTimeMap = dateTimeMap
  }

  /**
   * {@inheritdoc}
   */
  map (obj) {
    if (!obj || !obj.rechten) return null

    return this.mapArray(obj.rechten.lijst, this.mapRight)
  }

  mapRight (recht) {
    if (!recht) return null

    const measure = recht.maatregel && recht.maatregel.soort.naam
    const decided = this._dateTimeMap.map(recht.datumBeslissing)
    const decision = recht.status && recht.status.naam
    const from = this._dateTimeMap.map(recht.periode && recht.periode.van)
    const until = this._dateTimeMap.map(recht.periode && recht.periode.tot)

    return {
      measure, decided, decision, from, until
    }
  }

}

module.exports = AssistanceMap

