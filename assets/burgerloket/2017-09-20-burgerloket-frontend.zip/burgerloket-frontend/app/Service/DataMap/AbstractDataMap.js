'use strict'

/**
 * Abstract definition for mapping data.
 */
class AbstractDataMap {

  /**
   * FlatMap an array of objects to custom data structure.
   *
   * @param {Object[]} items
   *   An array of objects which should be mapped.
   * @param {Function} [cb=this.map]
   *   The mapping function to be used on each object, defaults to this.map.
   *
   * @returns {Object[]}
   *   An array of objects which have been mapped.
   */
  mapArray (items, cb = this.map, ...args) {
    // Iterate through the array and perform mapping on each item.
    // If the mapped return value is falsy it's not included.
    // If the mapped return value is an array all items are flattened into the result.
    items = items || []
    return items.map((obj) => cb.apply(this, [obj, ...args]))
      .reduce((result, obj) => obj ? result.concat(obj) : result, [])
  }

  /**
   * Map an object to custom data structure.
   *
   * @param {Object} obj
   *   An object which should be mapped.
   *
   * @returns {Object}
   *   An object which represents the mapped data structure.
   */
  map (obj) { return obj }

}

module.exports = AbstractDataMap
