'use strict'

const AbstractOperation = require('./AbstractOperation')

/**
 * Defines a service write operation.
 */
class WriteOperation extends AbstractOperation { }

module.exports = WriteOperation
