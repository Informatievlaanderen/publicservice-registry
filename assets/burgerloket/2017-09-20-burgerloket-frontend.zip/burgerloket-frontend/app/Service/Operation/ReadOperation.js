'use strict'

const CacheMode = require('../CacheMode')
const AbstractOperation = require('./AbstractOperation')

/**
 * Defines a service read operation.
 */
class ReadOperation extends AbstractOperation {

  /**
   * Create a ReadOperation object.
   *
   * @param {AbstractService} service
   *   An object which represents the service.
   * @param {String} operation
   *   Name of the operation.
   * @param {Object} options
   *   An object which contains the service operation options.
   * @param {Object} args
   *   An object which contains the worker arguments.
   * @param {Generator} worker
   *   A generator function which represents the worker.
   */
  constructor (service, operation, options, args, worker) {
    // Perform default object init.
    super(service, operation, options, args, worker)
    // Setup object members.
    this._cacheMode = this.options.defaultCacheMode || CacheMode.DEFAULT
  }

  /**
   * Get the current cache mode.
   *
   * @returns {Number}
   *   The cache mode being used.
   */
  getCacheMode () { return this._cacheMode }

  /**
   * Set the cache mode.
   *
   * @param {Number}
   *  Mode which should be used.
   *
   * @returns {this}
   *   A reference to ourself.
   */
  setCacheMode (mode) {
    // Validate the cache mode.
    if (!CacheMode.isValid(mode)) {
      // Raise error due to invalid cache mode.
      throw Error('Invalid service operation cache mode')
    }
    // Set the cache mode.
    this._cacheMode = mode

    return this
  }

  * exec () {
    // Initialize the operation result variable to null.
    let result = null
    // Get the configured cache mode.
    const cacheMode = this.getCacheMode()

    // Check whether the cache can be used for initial lookup.
    if (CacheMode.isCacheAllowed(cacheMode)) {
      // Try to retrieve the data from cache.
      result = yield this.service.cache.get(this.cacheKey)
    }

    // Check whether the backend can be used for lookup.
    if (result === null && CacheMode.isBackendAllowed(cacheMode)) {
      // Perform default operation execution.
      result = yield super.exec() || null
      // Check whether result is cacheable.
      if (result !== null) {
        // Update the service cache.
        yield this.service.cache.put(this.cacheKey, result, this.options.cacheExpire)
      }
    }

    return result
  }

}

module.exports = ReadOperation
