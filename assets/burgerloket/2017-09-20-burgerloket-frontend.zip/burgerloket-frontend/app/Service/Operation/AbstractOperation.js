'use strict'

/**
 * Abstraction of a service operation.
 */
class AbstractOperation {

  /**
   * Create a AbstractOperation object.
   *
   * @param {AbstractService} service
   *   An object which represents the service.
   * @param {String} operation
   *   Name of the operation.
   * @param {Object} options
   *   An object which contains the service operation options.
   * @param {Object} args
   *   An object which contains the worker arguments.
   * @param {Generator} worker
   *   A generator function which represents the worker.
   */
  constructor (service, operation, options, args, worker) {
    // Setup object members.
    this._service = service
    this._operation = operation || ''
    this._cacheKey = 'service__' + service.name + '__' + operation + '__' + use('HashObject')(args)
    this._options = options || {}
    this._args = args || {}
    this._worker = worker
  }

  /**
   * Get the service.
   *
   * @returns {AbstractService}
   *   An instance of AbstractService.
   */
  get service () { return this._service }

  /**
   * Get the name of the operation.
   *
   * @returns {String}
   *   Name of the operation.
   */
  get name () { return this._operation }

  /**
   * Get a unique cache key for this operation.
   *
   * @returns {String}
   *   Unique cache key matching this operation.
   */
  get cacheKey () { return this._cacheKey }

  /**
   * Get the service operation options.
   *
   * @returns {Object}
   *   An object which contains the options.
   */
  get options () { return this._options }

  /**
   * Get the service operation arguments.
   *
   * @returns {Object}
   *   An object which contains the worker arguments.
   */
  get args () { return this._args }

  /**
   * Get the service operation worker.
   *
   * @returns {Generator}
   *   A generator function which performs the actual
   *   service operation.
   */
  get worker () { return this._worker }

  /**
   * Execute this service operation.
   *
   * @returns {Object|null|undefined}
   *   Result of the service operation. Depends on the
   *   operation being performed.
   */
  * exec () { return yield this.worker(this.args) }

}

module.exports = AbstractOperation
