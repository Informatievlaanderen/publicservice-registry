<template>
  <div class="tabs__wrapper">
    <ul :class="classes">
      <slot></slot>
    </ul>
  </div>
</template>

<script>

import BlTab from '~components/navigations/tabs/Tab.vue'

export default {
  components: {
    BlTab
  },
  name: 'tabs',
  data () {
    return {
      classes: {
        'tabs': true
      }
    }
  }
}
</script>
