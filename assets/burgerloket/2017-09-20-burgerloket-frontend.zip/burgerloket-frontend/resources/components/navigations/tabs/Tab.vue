<template>
  <li :class="classes">
    <nuxt-link :id="id || null" class="tab__link" :to="href">
      {{ title }}
    </nuxt-link>
  </li>
</template>

<script>
export default {
  name: 'tab',
  props: {
    id: {
      default: '',
      type: String
    },
    title: {
      default: '',
      type: String
    },
    href: {
      default: '',
      type: String
    },
    isActive: {
      default: false,
      type: Boolean
    }
  },
  data () {
    return {
      classes: {
        'tab': true,
        'tab--active': this.isActive
      }
    }
  }
}
</script>
