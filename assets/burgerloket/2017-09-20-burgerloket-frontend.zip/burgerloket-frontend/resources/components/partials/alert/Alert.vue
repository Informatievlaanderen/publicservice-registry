<template>
  <div :class="classes" v-if="showAlert">
    <a href="" class="alert__close link--icon--close" v-if="isClosable" @click.prevent="showAlert = false"><span class="u-visually-hidden">Sluiten</span></a>
    <div class="alert__icon" aria-hidden="true" v-if="hasIcon"></div>
    <div class="alert__content">
      <div class="alert__title">{{ title }}</div>
      <div class="alert__message">
        <div class="typography">
          <slot></slot>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  name: 'alert',
  props: {
    title: {
      default: '',
      type: String
    },
    type: {
      default: null,
      type: String
    },
    hasIcon: {
      default: true,
      type: Boolean
    },
    isClosable: {
      default: false,
      type: Boolean
    }
  },
  data () {
    return {
      classes: {
        'alert': true,
        'alert--error': this.type === 'error',
        'alert--warning': this.type === 'warning',
        'alert--success': this.type === 'success',
        'alert--cta': this.type === 'cta',
        'alert--closable': this.isClosable
      },
      showAlert: true
    }
  }
}
</script>
