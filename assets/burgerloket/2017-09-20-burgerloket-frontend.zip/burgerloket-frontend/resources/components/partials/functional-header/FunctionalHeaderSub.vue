<template>
  <div class="functional-header__sub">
    <div class="full-content">
      <ul class="functional-header__sub__actions">
        <li class="functional-header__sub__action">
          <a href=""><i class="vi vi-arrow vi-u-180deg vi-u-link" aria-hidden="true"></i>Terug</a>
        </li>
        <li class="functional-header__sub__action">
          <h2 class="functional-header__sub__title">Subtitel</h2>
        </li>
        <li class="functional-header__sub__action">
          andere inhoud
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  name: 'functional-header-sub'
}
</script>
