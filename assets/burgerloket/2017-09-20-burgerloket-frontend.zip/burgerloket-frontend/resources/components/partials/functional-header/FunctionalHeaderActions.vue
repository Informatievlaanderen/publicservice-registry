<template>
  <div class="functional-header__actions">
    <ul>
      <template v-for="action in actions">
        <li v-if="action.to" class="functional-header__action"><a :href="action.to">{{ action.title }}</a></li>
        <li v-else class="functional-header__action">{{ action.title }}</li>
      </template>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'functional-header-actions',
  props: {
    actions: {
      default: null,
      type: Array
    }
  }
}
</script>
