<template>
  <header :class="classes">
    <bl-layout :mod-is-wide="true">
      <slot></slot>
    </bl-layout>
  </header>
</template>

<script>

export default {
  name: 'functional-header',
  props: {
    modHasActions: {
      default: false,
      type: Boolean
    }
  },
  data () {
    return {
      classes: {
        'functional-header': true,
        'functional-header--has-actions': this.modHasActions
      }
    }
  }
}
</script>
