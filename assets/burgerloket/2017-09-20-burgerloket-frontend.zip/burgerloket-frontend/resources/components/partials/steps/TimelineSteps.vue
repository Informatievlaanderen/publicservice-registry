<template>
  <ul class="steps steps--timeline">
    <slot></slot>
  </ul>
</template>

<script>
export default {
  name: 'timeline-steps'
}
</script>
