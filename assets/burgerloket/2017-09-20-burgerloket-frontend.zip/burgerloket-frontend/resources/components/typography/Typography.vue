<template>
  <div class="typography">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'typography'
}
</script>
