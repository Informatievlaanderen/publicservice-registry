<template>
  <div class="u-hr"></div>
</template>

<script>
export default {
  name: 'horizontal-ruler'
}
</script>
