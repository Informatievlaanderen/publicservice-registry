<!-- Wraps all content of the page and is the go-to contentblock for accessibility -->
<template>
  <main id="main" itemprop="mainContentOfPage">
    <slot></slot>
  </main>
</template>
