<template>
	<p>Hier komt de file upload.</p>
</template>

<script>
export default {
  name: 'file-upload'
}
</script>
