<template>
	<div :class="classes" :data-error-id="id">
		<slot></slot>
	</div>
</template>

<script>
export default {
  name: 'form-error',
  props: {
    id: {
      default: '',
      type: String
    }
  },
  data () {
    return {
      classes: {
        'form__error': true
      }
    }
  }
}
</script>
