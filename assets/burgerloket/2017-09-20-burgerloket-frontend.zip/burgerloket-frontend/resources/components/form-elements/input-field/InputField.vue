<template>
  <input type="text" :name="name" :id="id" :class="classes" :disabled="disabled" :value="value" :placeholder="placeholder" v-bind="attributes" /> 
</template>

<script>
export default {
  name: 'input-field',
  props: {
    name: {
      default: '',
      type: String
    },
    value: {
      default: '',
      type: String
    },
    id: {
      default: '',
      type: String
    },
    placeholder: {
      default: '',
      type: String
    },
    disabled: {
      default: false,
      type: Boolean
    },
    modIsBlock: {
      default: false,
      type: Boolean
    },
    modIsSmall: {
      default: false,
      type: Boolean
    },
    modIsError: {
      default: false,
      type: Boolean
    },
    validation: {
      default: null,
      type: Object
    }
  },
  data () {
    return {
      classes: {
        'input-field': true,
        'input-field--block': this.modIsBlock,
        'input-field--small': this.modIsSmall,
        'input-field--error': this.modIsError,
        'input-field--disabled': this.disabled
      },
      attributes: {}
    }
  },
  created () {
    // Possible validations.
    const arrValidations = ['email', 'iban', 'date', 'phone', 'rrn']
    // Check if validation is present.
    if (this.validation) {
      // Add error message
      this.attributes[`data-error-message`] = 'Dit is geen geldige invoer'
      if (this.validation.message) {
        this.attributes[`data-error-message`] = this.validation.message
      }
      // Attach the error to the corresponding placeholder
      this.attributes[`data-error-placeholder`] = this.name
      this.attributes[`data-error-class`] = 'input-field--error'
      // Loop through all validations
      this.validation.validations.forEach(validationRule => {
        // Check if validation validationRule is present inside the possible validations (arrValidations).
        if (!arrValidations.includes(validationRule)) return ''
        // Add validation type
        this.attributes[`data-validation-type`] = validationRule
      })
      // Check if this field is required
      if (this.validation.validations.includes('required')) {
        this.attributes[`data-required`] = true
      }
    }
  }
}
</script>
