<template>
  <div>
    <div class="bl__header" id="vlaanderen-header">
      <bl-widget id="2bf417e74d6b471a8755540205291a9c" lang="nl"/>
    </div>
    <nuxt class="bl__content" />
    <bl-widget id="098c6ea2646d4df38e54a87b0f043a30" lang="nl"/>
  </div>
</template>

<script>
import BlWidget from '~components/widget/Widget.vue'

export default {
  components: {
    BlWidget
  },
  beforeMount () {
    // Ensure the WidgetApi.Language namespace is available.
    window.WidgetApi = window.WidgetApi || {}
    window.WidgetApi.Language = window.WidgetApi.Language || {}
    // Overwrite the language detection and hard code to 'nl'.
    window.WidgetApi.Language.getCurrentLanguage = () => 'nl'
    window.WidgetApi.Language.getDefaultLanguage = () => 'nl'
  }
}
</script>

<style lang="scss">
  .bl__header {
    position: relative;
    z-index: $zindex-bl-header;
  }
  .bl__content {
    position: relative;
    z-index: $zindex-bl-content;
  }
</style>
