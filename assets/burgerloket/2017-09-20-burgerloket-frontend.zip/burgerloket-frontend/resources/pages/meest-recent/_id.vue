<template>
  <div>
    <bl-navigation-header v-if="fileLoaded" :badge="navigationHeaderBadge" :title="file.name + ' ' + $store.getters['session/fullName']">
      <bl-navigation-header-file-detail v-if="file" :file="file" />
    </bl-navigation-header>
    <bl-main>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid>
            <bl-column :cols="[{nom: 9, den: 12}, {nom: 10, den: 12, mod: 'm'}, {nom: 1, den: 1, mod: 's'}]">
              <bl-timeline-steps v-if="file">
                <bl-timeline-steps-item v-for="(historyItem, index) in file.history" :key="index" :date="historyItem.WijzigingsDatum" :title="historyItem.StatusDetail1" :title-has-icon="historyItem.Actie.ActieNodig" title-icon="icon-warning-fill" title-icon-class="bl-step__title__icon icon icon--color-warning" :has-content="historyItem.Actie.Actie">
                  <p>{{ historyItem.Actie.Actie }}</p>
                </bl-timeline-steps-item>
              </bl-timeline-steps>
            </bl-column>
          </bl-grid>
        </bl-layout>
      </bl-region>
    </bl-main>
  </div>
</template>

<script>
import BlNavigationHeader from '~components/navigations/navigation-header/NavigationHeader.vue'
import BlNavigationHeaderFileDetail from '~components/navigations/navigation-header/NavigationHeaderFileDetail.vue'

import BlTimelineSteps from '~components/partials/steps/TimelineSteps.vue'
import BlTimelineStepsItem from '~components/partials/steps/TimelineStepsItem.vue'

export default {
  middleware: ['authenticated'],
  components: {
    BlNavigationHeader,
    BlNavigationHeaderFileDetail,
    BlTimelineSteps,
    BlTimelineStepsItem
  },
  data () {
    return {
      navigationHeaderBadge: {
        type: 'icon',
        icon: 'vibl vibl-document'
      },
      file: {},
      fileLoaded: false
    }
  },
  beforeMount () {
    // Assign self to this.
    const self = this
    // Dispatch files to get all current cases.
    this.$store.dispatch('dosis/files').then(() => {
      // Set current cases.
      const files = self.$store.getters['dosis/files']
      // Check if current case is present in array of cases.
      self.file = files.find((file) => {
        // Return file object or null.
        return file.id === self.$route.params.id || null
      })
      // Set fileLoaded to true to remove the preloading states.
      self.fileLoaded = true
    })
  }
}
</script>
