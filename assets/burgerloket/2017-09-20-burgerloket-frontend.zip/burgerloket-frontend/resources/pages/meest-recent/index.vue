<template>
  <div>
    <bl-accent-header />
    <bl-icon-navigation />
    <bl-main>
      <bl-region>
        <bl-layout :mod-is-wide="true" class="js-equal-height-container">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
              <bl-h type="h2" class="h2">{{ pageSubtitle }}</bl-h>
            </bl-column>
            <template v-if="!cardsLoaded">
              <bl-column>
                <bl-separator :title="new Date().getFullYear().toString()" />
              </bl-column>
              <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 'm'}, {nom: 1, den: 1, mod: 's'}]" v-for="(pl, index) in cards" :key="index" class="js-preloading">
                <bl-preload-card />
              </bl-column>
            </template>
            <template v-else>
              <template v-if="timeline.length">
                <template v-for="(section, index) in timeline">
                  <bl-column>
                    <bl-separator :title="section.year.toString()" />
                  </bl-column>
                  <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 'm'}, {nom: 1, den: 1, mod: 's'}]" v-for="(card, index) in section.items" :key="card.id">
                    <section :class="{'bl-teaser-card bl-teaser-card--has-user-badge': true, 'js-preloading': !cardsLoaded}">
                      <component :is="!cardsLoaded ? 'div' : 'nuxt-link'" :to="'meest-recent/' + card.id" class="bl-teaser-card__cta js-equal-height" data-equal-height="height">
                        <div class="bl-teaser-card__inner">
                          <div class="bl-teaser-card__header">
                            <div class="bl-teaser-card__header__badges">
                              <bl-badge icon="icon-document" :mod-is-accent="true" :mod-is-small="true"></bl-badge>
                            </div>
                            <h1 class="bl-teaser-card__title">
                              <span class="bl-teaser-card__title__label">{{ card.name || null }}</span>
                              <time class="bl-teaser-card__title__timestamp" v-if="card.changed" :datetime="card.changed">
                                {{ $date(card.changed, 'long') }}
                              </time>
                            </h1>
                          </div>
                          <div class="bl-teaser-card__content">
                            <h2 class="bl-teaser-card__subtitle" v-if="card.phase">{{ card.phase.label }}</h2>
                            <div class="bl-teaser-card__description" v-if="card.status">
                              <p>{{ card.status.label }}</p>
                              <p v-if="card.status.requiresAction"><svg role="presentation" v-svg symbol="icon-warning-fill" class="icon icon--color-warning" size="0 0 20 20" aria-hidden="true"></svg> {{ card.status.message }}</p>
                            </div>
                            <!-- <div class="bl-teaser-card__person">
                              <img class="bl-user-badge bl-user-badge--alt" src="https://placehold.it/100x100/465164/ffffff" alt="User badge" />
                            </div> -->
                          </div>
                        </div>
                      </component>
                    </section>
                  </bl-column>
                </template>
              </template>
              <template v-else>
                <bl-column>
                  <bl-alert title="Geen lopende zaken">
                    <p>Je bezit momenteel geen lopende zaken.</p>
                  </bl-alert>
                </bl-column>
              </template>
            </template>
          </bl-grid>
          <!-- <div class="u-spacer"></div>
          <bl-grid :mod-is-stacked="true">
            <bl-column>
              <div class="bl-separator">
                <div class="bl-separator__label">Gemockte content</div>
              </div>
            </bl-column>
            <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 'm'}, {nom: 1, den: 1, mod: 's'}]">
              <section class="bl-teaser-card bl-teaser-card--has-user-badge">
                <a href="#" class="bl-teaser-card__cta js-equal-height" data-equal-height="height">
                  <div class="bl-teaser-card__inner">
                    <div class="bl-teaser-card__header">
                      <div class="bl-teaser-card__badge">
                        <img src="https://placehold.it/100x100/465164/ffffff" srcset="https://placehold.it/100x100/465164/ffffff 1x, https://placehold.it/100x100/465164/ffffff 2x" alt="Teaser card badge" />
                      </div>
                      <h1 class="bl-teaser-card__title">
                        <span class="bl-teaser-card__title__label">Studietoelagen Broos Deprez</span>
                        <time class="bl-teaser-card__title__timestamp" datetime="2017-03-07">7 maart 2017</time>
                      </h1>
                    </div>
                    <div class="bl-teaser-card__content">
                      <h2 class="bl-teaser-card__subtitle">Beslissingsbrief Studietoelage</h2>
                      <div class="bl-teaser-card__description">
                        <p>De studietoelage voor Broos Deprez werd toegekend.</p>
                      </div>
                      <div class="bl-teaser-card__person">
                        <img class="bl-user-badge bl-user-badge--alt bl-user-badge--block" src="https://placehold.it/100x100/465164/ffffff" alt="User badge" />
                        <img class="bl-user-badge bl-user-badge--alt bl-user-badge--block" src="https://placehold.it/100x100/465164/ffffff" alt="User badge" />
                      </div>
                    </div>
                  </div>
                </a>
              </section>
            </bl-column>
            <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 'm'}, {nom: 1, den: 1, mod: 's'}]">
              <section class="bl-teaser-card bl-teaser-card--has-user-badge bl-teaser-card--date">
                <a href="#" class="bl-teaser-card__cta js-equal-height">
                  <div class="bl-teaser-card__date">
                    <time datetime="2011-01-12">
                      <span class="bl-teaser-card__date__day">09</span>
                      <span class="bl-teaser-card__date__month">maa</span>
                      <span class="bl-teaser-card__date__year">2017</span>
                    </time>
                  </div>
                  <div class="bl-teaser-card__inner">
                    <div class="bl-teaser-card__header">
                      <h1 class="bl-teaser-card__title">
                        <span class="bl-teaser-card__title__label">Afspraak Kind en Gezin: Elise Deprez</span>
                      </h1>
                    </div>
                    <div class="bl-teaser-card__content">
                      <h2 class="bl-teaser-card__subtitle">Herinnering</h2>
                      <div class="bl-teaser-card__description">
                        <p>bij Kind en Gezin in Mechelen om 15u</p>
                      </div>
                      <div class="bl-teaser-card__person">
                        <div class="bl-user-badge bl-user-badge--alt" data-initials="ED" aria-hidden="true"="true"></div>
                      </div>
                    </div>
                  </div>
                </a>
              </section>
            </bl-column>
            <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 'm'}, {nom: 1, den: 1, mod: 's'}]">
              <section class="bl-teaser-card">
                <a href="#" class="bl-teaser-card__cta js-equal-height">
                  <div class="bl-teaser-card__inner">
                    <div class="bl-teaser-card__header">
                      <div class="bl-teaser-card__badge bl-teaser-card__badge--alt">
                        <i class="bl-teaser-card__badge__icon vibl vibl-car"></i>
                      </div>
                      <h1 class="bl-teaser-card__title">
                        <span class="bl-teaser-card__title__label">Nieuw voertuig</span>
                        <time class="bl-teaser-card__title__timestamp" datetime="2017-03-02">2 maart 2017</time>
                      </h1>
                    </div>
                    <div class="bl-teaser-card__content">
                      <div class="bl-teaser-card__description">
                        <p>1-PAU-982 is toegevoegd aan uw gegevens</p>
                      </div>
                    </div>
                  </div>
                </a>
              </section>
            </bl-column>
            <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 'm'}, {nom: 1, den: 1, mod: 's'}]">
              <section class="bl-teaser-card">
                <a href="#" class="bl-teaser-card__cta js-equal-height">
                  <div class="bl-teaser-card__inner">
                    <div class="bl-teaser-card__header">
                      <div class="bl-teaser-card__badge bl-teaser-card__badge--yellow">
                        <i class="bl-teaser-card__badge__icon vibl vibl-car" aria-hidden="true"></i>
                      </div>
                      <h1 class="bl-teaser-card__title">
                        <span class="bl-teaser-card__title__label">Bouwvergunning Begijnenstraat</span>
                        <time class="bl-teaser-card__title__timestamp" datetime="2017-02-23">23 februari 2017</time>
                      </h1>
                    </div>
                    <div class="bl-teaser-card__content">
                      <h2 class="bl-teaser-card__subtitle">Statuswijziging</h2>
                      <div class="bl-teaser-card__description">
                        <p>Aanvraag in behandeling</p>
                      </div>
                    </div>
                  </div>
                </a>
              </section>
            </bl-column>
            <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 'm'}, {nom: 1, den: 1, mod: 's'}]">
              <section class="bl-teaser-card">
                <a href="#" class="bl-teaser-card__cta js-equal-height">
                  <div class="bl-teaser-card__inner">
                    <div class="bl-teaser-card__header">
                      <div class="bl-teaser-card__badge">
                        <img src="https://placehold.it/100x100/465164/ffffff" srcset="https://placehold.it/100x100/465164/ffffff 1x, https://placehold.it/100x100/465164/ffffff 2x" alt="Teaser card badge" />
                      </div>
                      <h1 class="bl-teaser-card__title">
                        <span class="bl-teaser-card__title__label">Palliatief verlof</span>
                        <time class="bl-teaser-card__title__timestamp" datetime="2017-01-20">20 januari 2017</time>
                      </h1>
                    </div>
                    <div class="bl-teaser-card__content">
                      <h2 class="bl-teaser-card__subtitle">Belastingsfiche</h2>
                      <div class="bl-teaser-card__description">
                        <p>Belastingsfiche voor uitkeringen in het kader van uw palliatief verlof</p>
                      </div>
                    </div>
                  </div>
                </a>
              </section>
            </bl-column>
            <bl-column>
              <bl-separator title="2015" />
            </bl-column>
            <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 'm'}, {nom: 1, den: 1, mod: 's'}]">
              <section class="bl-teaser-card">
                <a href="#" class="bl-teaser-card__cta js-equal-height">
                  <div class="bl-teaser-card__inner">
                    <div class="bl-teaser-card__header">
                      <div class="bl-teaser-card__badge bl-teaser-card__badge--alt">
                        <i class="bl-teaser-card__badge__icon vibl vibl-car"></i>
                      </div>
                      <h1 class="bl-teaser-card__title">
                        <span class="bl-teaser-card__title__label">Nieuw voertuig</span>
                        <time class="bl-teaser-card__title__timestamp" datetime="2017-03-02">2 maart 2017</time>
                      </h1>
                    </div>
                    <div class="bl-teaser-card__content">
                      <div class="bl-teaser-card__description">
                        <p>1-PAU-982 is toegevoegd aan uw gegevens</p>
                      </div>
                    </div>
                  </div>
                </a>
              </section>
            </bl-column>
            <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 'm'}, {nom: 1, den: 1, mod: 's'}]">
              <section class="bl-teaser-card">
                <a href="#" class="bl-teaser-card__cta js-equal-height">
                  <div class="bl-teaser-card__inner">
                    <div class="bl-teaser-card__header">
                      <div class="bl-teaser-card__badge bl-teaser-card__badge--yellow">
                        <i class="bl-teaser-card__badge__icon vibl vibl-car" aria-hidden="true"></i>
                      </div>
                      <h1 class="bl-teaser-card__title">
                        <span class="bl-teaser-card__title__label">Bouwvergunning Begijnenstraat</span>
                        <time class="bl-teaser-card__title__timestamp" datetime="2017-02-23">23 februari 2017</time>
                      </h1>
                    </div>
                    <div class="bl-teaser-card__content">
                      <h2 class="bl-teaser-card__subtitle">Statuswijziging</h2>
                      <div class="bl-teaser-card__description">
                        <p>Aanvraag in behandeling</p>
                      </div>
                    </div>
                  </div>
                </a>
              </section>
            </bl-column>
            <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 'm'}, {nom: 1, den: 1, mod: 's'}]">
              <section class="bl-teaser-card">
                <a href="#" class="bl-teaser-card__cta js-equal-height">
                  <div class="bl-teaser-card__inner">
                    <div class="bl-teaser-card__header">
                      <div class="bl-teaser-card__badge">
                        <img src="https://placehold.it/100x100/465164/ffffff" srcset="https://placehold.it/100x100/465164/ffffff 1x, https://placehold.it/100x100/465164/ffffff 2x" alt="Teaser card badge" />
                      </div>
                      <h1 class="bl-teaser-card__title">
                        <span class="bl-teaser-card__title__label">Palliatief verlof</span>
                        <time class="bl-teaser-card__title__timestamp" datetime="2017-01-20">20 januari 2017</time>
                      </h1>
                    </div>
                    <div class="bl-teaser-card__content">
                      <h2 class="bl-teaser-card__subtitle">Belastingsfiche</h2>
                      <div class="bl-teaser-card__description">
                        <p>Belastingsfiche voor uitkeringen in het kader van uw palliatief verlof</p>
                      </div>
                    </div>
                  </div>
                </a>
              </section>
            </bl-column>
          </bl-grid> -->
        </bl-layout>
      </bl-region>
    </bl-main>
  </div>
</template>

<script>
// import alert from '~plugins/test'
import BlAlert from '~components/partials/alert/Alert.vue'
import BlAccentHeader from '~components/partials/accent-header/AccentHeader.vue'
import BlIconNavigation from '~components/navigations/icon-navigation/IconNavigation.vue'
import BlSeparator from '~components/partials/separator/Separator.vue'
import BlPreloadCard from '~components/service-components/preload-card/PreloadCard.vue'
import BlBadge from '~components/partials/badge/Badge.vue'

export default {
  middleware: ['authenticated'],
  components: {
    BlAlert,
    BlAccentHeader,
    BlIconNavigation,
    BlSeparator,
    BlPreloadCard,
    BlBadge
  },
  data () {
    return {
      cards: 2,
      cardsLoaded: false,
      pageSubtitle: 'Meest recent',
      timeline: []
    }
  },
  mounted () {
    const self = this
    self.$store.dispatch('dosis/files').then(() => {
      self.timeline = self.$store.getters['dosis/filesTimeline']
      self.cardsLoaded = true
      setTimeout(() => {
        vl.drawer.dressAll()
        vl.equalheight.resize()
      }, 30)
    })
  }
}
</script>
