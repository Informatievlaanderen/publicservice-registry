<template>
  <div>
    <bl-accent-header />
    <bl-icon-navigation />
    <bl-main>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
              <bl-h type="h2" class="h2">Tegemoetkomingen, rechten en voordelen</bl-h>
              <div class="u-spacer"></div>
            </bl-column>
          </bl-grid>
        </bl-layout>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">

            <!-- careerBreaks service works -->
            <template v-if="!$store.getters['tax/careerBreaksFailed']">
              <!-- Preload -->
              <bl-column v-if="careerBreaksLoading">
                <bl-preload-card />
              </bl-column>
              <!-- ./ Preload -->
              <!-- Loaded & data -->
              <bl-column v-if="careerBreaksLoaded && careerBreaks" v-for="(careerBreak, index) in careerBreaks" :key="index">
                <bl-panel>
                  <bl-panel-header :title="careerBreak.category" :badges="[{ icon: 'icon-hand-pig', modIsAlt: true }]" :subtitle="careerBreak.context" :extra="[(careerBreak.dossierId ? {label: 'Dossiernummer ' + careerBreak.dossierId} : ''), (careerBreak.source ? {label: careerBreak.source} : '')]" />
                  <bl-panel-body>
                    <template slot="content">
                      <bl-description-data>
                        <bl-grid :mod-is-stacked="true">
                          <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                            <bl-description-data-item-wrapper v-if="careerBreak.reduction">
                              <bl-description-data-item class-type="subdata">Vermindering</bl-description-data-item>
                              <bl-description-data-item class-type="data">
                                {{ careerBreak.reduction }}
                                <template v-if="careerBreak.additionalActivity">
                                <br><br>
                                Bijkomende activiteit als {{ careerBreak.additionalActivity }}
                                </template>
                              </bl-description-data-item>
                            </bl-description-data-item-wrapper>
                          </bl-column>
                          <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                            <bl-description-data-item-wrapper v-if="careerBreak.from && careerBreak.until">
                              <bl-description-data-item class-type="subdata">Datum</bl-description-data-item>
                              <bl-description-data-item class-type="data"><time :datetime="careerBreak.from.value">{{ $date(careerBreak.from) }}</time> - <time :datetime="careerBreak.until.value">{{ $date(careerBreak.until) }}</time></bl-description-data-item>
                            </bl-description-data-item-wrapper>
                          </bl-column>
                          <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                            <bl-description-data-item-wrapper v-if="careerBreak.amount">
                              <bl-description-data-item class-type="subdata">Bedrag maandelijkse uitkering</bl-description-data-item>
                              <bl-description-data-item class-type="data">{{ careerBreak.amount }} EUR/maand</bl-description-data-item>
                            </bl-description-data-item-wrapper>
                          </bl-column>
                        </bl-grid>
                      </bl-description-data>
                    </template>
                  </bl-panel-body>
                </bl-panel>
              </bl-column>
               <!-- ./ Loaded & data -->
            </template>
            <!-- ./ careerBreaks service works -->

            <!-- assistance service works -->
            <template v-if="!$store.getters['tax/assistanceFailed']">
              <!-- Preload -->
              <bl-column v-if="assistancesLoading">
                <bl-preload-card :mod-has-content="false" />
              </bl-column>
              <!-- ./ Preload -->
              <!-- Loaded & data -->
              <bl-column v-if="assistancesLoaded && assistances" v-for="(assistance, index) in assistances" :key="index">
                <bl-panel>
                  <bl-panel-header :title="assistance.measure" :badges="[{ icon: 'icon-hand-umbrella', modIsAlt: true }]" :subtitle="assistancePanelSubtitle(assistance)" />
                </bl-panel>
              </bl-column>
               <!-- ./ Loaded & data -->
            </template>
            <!-- ./ assistance service works -->

            <!-- Loaded & both empty -->
            <template v-if="!$store.getters['tax/careerBreaksFailed'] && !$store.getters['tax/assistanceFailed'] && assistancesLoaded && !assistances && careerBreaksLoaded && !careerBreaks">
              <bl-column>
                <bl-alert title="Geen gegevens beschikbaar">
                  <p>Er zijn op dit moment geen gegevens beschikbaar.</p>
                </bl-alert>
              </bl-column>
            </template>
            <!-- ./ Loaded & both empty -->

            <!-- Both services failed -->
            <template v-if="$store.getters['tax/careerBreaksFailed'] && $store.getters['tax/assistanceFailed']">
              <bl-column>
                <bl-alert type="error" title="Geen verbinding">
                  <bl-typography>
                    <p>Er kan op dit moment geen verbinding gemaakt worden waardoor we hier uw opvragingen niet kunnen tonen. Van zodra het probleem is opgelost, vind u hier een overzicht van uw geraadpleegde gegevens.</p>
                  </bl-typography>
                </bl-alert>
              </bl-column>
            </template>
            <!-- ./ Both services failed -->

          </bl-grid>
        </bl-layout>
      </bl-region>
    </bl-main>
  </div>
</template>

<script>

import BlAlert from '~components/partials/alert/Alert.vue'
import BlAccentHeader from '~components/partials/accent-header/AccentHeader.vue'
import BlIconNavigation from '~components/navigations/icon-navigation/IconNavigation.vue'
import BlPreloadCard from '~components/service-components/preload-card/PreloadCard.vue'
import BlPanel from '~components/partials/panel/Panel.vue'
import BlPanelHeader from '~components/partials/panel/panel-header/PanelHeader.vue'
import BlPanelBody from '~components/partials/panel/panel-body/PanelBody.vue'
import BlPanelBodyAccordion from '~components/partials/panel/panel-body/PanelBodyAccordion.vue'
import BlDescriptionData from '~components/partials/description-data/DescriptionData.vue'
import BlDescriptionDataItem from '~components/partials/description-data/DescriptionDataItem.vue'
import BlDescriptionDataItemWrapper from '~components/partials/description-data/DescriptionDataItemWrapper.vue'

export default {
  middleware: ['authenticated'],
  components: {
    BlAlert,
    BlAccentHeader,
    BlIconNavigation,
    BlPreloadCard,
    BlPanel,
    BlPanelHeader,
    BlPanelBody,
    BlPanelBodyAccordion,
    BlDescriptionData,
    BlDescriptionDataItem,
    BlDescriptionDataItemWrapper
  },
  data () {
    return {
      pageTitle: 'Uw gegevens bij de overheid',
      pageSubtitle: 'Belastingen & voordelen',
      preloadCards: 3,
      showLoader: false,
      careerBreaks: [],
      careerBreaksLoaded: false,
      careerBreaksLoading: true,
      assistances: [],
      assistancesLoaded: false,
      assistancesLoading: true
    }
  },
  methods: {
    assistancePanelSubtitle (assistance) {
      var subtitleParts = []
      if (assistance.decided) subtitleParts.push('Toegekend op ' + this.$date(assistance.decided))
      if (assistance.from && assistance.until) subtitleParts.push('Geldig van ' + this.$date(assistance.from) + ' tot ' + this.$date(assistance.until))
      return subtitleParts.join(' | ')
    }
  },
  computed: {
  },
  mounted () {
    // Get a reference to ourself.
    const self = this
    // Resolve the careerBreaks.
    self.$store.dispatch('tax/careerBreaks').then(() => {
      // Get the careerBreaks.
      self.careerBreaks = self.$store.getters['tax/careerBreaks']
      // Stop preloading.
      self.careerBreaksLoading = false
      // Mark the careerBreaks as loaded.
      self.careerBreaksLoaded = true
    })
    // Resolve the assistance.
    self.$store.dispatch('tax/assistance').then(() => {
      // Get the assistance.
      self.assistances = self.$store.getters['tax/assistance']
      // Stop preloading.
      self.assistancesLoading = false
      // Mark the assistance as loaded.
      self.assistancesLoaded = true
    })
  }
}
</script>
