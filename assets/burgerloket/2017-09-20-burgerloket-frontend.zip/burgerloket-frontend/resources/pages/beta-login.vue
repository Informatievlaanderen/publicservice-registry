<template>
  <div>
    <bl-content-header :title="pageTitle" />
    <bl-main>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column :cols="[{nom: 8, den: 12}, {nom: 1, den: 1, mod: 's'}]" class="u-spacer">
              <bl-h type="h2" class="h2">Een overheid die je beter begrijpt</bl-h>
              <bl-typography>
                <p>Met de Vlaamse overheid streven we naar een overheid die je beter begrijpt. Daarom kan je vanaf nu zien wat de overheid precies over jou weet, welke overheidsinstanties jouw gegevens hebben geraadpleegd en waarom. Maar je kan ook op elk moment de status van bijvoorbeeld jouw premie- of studietoelage-aanvraag bekijken. We hebben al deze gegevens voor jou samengebracht op jouw persoonlijke pagina. Je hoeft enkel nog aan te melden.</p>
              </bl-typography>
            </bl-column>
            <bl-column :cols="[{nom: 4, den: 12}, {nom: 1, den: 1, mod: 's'}]" class="u-spacer">
              <div class="u-align-center" style="background: #e8ebee">
                <br>
                <i class="vi vi-id" aria-hidden style="font-size: 6rem; color: #cbd2da"></i>
                <br>
                <bl-h type="h3" class="h5">Mijn gegevens bij de overheid</bl-h>
                <br>
                <a href="#" @click.prevent="openLoginModal('login-modal')" class="button">Aanmelden</a>
                <br>
                <br>
              </div>
            </bl-column>
            <bl-column :cols="[{nom: 4, den: 12}, {nom: 1, den: 1, mod: 's'}]" class="u-spacer">
              <img src="https://placehold.it/600x300" width="100%" alt="">
            </bl-column>
            <bl-column :cols="[{nom: 8, den: 12}, {nom: 1, den: 1, mod: 's'}]" class="u-spacer">
              <bl-h type="h2" class="h2">Wat weet de overheid over mij</bl-h>
              <bl-typography>
                <p>Een volledig overzicht van alle gegevens die de overheid over jou weet samengebracht op één plaats. Zijn de gegevens niet correct? Dan kan je dat makkelijk melden. Bovendien kan je ook zien welke overheidsdiensten jouw gegevens hebben opgevraagd en waarvoor ze die gegevens hebben gebruikt.</p>
              </bl-typography>
            </bl-column>
            <bl-column :cols="[{nom: 8, den: 12}, {nom: 1, den: 1, mod: 's'}]" class="u-spacer">
              <bl-h type="h2" class="h2">Lopende zaken</bl-h>
              <bl-typography>
                <p>Heb je aanvraag voor bijvoorbeeld een premie of studietoelage ingediend bij de overheid? Dan kan je via jouw persoonlijke pagina de status van de aanvraag opvolgen. Zo weet je precies hoe het staat met jouw aanvraag en wie jouw dossierbeheerder is.</p>
              </bl-typography>
            </bl-column>
            <bl-column :cols="[{nom: 4, den: 12}, {nom: 1, den: 1, mod: 's'}]" class="u-spacer">
              <img src="https://placehold.it/600x300" width="100%" alt="">
            </bl-column>
            <bl-column :cols="[{nom: 4, den: 12}, {nom: 1, den: 1, mod: 's'}]" class="u-spacer">
              <img src="https://placehold.it/600x300" width="100%" alt="">
            </bl-column>
            <bl-column :cols="[{nom: 8, den: 12}, {nom: 1, den: 1, mod: 's'}]">
              <bl-h type="h2" class="h2">Meldingen</bl-h>
              <bl-typography>
                <p>Meldingen houden je pro-actief op de hoogte van zaken die van belang voor u zijn. Is bijvoorbeeld de status van uw aanvraag gewijzigd, dan krijgt u hiervan een melding. Deze meldingen ontvang je hier, maar als je wil, kan dat ook per e-mail of SMS. Dat beheer je gemakkelijk in jouw voorkeuren op jouw persoonlijke pagina.</p>
              </bl-typography>
            </bl-column>
          </bl-grid>
        </bl-layout>
      </bl-region>
      <bl-column>
        <div class="u-align-center" style="background: #e8ebee">
          <br>
          <br>
          <br>
          <i class="vi vi-id" aria-hidden style="font-size: 8rem; color: #cbd2da"></i>
          <br>
          <bl-h type="h3" class="h3">Mijn gegevens bij de overheid</bl-h>
          <a href="#" @click.prevent="openLoginModal('login-modal')" class="button">Aanmelden</a>
          <br>
          <br>
          <br>
          <br>
        </div>
      </bl-column>
    </bl-main>

    <div class="modals">

      <div class="bl-modal" id="login-modal">
        <div class="bl-modal__backdrop"></div>
        <div class="bl-modal__content">
          <header class="functional-header" role="banner">
            <div class="layout layout--wide">
              <div class="functional-header__content">
                <h1 class="functional-header__title">Burgerloket - Aanmelden</h1>
              </div>
            </div>
          </header>

          <div class="region">
            <div class="layout layout--wide">
              <div class="grid grid--is-stacked js-equal-height-container u-spacer">
                <div class="col--8-12 col--12-12--s">
                  <div class="progress-bar u-spacer">
                    <div class="progress-bar__step progress-bar__step--active">
                      <div class="progress-bar__bullet progress-bar__bullet--current">
                        <div class="tooltip tooltip--top tooltip--static" style="min-width: 19rem;">
                          <div class="tooltip__content"><span class="u-visually-hidden">Stap 1 van 4: </span>Kies manier van aanmelden</div>
                          <div class="tooltip__arrow"></div>
                        </div>
                      </div>
                    </div>
                    <div class="progress-bar__step">
                      <div class="progress-bar__bullet"></div>
                    </div>
                    <div class="progress-bar__step">
                      <div class="progress-bar__bullet"></div>
                    </div>
                    <div class="progress-bar__step">
                      <div class="progress-bar__bullet"></div>
                    </div>
                  </div>
                  <div class="typography u-spacer">
                    <p>Kies hieronder hoe u wil aanmelden. Klik op "meer info" voor uitleg over die manier van aanmelden. Klik op de knop "hulp nodig?" (rechts) voor veelgestelde vragen over aanmelden of om contact op te nemen met de helpdesk.</p>
                  </div>
                 </div>
                 <div class="col--8-12 col--1-1--s">
                  <div class="grid grid--is-stacked">
                    <li class="col--1-2 col--1-1--m col--flex col--col">
                      <div class="auth-method auth-method--highlight">
                        <a class="auth-method__action js-equal-height" href="javascript:;" @click.prevent="handleLogin('login-modal', 'acm-modal')">
                          <i class="auth-method__bullet vi vi-u-badge vi-u-badge--small vi-u-badge--action vi-arrow" aria-hidden="true"></i>
                          <div class="auth-method__icon">
                            <img src="/img/CSAM-kaartlezer-icon.png" alt="" class="auth-method__icon__img">
                          </div>
                          <div class="auth-method__header">
                            <div class="auth-method__title"><span class="auth-method__title__text">eID en aangesloten kaartlezer</span></div>
                              <div class="auth-method__label">Veiligste keuze</div>
                          </div>
                            <div class="auth-method__info-placeholder" aria-hidden="true">meer info</div>
                        </a>
                      </div>
                    </li>
                    <li class="col--1-2 col--1-1--m col--flex col--col">
                      <div class="auth-method  auth-method--highlight  ">
                        <a class="auth-method__action  js-equal-height" href="javascript:;" @click.prevent="handleLogin('login-modal', 'acm-modal')" style="min-height: 162px;">
                          <i class="auth-method__bullet vi vi-u-badge vi-u-badge--small vi-u-badge--action vi-arrow" aria-hidden="true"></i>
                          <div class="auth-method__icon">
                            <img src="/img/CSAM-app-icon.png" alt="" class="auth-method__icon__img">
                          </div>
                          <div class="auth-method__header">
                            <div class="auth-method__title"><span class="auth-method__title__text">Beveiligingscode via mobiele app</span> </div>
                              <div class="auth-method__label">Gemakkelijkste keuze</div>
                          </div>
                            <div class="auth-method__info-placeholder" aria-hidden="true">meer info</div>
                            <div class="auth-method__text">Eerste gebruik? Manier van aanmelden eerst activeren.</div>
                        </a>
                      </div>
                    </li>
                    <li class="col--1-2 col--1-1--m col--flex col--col">
                      <div class="auth-method  auth-method--highlight  ">
                        <a class="auth-method__action  js-equal-height" href="javascript:;" @click.prevent="handleLogin('login-modal', 'acm-modal')" style="min-height: 162px;">
                          <i class="auth-method__bullet vi vi-u-badge vi-u-badge--small vi-u-badge--action vi-arrow" aria-hidden="true"></i>
                          <div class="auth-method__icon">
                            <img src="/img/optie-3.png" alt="" class="auth-method__icon__img">
                          </div>
                          <div class="auth-method__header">
                            <div class="auth-method__title"><span class="auth-method__title__text">eID en draadloze kaartlezer</span> </div>
                          </div>
                            <div class="auth-method__info-placeholder" aria-hidden="true">meer info</div>
                            <div class="auth-method__text">Eerste gebruik? Manier van aanmelden eerst activeren.</div>
                        </a>
                      </div>
                    </li>
                    <li class="col--1-2 col--1-1--m col--flex col--col">
                      <div class="auth-method  auth-method--highlight  ">
                        <a class="auth-method__action  js-equal-height" href="javascript:;" @click.prevent="handleLogin('login-modal', 'acm-modal')" style="min-height: 162px;">
                          <i class="auth-method__bullet vi vi-u-badge vi-u-badge--small vi-u-badge--action vi-arrow" aria-hidden="true"></i>
                          <div class="auth-method__icon">
                            <img src="/img/optie-4.png" alt="" class="auth-method__icon__img">
                          </div>
                          <div class="auth-method__header">
                            <div class="auth-method__title"><span class="auth-method__title__text">Beveiligingscode via SMS</span> </div>
                          </div>
                            <div class="auth-method__info-placeholder" aria-hidden="true">meer info</div>
                            <div class="auth-method__text">Eerste gebruik? Manier van aanmelden eerst activeren.</div>
                        </a>
                      </div>
                    </li>
                  </div>
                 </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="bl-modal" id="acm-modal">
        <div class="bl-modal__backdrop"></div>
        <div class="bl-modal__content">
          <div class="bl-modal__content__inner" style="position: relative;">
            <nuxt-link to="/beta-logged-in">
            <img src="/img/acm-bg.png" style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; object-fit: cover; cursor: pointer;" />
            </nuxt-link>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

import BlContentHeader from '~components/partials/content-header/ContentHeader.vue'

export default {
  components: {
    BlContentHeader
  },
  data () {
    return {
      pageTitle: 'Vlaanderen.be'
    }
  },
  methods: {
    openLoginModal (id) {
      const modal = document.getElementById(id)

      if (!hasClass(document.body, 'body--has-modal')) {
        addClass(document.body, 'body--has-modal')
        addClass(modal, 'bl-modal--active')
      }

      const backdrop = modal.getElementsByClassName('bl-modal__backdrop')[0]
      backdrop.addEventListener('click', e => {
        removeClass(document.body, 'body--has-modal')
        removeClass(modal, 'bl-modal--active')
      })
    },
    handleLogin (oldId, newId) {
      const oldmodal = document.getElementById(oldId)
      removeClass(oldmodal, 'bl-modal--active')
      const newModal = document.getElementById(newId)
      addClass(newModal, 'bl-modal--active')

      const backdrop = newModal.getElementsByClassName('bl-modal__backdrop')[0]
      backdrop.addEventListener('click', e => {
        removeClass(document.body, 'body--has-modal')
        removeClass(newModal, 'bl-modal--active')
      })
    },
    alertMessage () {

    }
  }
}
</script>
