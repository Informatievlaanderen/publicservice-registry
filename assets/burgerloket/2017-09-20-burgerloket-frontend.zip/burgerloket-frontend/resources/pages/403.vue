<template>
  <div>
    <bl-content-header :data="{ title: pageTitle }" />
    <bl-main>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
              <bl-h type="h2" class="h2">{{ errorCode }} - Geen toegang</bl-h>
              <bl-typography>
                <p>U beschikt niet over de juiste rechten om deze pagina te bekijken. <nuxt-link to="/">Ga naar de homepage</nuxt-link>.</p>
              </bl-typography>
            </bl-column>
          </bl-grid>
        </bl-layout>
      </bl-region>
    </bl-main>
  </div>
</template>

<script>

import BlContentHeader from '~components/partials/content-header/ContentHeader.vue'

export default {
  components: {
    BlContentHeader
  },
  data () {
    return {
      pageTitle: 'Burgerloket',
      errorCode: '403'
    }
  }
}
</script>
