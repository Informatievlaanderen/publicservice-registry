<template>
  <div>
    <bl-accent-header />
    <bl-icon-navigation />
    <bl-main>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
                <bl-h type="h2" class="h2">{{ pageSubtitle }}</bl-h>
            </bl-column>
            <bl-column>
              <bl-typography>
                <p>
                  Hier vindt u een chronologisch overzicht van uw diploma’s en leerbewijzen die bekend zijn bij de Vlaamse Overheid. Opgelet: niet elke diploma is opgenomen. We starten vanaf 1999 of 2013, afhankelijk van het type opleiding.
                </p>
              </bl-typography>
              <!--<a v-if="$store.getters['education/eventsReference'] !== null" class="link--icon--external link--icon--after" :href="$store.getters['education/eventsReference'].url" target="_BLANK">Bekijk meer details in de {{ $store.getters['education/eventsReference'].label }}</a>-->
              <a href="#">Welke diploma's worden vermeld en welke niet?</a>
            </bl-column>
            <template v-if="!$store.getters['education/eventsFailed']">
              <template v-if="!educationEventsTimelineLoaded">
                <bl-column>
                  <bl-separator :title="new Date().getFullYear()" />
                </bl-column>
                <bl-column v-for="(pl, index) in mockEducationEventsTimeline" :key="index" class="js-preloading">
                  <bl-preload-card />
                </bl-column>
              </template>
              <template v-else>
                <template v-if="educationEventsTimeline.length">
                  <bl-column v-for="(educationEvent, i) in educationEventsTimeline" :key="i">
                    <bl-separator :title="(educationEvent.year === null || educationEvent.year === 0 ? 'Datum ongekend' : educationEvent.year)" />
                    <bl-grid :mod-is-stacked="true">
                      <bl-column v-for="(item, j) in educationEvent.items" :key="j">
                        <template v-if="item.type === 'default'">
                          <bl-education-card :data="item" />
                        </template>
                        <template v-if="item.type === 'dutch-language'">
                          <bl-dutch-language-card :data="item" />
                        </template>
                        <template v-if="item.type === 'integration'">
                          <bl-integration-card :data="item" />
                        </template>
                      </bl-column>
                    </bl-grid>
                  </bl-column>
                </template>
                <template v-else>
                  <bl-column>
                    <bl-alert title="Geen behaalde leer- en ervaringsbewijzen">
                      <p>U bezit momenteel geen behaalde leer- en ervaringsbewijzen.</p>
                    </bl-alert>
                  </bl-column>
                </template>
              </template>
            </template>
            <template v-else>
              <bl-column>
                <bl-alert type="error" title="Geen verbinding">
                  <bl-typography>
                    <p>Er kan op dit moment geen verbinding gemaakt worden waardoor we hier uw behaalde leer- en ervaringsbewijzen niet kunnen tonen. Van zodra het probleem is opgelost, vindt u hier een overzicht van uw leer- en ervaringsbewijzen.</p>
                  </bl-typography>
                </bl-alert>
              </bl-column>
            </template>
          </bl-grid>
        </bl-layout>
      </bl-region>
    </bl-main>
  </div>
</template>

<script>

import BlAlert from '~components/partials/alert/Alert.vue'
import BlAccentHeader from '~components/partials/accent-header/AccentHeader.vue'
import BlIconNavigation from '~components/navigations/icon-navigation/IconNavigation.vue'
import BlPreloadCard from '~components/service-components/preload-card/PreloadCard.vue'
import BlEducationCard from '~components/service-components/education-card/EducationCard.vue'
import BlDutchLanguageCard from '~components/service-components/dutch-language-card/DutchLanguageCard.vue'
import BlIntegrationCard from '~components/service-components/integration-card/IntegrationCard.vue'
import BlHSublink from '~components/typography/HSublink.vue'
import BlSeparator from '~components/partials/separator/Separator.vue'

export default {
  middleware: ['authenticated'],
  components: {
    BlAlert,
    BlAccentHeader,
    BlIconNavigation,
    BlPreloadCard,
    BlEducationCard,
    BlDutchLanguageCard,
    BlIntegrationCard,
    BlHSublink,
    BlSeparator
  },
  data () {
    return {
      pageSubtitle: 'Onderwijsloopbaan',
      mockEducationEventsTimeline: 2,
      educationEventsTimeline: [],
      educationEventsTimelineLoaded: false
    }
  },
  mounted () {
    // Get a reference to ourself.
    const self = this
    // Resolve the Education Events.
    self.$store.dispatch('education/events').then(() => {
      // Get the education events timeline.
      self.educationEventsTimeline = self.$store.getters['education/eventsTimeline']
      // Mark the education events timeline as loaded.
      self.educationEventsTimelineLoaded = true
      // Dress the components using Flanders UI.
      setTimeout(() => { vl.accordion.dressAll() }, 10)
    })
  }
}
</script>
