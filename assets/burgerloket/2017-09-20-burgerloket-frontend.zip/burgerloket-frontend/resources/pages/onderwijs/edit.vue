<template>
  <div>
    <bl-accent-header />
    <bl-icon-navigation />
    <bl-main>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
              <bl-h type="h2" class="h2">{{ pageSubtitle }}</bl-h>
              <bl-alert type="success" :has-icon="false">
                <p>U bevindt zich in de <strong>bewerkingsmodus</strong>. Als u terug naar het overzicht wilt gaan, <nuxt-link to="/uw-gegevens-bij-de-overheid/onderwijs">klik hier</nuxt-link>.</p>
              </bl-alert>
            </bl-column>
            <bl-column>
             <div class="bl-card">
                <div class="bl-card__header">
                  <div class="bl-card__header__inner">
                    <div class="bl-card__badges" aria-hidden="true">
                      <bl-badge :mod-is-placeholder="true"></bl-badge>
                    </div>
                    <div class="bl-card__header__content">
                      <h1 class="bl-card__header__title">Een diploma of certificaat dat u behaald ontbreekt?</h1>
                      <h2 class="bl-card__header__meta">Meld het ons, zodat wij kunnen verifiëren en toevoegen.</h2>
                      <button type="button" :class="{ 'button': true, 'bl-card__header__button': true, 'button--secondary' : educationAddOpen}" @click="toggleAddEducation">{{ educationAddOpen ? 'Annuleren' : 'Diploma toevoegen' }}</button>
                    </div>
                  </div>
                </div>
                <div class="bl-card__content" v-show="educationAddOpen">
                  <div class="bl-card__content__accordion js-accordion js-accordion--open">
                    <div class="accordion__content">
                      <div class="bl-card__content__accordion__content">
                        <form class="form" action="">
                          <bl-alert type="success" title="Wijziging is doorgegeven" :is-closable="true">
                            <p>We hebben uw foutmelding ontvangen en gaan meteen aan de slag om de fout te verbeteren. U wordt op de hoogte gehouden via het e-mailadres thomas.deprez@gmail.com</p>
                          </bl-alert>
                          <bl-grid :mod-is-stacked="true">
                            <bl-column :cols="[{nom: 1, den: 2}, {nom: 2, den: 3, mod: 'm'}, {nom: 1, den: 1, mod: 's'}]">
                              <div class="u-spacer--small">
                                <p>Vertel ons welke gegevens hier ontbreken zodat we het kunnen corrigeren (gemockte data)</p>
                              </div>
                              <div class="u-spacer--tiny">
                                <bl-select name="onderwerp-select" label="Kies onderwerp" :options="onderwerpSelectOptions" :mod-show-label="false" :mod-is-block="true" />
                              </div>
                              <div class="u-spacer--small">
                                <bl-textarea name="add-extra-opmerkingen" label="Bericht" :mod-show-label="false" :mod-is-block="true" />
                                <bl-file-upload />
                              </div>
                              <div class="u-spacer--small">
                                <label class="checkbox checkbox--block u-spacer">
                                  <input checked type="checkbox" name="add-notify-me" class="checkbox__toggle" data-show-checked="true" data-show-checked-target="add-notify-me" value="1"> <span></span>Houd me op de hoogte van de status van mijn melding
                                </label>
                                <div class="js-show-checked js-show-checked--open" data-show-checked-trigger="add-notify-me">
                                  <bl-input-field name="notify-me-email" label="E-mailadres" :mod-show-label="false" :mod-is-block="true" />
                                </div>
                              </div>
                              <div class="button-group">
                                <button type="submit" class="button">Wijzigingen verzenden</button>
                                <button type="button" class="button button--secondary" @click="educationAddOpen = false">Annuleren</button>
                              </div>
                            </bl-column>
                          </bl-grid>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </bl-column>
            <template v-if="!$store.getters['education/eventsFailed']">
              <template v-if="!educationEventsTimelineLoaded">
                <bl-column>
                  <bl-separator :title="new Date().getFullYear().toString()" />
                </bl-column>
                <bl-column v-for="(pl, index) in mockEducationEventsTimeline" :key="index" class="js-preloading">
                  <bl-preload-card />
                </bl-column>
              </template>
              <template v-else>
                <template v-if="educationEventsTimeline.length">
                  <bl-column v-for="(educationEvent, i) in educationEventsTimeline" :key="i">
                    <bl-grid :mod-is-stacked="true">
                      <bl-column v-for="(item, j) in educationEvent.items" :key="j">
                        <template v-if="item.type === 'default'">
                          <bl-education-card-edit :data="item" />
                        </template>
                      </bl-column>
                    </bl-grid>
                  </bl-column>
                </template>
                <template v-else>
                  <bl-column>
                    <bl-alert title="Geen behaalde leer- en ervaringsbewijzen">
                      <p>Je bezit momenteel geen behaalde leer- en ervaringsbewijzen.</p>
                    </bl-alert>
                  </bl-column>
                </template>
              </template>
            </template>
            <template v-else>
              <bl-column>
                <bl-alert type="error" title="Geen verbinding">
                  <bl-typography>
                    <p>Er kan op dit moment geen verbinding gemaakt worden waardoor we hier uw behaalde leer- en ervaringsbewijzen niet kunnen tonen. Van zodra het probleem is opgelost, vindt u hier een overzicht van uw leer- en ervaringsbewijzen.</p>
                  </bl-typography>
                </bl-alert>
              </bl-column>
            </template>
          </bl-grid>
        </bl-layout>
      </bl-region>
    </bl-main>
  </div>
</template>

<script>

import BlAlert from '~components/partials/alert/Alert.vue'
import BlAccentHeader from '~components/partials/accent-header/AccentHeader.vue'
import BlIconNavigation from '~components/navigations/icon-navigation/IconNavigation.vue'
import BlPreloadCard from '~components/service-components/preload-card/PreloadCard.vue'
import BlEducationCardEdit from '~components/service-components/education-card/EducationCardEdit.vue'
import BlHSublink from '~components/typography/HSublink.vue'
import BlSeparator from '~components/partials/separator/Separator.vue'
import BlBadge from '~components/partials/badge/Badge.vue'

import BlCheckbox from '~components/form-elements/checkbox/Checkbox.vue'
import BlInputField from '~components/form-elements/input-field/InputField.vue'
import BlTextarea from '~components/form-elements/textarea/Textarea.vue'
import BlSelect from '~components/form-elements/select/Select.vue'
import BlFileUpload from '~components/form-elements/file-upload/FileUpload.vue'

export default {
  middleware: ['authenticated'],
  components: {
    BlAlert,
    BlAccentHeader,
    BlIconNavigation,
    BlPreloadCard,
    BlEducationCardEdit,
    BlHSublink,
    BlSeparator,
    BlBadge,
    BlCheckbox,
    BlInputField,
    BlTextarea,
    BlSelect,
    BlFileUpload
  },
  data () {
    return {
      pageSubtitle: 'Onderwijsloopbaan',
      mockEducationEventsTimeline: 2,
      educationEventsTimeline: [],
      educationEventsTimelineLoaded: false,
      educationAddOpen: false,
      onderwerpSelectOptions: [
        {
          type: 'option',
          value: '',
          label: '-- Kies onderwerp --'
        },
        {
          type: 'optgroup',
          label: 'Eerste groep met opties',
          options: [
            {
              value: '1',
              label: 'Optie 1'
            },
            {
              value: '2',
              label: 'Optie 2'
            },
            {
              value: '3',
              label: 'Optie 3'
            }
          ]
        },
        {
          type: 'optgroup',
          label: 'Andere groep met opties',
          options: [
            {
              value: '4',
              label: 'Optie 4'
            },
            {
              value: '5',
              label: 'Optie 5'
            },
            {
              value: '6',
              label: 'Optie 6'
            }
          ]
        }
      ]
    }
  },
  mounted () {
    // Get a reference to ourself.
    const self = this
    // Resolve the Education Events.
    self.$store.dispatch('education/events').then(() => {
      // Get the education events timeline.
      self.educationEventsTimeline = self.$store.getters['education/eventsTimeline']
      // Mark the educatione events timeline as loaded.
      self.educationEventsTimelineLoaded = true
      // Dress the components using Flanders UI.
      setTimeout(() => { vl.accordion.dressAll() }, 10)
      setTimeout(() => { vl.input.showOnChecked.dressAll() }, 10)
    })
  },
  methods: {
    toggleAddEducation () {
      this.educationAddOpen = !this.educationAddOpen
    }
  }
}
</script>
