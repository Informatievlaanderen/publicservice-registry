<template>
  <div>
    <bl-content-header :parent="{title: parentTitle, to: '/'}" :title="pageTitle" />
    <bl-main>
      <bl-region type="section">
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
              <bl-h type="h2" class="h2">Selecteer een rijksregisternummer</bl-h>
            </bl-column>
            <bl-column v-for="(testCaseGroup, index) in testCases" :key="index">
              <bl-h type="h3" class="h3">{{ testCaseGroup.label }}</bl-h>
              <form action="/api/v1/session/switch-token" method="POST">
                <div class="search search--block">
                  <select class="select search__input" required name="token">
                    <option v-for="(testCase, index) in testCaseGroup.items" :value="testCase.token">{{ (index+1) }} - {{ testCase.token }} - {{ testCase.label }}</option>
                  </select>
                  <input class="button search__submit" type="submit" value="Aanmelden" />
                </div>
                <!-- <div class="u-spacer--small"></div>
                <div class="form__annotation">Normaal gebeurt de aanmelding via ACM authenticatie hierboven. Sinds dit aan de ACM-kant nog niet op punt staat halen we rechtstreeks via het rijksregisternummer de lopende zaken op van een persoon.</div> -->
              </form>
            </bl-column>
            <bl-column>
              <bl-h type="h2" class="h3">Zelf ingeven</bl-h>
              <form action="/api/v1/session/switch-token" method="POST">
                <div class="search search--block">
                  <input class="search__input input-field" placeholder="Zonder puntjes of streepjes" type="number" required name="token">
                  <input class="button search__submit" type="submit" value="Aanmelden" />
                </div>
              </form>
            </bl-column>
          </bl-grid>
        </bl-layout>
      </bl-region>
    </bl-main>
  </div>
</template>

<script>

import { mapGetters } from 'vuex'

import BlContentHeader from '~components/partials/content-header/ContentHeader.vue'

export default {
  middleware: ['authenticated'],
  components: {
    BlContentHeader
  },
  data () {
    return {
      pageTitle: 'Aanmelden',
      parentTitle: 'Vlaanderen.be',
      initialTestCases: [
        // Hardcoded Dosis Test Cases as they do not
        // provide a service to retrieve these.
        {
          label: 'Dosis Test Cases',
          items: [
            // { token: '76093011166', label: 'Fase 6 - Afgerond (we behandelen uw dossier)' },
            // { token: '99031745667', label: 'Fase 2 - Behandeling (we behandelen uw dossier)' },
            // { token: '80123199830', label: 'Fase 1 - Samenstelling' },
            { token: '12030899834', label: 'Fase 1 - Samenstelling' },
            { token: '83111899789', label: 'Fase 6 - Afgerond (we hebben de betaling uitgevoerd)' },
            { token: '88042099884', label: 'Fase 1+2 - Meerdere records + onderwijsgebeurtenissen' },
            { token: '78100799716', label: 'Officiële demo data studietoelagen via Magda Gateway' }
          ]
        },
        // Hardcoded Notification Test Cases as they do not
        // provide a service to retrieve these.
        {
          label: 'Notificatie Test Cases',
          items: [
            { token: '74042899736', label: 'Studietoelagen' },
            { token: '80020399824', label: 'Test van Joost' },
            { token: '02030399644', label: 'Lopende Zaken - A' },
            { token: '98090499635', label: 'Lopende Zaken - B' },
            { token: '81020599783', label: 'Developer Test Case' },
            { token: '02030399644', label: 'Notificatie met body' }
          ]
        }
      ]
    }
  },
  computed: {
    ...mapGetters({
      educationTestCases: 'education/testCases',
      auditTestCases: 'audit/testCases',
      personTestCases: 'person/testCases',
      accommodationTestCases: 'accommodation/testCases',
      taxTestCases: 'tax/testCases'
    }),
    testCases () {
      return [].concat(
        this.initialTestCases,
        this.educationTestCases,
        this.auditTestCases,
        this.personTestCases,
        this.accommodationTestCases,
        this.taxTestCases
      ).filter((testCaseGroup) => testCaseGroup.items.length > 0)
    }
  },
  mounted () {
    // Trigger fetching of test cases
    this.$store.dispatch('education/testCases')
    this.$store.dispatch('audit/testCases')
    this.$store.dispatch('person/testCases')
    this.$store.dispatch('accommodation/testCases')
    this.$store.dispatch('tax/testCases')
  }
}
</script>
