<template>
  <div>
    <bl-main>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
              <form class="form" action="" data-validate-form>

                <!-- Inputfield -->
                <bl-separator title="Inputfield" />

                <bl-form-row>
                  <bl-label for="inputfield-1" :mod-is-hidden="true">Inputfield label</bl-label>
                  <bl-input-field name="inputfield-1" id="inputfield-1" placeholder="Inputfield label" />
                </bl-form-row>

                <bl-form-row>
                  <bl-label for="inputfield-2" :mod-is-block="true">Inputfield label</bl-label>
                  <bl-input-field name="inputfield-2" placeholder="Inputfield label" />
                </bl-form-row>

                <bl-form-row>
                  <bl-input-field name="inputfield-3" placeholder="Inputfield label" :mod-is-block="true" />
                </bl-form-row>

                <bl-form-row>
                  <bl-input-field name="inputfield-4" placeholder="Inputfield label" :disabled="true" />
                </bl-form-row>

                <bl-form-row>
                  <bl-input-field name="inputfield-5" placeholder="Inputfield label" :mod-is-small="true" />
                </bl-form-row>

                <bl-form-row>
                  <bl-input-field name="inputfield-6" placeholder="Inputfield label" :mod-is-error="true" />
                  <bl-form-error>Ongeldige invoer</bl-form-error>
                </bl-form-row>

                <bl-form-row>
                  <bl-input-field name="inputfield-7" placeholder="Telefoonnummer" :validation="{validations: ['required','phone'], message: 'Dit is geen geldig telefoonnummer'}" />
                  <bl-form-error id="inputfield-7"></bl-form-error>
                </bl-form-row>

                <!-- Textarea -->
                <bl-separator title="Textarea" />

                <bl-form-row>
                  <bl-textarea name="textarea-1" placeholder="Inputfield label" />
                </bl-form-row>

                <bl-form-row>
                  <bl-textarea name="textarea-2" placeholder="Inputfield label" :mod-is-block="true" />
                </bl-form-row>

                <bl-form-row>
                  <bl-textarea name="textarea-3" placeholder="Inputfield label" :mod-is-block="true" :disabled="true" />
                </bl-form-row>

                <bl-form-row>
                  <bl-textarea name="textarea-4" placeholder="Inputfield label" :mod-is-block="true" :mod-is-error="true" />
                  <bl-form-error>Ongeldige invoer</bl-form-error>
                </bl-form-row>

                <!-- Select -->
                <bl-separator title="Select" />

                <bl-form-row>
                  <bl-label for="select-1">Inputfield label</bl-label>
                  <bl-select name="select-1" id="select-1" :options="selectOptions" />
                </bl-form-row>

                <bl-form-row>
                  <bl-select name="select-2" :options="selectOptions" :mod-is-block="true" />
                </bl-form-row>

                <bl-form-row>
                  <bl-select name="select-3" :options="selectOptions" :mod-is-block="true"/>
                </bl-form-row>
                
                <bl-form-row>
                  <bl-select name="select-4" :options="selectOptionsWithDefault" />
                </bl-form-row>
                
                <bl-form-row>
                  <bl-select name="select-5" :options="selectOptions" :mod-is-block="true" :mod-is-error="true" />
                  <bl-form-error>Ongeldige keuze</bl-form-error>
                </bl-form-row>
                
                <bl-form-row>
                  <bl-select name="select-6" :options="selectOptions" :disabled="true" />
                </bl-form-row>

                <!-- Checkbox -->
                <bl-separator title="Checkbox" />
                
                <bl-form-row>
                  <bl-checkbox name="checkbox-1" label="Option" />
                </bl-form-row>
                
                <bl-form-row>
                  <bl-checkbox name="checkbox-2" label="Option 1" :checked="true" />
                </bl-form-row>
                
                <bl-form-row>
                  <bl-checkbox name="checkbox-3" label="Option 1" :mod-is-error="true" />
                </bl-form-row>
                
                <bl-form-row>
                  <bl-checkbox name="checkbox-4" label="Option 1" :disabled="true" />
                </bl-form-row>
                
                <bl-form-row>
                  <bl-checkbox name="checkbox-5" label="Option 1" />
                  <bl-checkbox name="checkbox-5" label="Option 2" />
                  <bl-checkbox name="checkbox-5" label="Option 3" />
                </bl-form-row>

                <bl-form-row>
                  <bl-checkbox name="checkbox-6" label="Option 1" :mod-is-block="true" />
                  <bl-checkbox name="checkbox-6" label="Option 2" :mod-is-block="true" />
                  <bl-checkbox name="checkbox-6" label="Option 3" :mod-is-block="true" />
                </bl-form-row>

                <bl-form-row>
                  <bl-checkbox-switch name="checkbox-7" label="Option" :checked="true" />
                </bl-form-row>

                <!-- Radio button -->
                <bl-separator title="Radiobutton" />
                
                <bl-form-row>
                  <bl-radio-button name="radio-button-1" label="Option" />
                </bl-form-row>
                
                <bl-form-row>
                  <bl-radio-button name="radio-button-2" label="Option 1" :checked="true" />
                </bl-form-row>
                
                <bl-form-row>
                  <bl-radio-button name="radio-button-3" label="Option 1" :mod-is-error="true" />
                </bl-form-row>
                
                <bl-form-row>
                  <bl-radio-button name="radio-button-4" label="Option 1" :disabled="true" />
                </bl-form-row>

                <bl-form-row>
                  <bl-radio-button name="radio-button-5" label="Option 1" />
                  <bl-radio-button name="radio-button-5" label="Option 2" />
                  <bl-radio-button name="radio-button-5" label="Option 3" />
                </bl-form-row>

                <bl-form-row>
                  <bl-radio-button name="radio-button-6" label="Option 1" :mod-is-block="true" />
                  <bl-radio-button name="radio-button-6" label="Option 2" :mod-is-block="true" />
                  <bl-radio-button name="radio-button-6" label="Option 3" :mod-is-block="true" />
                </bl-form-row>

                <!-- Button -->
                <bl-separator title="Button" />

                <bl-form-row>
                  <bl-button label="Button 1" id="testbutton"></bl-button>
                </bl-form-row>

                <bl-form-row>
                  <bl-button label="Button 2" :mod-is-secondary="true"></bl-button>
                </bl-form-row>

                <bl-form-row>
                  <bl-button label="Button 3" :mod-is-warning="true"></bl-button>
                </bl-form-row>

                <bl-form-row>
                  <bl-button label="Button 4" :disabled="true"></bl-button>
                </bl-form-row>

                <bl-form-row>
                  <bl-button label="Button 5" :mod-is-block="true"></bl-button>
                </bl-form-row>

                <bl-form-row>
                  <bl-button label="Button 6" :mod-is-large="true"></bl-button>
                </bl-form-row>

                <bl-form-row>
                  <bl-button label="Button 7" :mod-is-narrow="true"></bl-button>
                </bl-form-row>

                <bl-form-row>
                  <bl-button label="Button 8" :mod-is-wide="true"></bl-button>
                </bl-form-row>

                <bl-form-row>
                  <bl-button label="Button 9" :mod-is-loading="true"></bl-button>
                </bl-form-row>

                <bl-form-row>
                  <bl-button-group>
                    <bl-button label="Button 10"></bl-button>
                    <bl-button label="Button 11"></bl-button>
                  </bl-button-group>
                </bl-form-row>

                <!-- Datepicker -->
                <bl-separator title="Datepicker" />

                <bl-form-row>
                  <bl-date-picker name="datepicker-1" placeholder="01.01.2017" min="01.01.2014" max="01.01.2020" />
                </bl-form-row>

                <!-- Show on checked -->
                <bl-separator title="Show on checked" />

                <bl-form-row>
                  <bl-show-on-checked name="show-on-checked-1" label="Toon inhoud" :checked="true">
                    <div class="u-bg-block">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum reiciendis dolorem modi quasi illum hic vero, quia, sequi non nulla quaerat optio delectus eveniet qui aliquam magni eligendi sed. Voluptatum.
                    </div>
                  </bl-show-on-checked>
                </bl-form-row>

                <bl-form-row>
                  <bl-show-on-checked name="show-on-checked-2" label="Toon inhoud" type="radio">
                    <div class="u-bg-block">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum reiciendis dolorem modi quasi illum hic vero, quia, sequi non nulla quaerat optio delectus eveniet qui aliquam magni eligendi sed. Voluptatum.
                    </div>
                  </bl-show-on-checked>
                </bl-form-row>

                <!-- Show on select -->
                <bl-separator title="Show on select" />

                <bl-form-row>
                  <bl-show-on-select name="show-on-select-1" label="Select label" :options="showOnSelectOptions" />
                </bl-form-row>

              </form>
            </bl-column>
          </bl-grid>
        </bl-layout>
      </bl-region>
    </bl-main>
  </div>
</template>

<script>

import BlSeparator from '~components/partials/separator/Separator.vue'
import BlLabel from '~components/form-elements/label/Label.vue'
import BlFormError from '~components/form-elements/form-error/FormError.vue'
import BlCheckbox from '~components/form-elements/checkbox/Checkbox.vue'
import BlCheckboxSwitch from '~components/form-elements/checkbox-switch/CheckboxSwitch.vue'
import BlRadioButton from '~components/form-elements/radio-button/RadioButton.vue'
import BlFormRow from '~components/form-elements/form-row/FormRow.vue'
import BlInputField from '~components/form-elements/input-field/InputField.vue'
import BlTextarea from '~components/form-elements/textarea/Textarea.vue'
import BlSelect from '~components/form-elements/select/Select.vue'
import BlFileUpload from '~components/form-elements/file-upload/FileUpload.vue'
import BlButton from '~components/form-elements/button/Button.vue'
import BlButtonGroup from '~components/form-elements/button-group/ButtonGroup.vue'
import BlDatePicker from '~components/form-elements/date-picker/DatePicker.vue'
import BlShowOnChecked from '~components/form-elements/show-on-checked/ShowOnChecked.vue'
import BlShowOnSelect from '~components/form-elements/show-on-select/ShowOnSelect.vue'

export default {
  components: {
    BlSeparator,
    BlLabel,
    BlFormError,
    BlCheckbox,
    BlCheckboxSwitch,
    BlRadioButton,
    BlFormRow,
    BlInputField,
    BlTextarea,
    BlSelect,
    BlFileUpload,
    BlButton,
    BlButtonGroup,
    BlDatePicker,
    BlShowOnChecked,
    BlShowOnSelect
  },
  data () {
    return {
      pageTitle: 'Form components',
      selectOptions: [
        {
          type: 'option',
          value: '',
          label: '-- Maak een keuze --'
        },
        {
          type: 'optgroup',
          label: 'Eerste groep met opties',
          options: [
            {
              value: '1',
              label: 'Optie 1'
            },
            {
              value: '2',
              label: 'Optie 2'
            },
            {
              value: '3',
              label: 'Optie 3'
            }
          ]
        },
        {
          type: 'optgroup',
          label: 'Andere groep met opties',
          options: [
            {
              value: '4',
              label: 'Optie 4'
            },
            {
              value: '5',
              label: 'Optie 5'
            },
            {
              value: '6',
              label: 'Optie 6'
            }
          ]
        }
      ],
      selectOptionsWithDefault: [
        {
          type: 'option',
          value: '',
          label: '-- Maak een keuze --'
        },
        {
          type: 'optgroup',
          label: 'Eerste groep met opties',
          options: [
            {
              value: '1',
              label: 'Optie 1',
              selected: true
            },
            {
              value: '2',
              label: 'Optie 2'
            },
            {
              value: '3',
              label: 'Optie 3'
            }
          ]
        },
        {
          type: 'optgroup',
          label: 'Andere groep met opties',
          options: [
            {
              value: '4',
              label: 'Optie 4'
            },
            {
              value: '5',
              label: 'Optie 5'
            },
            {
              value: '6',
              label: 'Optie 6'
            }
          ]
        }
      ],
      showOnSelectOptions: [
        {
          type: 'option',
          value: '',
          label: '-- Maak een keuze --'
        },
        {
          type: 'option',
          value: 'show-on-select-option-1',
          label: 'Optie 1',
          showOnSelect: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illo dolorem nobis quod, repudiandae amet quos, unde, quis ratione asperiores adipisci, nam non veniam. Quisquam officia nihil esse fuga doloribus minus.'
        },
        {
          type: 'option',
          value: 'show-on-select-option-2',
          label: 'Optie 2'
        },
        {
          type: 'option',
          value: 'show-on-select-option-3',
          label: 'Optie 3',
          showOnSelect: 'Lorem ipsum dolor sit.'
        }
      ]
    }
  }
}
</script>
