<template>
  <div>
    <bl-accent-header />
    <bl-icon-navigation />
    <bl-main>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
                <bl-h type="h2" class="h2">{{ pageSubtitle }}</bl-h>
            </bl-column>
            <bl-column :cols="[{nom: 8, den: 12}, {nom: 10, den: 12, mod: 'm'}, {nom: 1, den: 1, mod: 's'}]">
              <bl-typography>
                <p v-html="pageIntroduction" />
              </bl-typography>
              <div class="u-spacer" v-if="auditExtractionsTimelineLoading || !auditExtractionsTimelineLoaded"></div>
              <button type="button" v-if="auditExtractionsTimelineLoading || !auditExtractionsTimelineLoaded" @click.prevent="getExtractions" class="button">Rapport genereren</button>
            </bl-column>

            <!-- Service works -->
            <template v-if="!$store.getters['audit/extractionsFailed']">
              <!-- Preload -->
              <bl-column v-if="auditExtractionsTimelineLoading">
                <bl-separator :title="new Date().getFullYear().toString()" />
                <bl-grid :mod-is-stacked="true">
                  <bl-column>
                    <bl-preload-card />
                  </bl-column>
                </bl-grid>
              </bl-column>
              <!-- ./ Preload -->
              <!-- Loaded & data -->
              <template v-if="auditExtractionsTimelineLoaded && auditExtractionsTimeline.length > 0">
                <template v-for="(auditExtractionsTimelineBlock, index) in auditExtractionsTimeline">
                  <bl-column :key="index">
                    <bl-separator :title="auditExtractionsTimelineBlock.year" />
                  </bl-column>
                  <bl-column v-for="(item, index) in auditExtractionsTimelineBlock.items" :key="index">
                    <bl-extraction-card :data="item" />
                  </bl-column>
                </template>
                <bl-column>
                  <div class="u-spacer--small"></div>
                  <div class="u-hr"></div>
                  <div class="u-spacer--tiny"></div>
                  <bl-typography>
                    <p><strong>Geen verdere opvragingen beschikbaar</strong><br>
                    Enkel de historiek van de laatste 6 maanden is online beschikbaar volgens de Europese richtlijn.</p>
                  </bl-typography>
                </bl-column>
              </template>
              <!-- ./ Loaded & data -->
              <!-- Loaded & empty -->
              <template v-if="auditExtractionsTimelineLoaded && !auditExtractionsTimeline.length">
                <bl-column>
                  <bl-alert title="Geen opvragingen">
                    <p>Uw gegevens werden de voorbije 6 maanden niet geraadpleegd.</p>
                  </bl-alert>
                </bl-column>
              </template>
              <!-- ./ Loaded & empty -->
            </template>
            <!-- ./ Service works -->
            <!-- Service failed -->
            <template v-if="$store.getters['audit/extractionsFailed']">
              <bl-column>
                <bl-alert type="error" title="Geen verbinding">
                  <bl-typography>
                    <p>Er kan op dit moment geen verbinding gemaakt worden waardoor we hier uw opvragingen niet kunnen tonen. Van zodra het probleem is opgelost, vind u hier een overzicht van uw geraadpleegde gegevens.</p>
                  </bl-typography>
                </bl-alert>
              </bl-column>
            </template>
            <!-- ./ Service failed -->
          </bl-grid>
        </bl-layout>
      </bl-region>
    </bl-main>
  </div>
</template>

<script>

import BlAlert from '~components/partials/alert/Alert.vue'
import BlAccentHeader from '~components/partials/accent-header/AccentHeader.vue'
import BlIconNavigation from '~components/navigations/icon-navigation/IconNavigation.vue'
import BlPreloadCard from '~components/service-components/preload-card/PreloadCard.vue'
import BlExtractionCard from '~components/service-components/extraction-card/ExtractionCard.vue'
import BlHSublink from '~components/typography/HSublink.vue'
import BlSeparator from '~components/partials/separator/Separator.vue'

export default {
  middleware: ['authenticated'],
  components: {
    BlAlert,
    BlAccentHeader,
    BlIconNavigation,
    BlPreloadCard,
    BlExtractionCard,
    BlHSublink,
    BlSeparator
  },
  data () {
    return {
      pageSubtitle: 'Wie heeft uw gegevens geraadpleegd',
      pageIntroduction: 'Overheidsdiensten hebben soms nood om gegevens over u op te vragen. Wij hechten veel belang aan uw privacy en transparantie. Dit overzicht geeft weer wie de <strong>voorbije 6 maanden</strong> uw gegevens heeft opgevraagd, wanneer, met welk doel. Via de link, kan u de machtiging raadplegen die de opvraging mogelijk maakt.',
      mockAuditExtractionsTimeline: 2,
      auditExtractionsTimeline: [],
      auditExtractionsTimelineLoaded: false,
      auditExtractionsTimelineLoading: false
    }
  },
  methods: {
    getExtractions () {
      // Get a reference to ourself.
      const self = this
      // Start preloading.
      self.auditExtractionsTimelineLoading = true
      // Resolve the Extractions audits.
      self.$store.dispatch('audit/extractions').then(() => {
        // Stop preloading.
        self.auditExtractionsTimelineLoading = false
        // Get the Extractions audits timeline.
        self.auditExtractionsTimeline = self.$store.getters['audit/extractions'].timeline
        // Mark the auditExtractions timeline as loaded.
        self.auditExtractionsTimelineLoaded = true
        // Dress the components using Flanders UI.
        setTimeout(() => { vl.accordion.dressAll() }, 10)
      })
    }
  }
}
</script>
