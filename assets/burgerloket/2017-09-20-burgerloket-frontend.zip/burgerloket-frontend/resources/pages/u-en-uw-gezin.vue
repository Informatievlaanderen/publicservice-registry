<template>
  <div>
    <bl-accent-header />
    <bl-icon-navigation />
    <bl-main>
      <bl-person-particulars />
      <!-- <bl-region v-if="!familyFailed && family">
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
              <div class="title-sublink">
                <bl-h type="h2" class="h2">Gezinssamenstelling <span class="title-sublink__sub">volgens het rijksregister</span></bl-h>
              </div>
            </bl-column>
            <template v-if="family.incompleteData">
              <bl-column>
                <bl-alert type="error" title="Geen data beschikbaar">
                  <p>{{ family.incompleteData }}</p>
                </bl-alert>
              </bl-column>
            </template>
            <template v-else>
              <bl-column>
                <bl-separator v-if="family.address" :mod-is-small="true" :title="'Gezinsleden verblijvend op ' + generateFormattedAddress(family.address)">
                  <p v-if="family.accommodation" class="u-small-text u-color-gray u-font-weight-regular">{{ family.accommodation }}</p>
                </bl-separator>
              </bl-column>
              <bl-column>
                <bl-grid class="js-equal-height-container" :mod-is-stacked="true">
                  <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]" v-if="family.reference">
                    <section class="bl-family-tile bl-family-tile--alt js-equal-height">
                      <div class="bl-family-tile__badge">
                        <div class="bl-family-tile__badge__image" :data-initials="generateInitials(family.reference)"></div>
                      </div>
                      <div class="bl-family-tile__content">
                        <h1 class="bl-family-tile__title">{{ family.reference.preferredFirstName || family.reference.firstNames[0]}} {{ family.reference.lastNames[0]}}</h1>
                        <p class="bl-family-tile__meta" v-if="family.reference.nationalId">{{ family.reference.nationalId }}</p>
                        <p class="bl-family-tile__meta" v-if="family.reference.relation">{{ family.reference.relation }}</p>
                        <p class="bl-family-tile__meta" v-if="family.reference.self"><span class="bl-tag">uzelf</span></p>
                      </div>
                    </section>
                  </bl-column>
                  <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]" v-if="family.family && family.family[0] && family.family[0].length" v-for="(partner, index) in family.family[0]" :key="index">
                    <section class="bl-family-tile js-equal-height">
                      <div class="bl-family-tile__badge">
                        <div class="bl-family-tile__badge__image" :data-initials="generateInitials(partner)"></div>
                      </div>
                      <div class="bl-family-tile__content">
                        <h1 class="bl-family-tile__title">{{ partner.preferredFirstName || partner.firstNames[0]}} {{ partner.lastNames[0]}}</h1>
                        <p class="bl-family-tile__meta" v-if="partner.nationalId">{{ partner.nationalId }}</p>
                        <p class="bl-family-tile__meta">{{ partner.relation }} van {{ family.reference.preferredFirstName || family.reference.firstNames[0]}} {{ family.reference.lastNames[0]}}</p>
                        <p class="bl-family-tile__meta" v-if="partner.self"><span class="bl-tag">uzelf</span></p>
                      </div>
                    </section>
                  </bl-column>
                </bl-grid>
              </bl-column>
              <bl-column>
                <bl-grid class="js-equal-height-container" :mod-is-stacked="true">
                  <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]" v-if="family.family && family.family[1] && family.family[1].length" v-for="(child, index) in family.family[1]" :key="index">
                    <section class="bl-family-tile js-equal-height">
                      <div class="bl-family-tile__badge">
                        <div class="bl-family-tile__badge__image" :data-initials="generateInitials(child)"></div>
                      </div>
                      <div class="bl-family-tile__content">
                        <h1 class="bl-family-tile__title">{{ child.preferredFirstName || child.firstNames[0]}} {{ child.lastNames[0]}}</h1>
                        <p class="bl-family-tile__meta" v-if="child.nationalId">{{ child.nationalId }}</p>
                        <p class="bl-family-tile__meta">{{ child.relation }} van {{ family.reference.preferredFirstName || family.reference.firstNames[0]}} {{ family.reference.lastNames[0]}}</p>
                        <p class="bl-family-tile__meta" v-if="child.self"><span class="bl-tag">uzelf</span></p>
                      </div>
                    </section>
                  </bl-column>
                </bl-grid>
              </bl-column>
              <bl-column>
                <bl-grid :mod-is-stacked="true">
                  <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]" v-if="family.family && family.family[2] && family.family[2].length" v-for="(child, index) in family.family[2]" :key="index">
                    <section class="bl-family-tile js-equal-height">
                      <div class="bl-family-tile__badge">
                        <div class="bl-family-tile__badge__image" :data-initials="generateInitials(child)"></div>
                      </div>
                      <div class="bl-family-tile__content">
                        <h1 class="bl-family-tile__title">{{ child.preferredFirstName || child.firstNames[0]}} {{ child.lastNames[0]}}</h1>
                        <p class="bl-family-tile__meta" v-if="child.nationalId">{{ child.nationalId }}</p>
                        <p class="bl-family-tile__meta">niet verwant aan {{ family.reference.preferredFirstName || family.reference.firstNames[0]}} {{ family.reference.lastNames[0]}}</p>
                        <p class="bl-family-tile__meta" v-if="child.self"><span class="bl-tag">uzelf</span></p>
                      </div>
                    </section>
                  </bl-column>
                </bl-grid>
              </bl-column>
            </template>
          </bl-grid>
        </bl-layout>
      </bl-region>
      <bl-region v-else>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
              <div class="title-sublink">
                <bl-h type="h2" class="h2">Gezinssamenstelling <span class="title-sublink__sub">volgens het rijksregister</span></bl-h>
              </div>
            </bl-column>
            <bl-column>
              <bl-alert type="error" title="Geen data beschikbaar">
                <p>Er liep iets fout met de connectie naar MAGDA. (boodschap nog aan te passen)</p>
              </bl-alert>
            </bl-column>
          </bl-grid>
        </bl-layout>
      </bl-region> -->
      <bl-person-family />
      <bl-person-descent />
      <!-- <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid>
            <bl-column>
              <bl-h type="h2" class="h2">Personen die u vertegenwoordigt</bl-h>
              <bl-grid :mod-is-stacked="true">
                <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                  <section class="bl-family-tile">
                    <div class="bl-family-tile__badge">
                      <img class="bl-family-tile__badge__image" src="https://placehold.it/100x100" alt="" />
                    </div>
                    <div class="bl-family-tile__content">
                      <h1 class="bl-family-tile__title">Broos Deprez</h1>
                      <p class="bl-family-tile__meta">uw zoon <time datetime="19.05.2005">(19.05.2005)</time></p>
                      <p class="bl-family-tile__meta">niet verwant aan referentiepersoon</p>
                    </div>
                  </section>
                </bl-column>
              </bl-grid>
            </bl-column>
          </bl-grid>
        </bl-layout>
      </bl-region> -->
    </bl-main>
  </div>
</template>

<script>

import BlAccentHeader from '~components/partials/accent-header/AccentHeader.vue'
import BlIconNavigation from '~components/navigations/icon-navigation/IconNavigation.vue'
import BlDescriptionData from '~components/partials/description-data/DescriptionData.vue'
import BlDescriptionDataItem from '~components/partials/description-data/DescriptionDataItem.vue'
import BlPersonParticulars from '~components/service-components/person-particulars/PersonParticulars.vue'
import BlPersonDescent from '~components/service-components/person-descent/PersonDescent.vue'
import BlPersonFamily from '~components/service-components/person-family/PersonFamily.vue'

export default {
  middleware: ['authenticated'],
  components: {
    BlAccentHeader,
    BlIconNavigation,
    BlDescriptionData,
    BlDescriptionDataItem,
    BlPersonParticulars,
    BlPersonDescent,
    BlPersonFamily
  }
}
</script>
