<template>
  <div>
    <header class="bl-accent-header js-accent-header" role="banner">
        <bl-layout :mod-is-wide="true">
          <bl-grid>
            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 's'}]">
              <div class="bl-accent-header__content">
                <div data-initials="WB" class="bl-accent-header__badge" />
                <h1 class="bl-accent-header__title">Warre Buysse</h1>
              </div>
            </bl-column>
            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 's'}]">
              <ul class="bl-accent-header__actions">
                <li class="bl-accent-header__actions__item">
                    <nuxt-link to="/siteimprove/wie-heeft-uw-gegevens-geraadpleegd" class="bl-accent-header__actions__item__cta link u-small-text">Wie heeft uw gegevens geraadpleegd</nuxt-link>
                </li>
                </li>
                <li class="bl-accent-header__actions__item">
                  <nuxt-link to="/login" class="bl-accent-header__actions__item__cta link u-small-text">INSZ</nuxt-link>&nbsp;
                  <a href="#" class="bl-accent-header__actions__item__cta link u-small-text" @click.prevent="$store.dispatch('session/logout', true)">Uitloggen</a>
                </li>
              </ul>
            </bl-column>
          </bl-grid>
        </bl-layout>
      <slot></slot>
    </header>
    <nav class="bl-icon-navigation">
      <bl-layout :mod-is-wide="true">
        <bl-grid>
          <bl-column>
            <ul class="bl-icon-navigation__list">
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/meest-recent" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-bell" size="0 0 19 19" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Meest recent</span>
                </nuxt-link>
              </li>
              <li role="separator" aria-hidden="true" class="bl-icon-navigation__separator"></li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/u-en-uw-gezin" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-people" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">U & uw gezin</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/woonst-en-vastgoed" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-house" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Woonst &<br>vastgoed</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <a href="" @click.prevent="" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-car" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Mobiliteit</span>
                </a>
              </li>
              <li class="bl-icon-navigation__item">
                <a href="" @click.prevent="" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-suitcase" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Werk &<br>pensioen</span>
                </a>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/onderwijs" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-hat" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Onderwijs & inburgering</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/belastingen-en-voordelen" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-cash" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Belastingen &<br>voordelen</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/attesten" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-diploma" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Attesten</span>
                </nuxt-link>
              </li>
            </ul>
          </bl-column>
        </bl-grid>
      </bl-layout>
    </nav>
  </div>
</template>

<script>

import BlAlert from '~components/partials/alert/Alert.vue'
import BlAccentHeader from '~components/partials/accent-header/AccentHeader.vue'
import BlIconNavigation from '~components/navigations/icon-navigation/IconNavigation.vue'
import BlPreloadCard from '~components/service-components/preload-card/PreloadCard.vue'
import BlTemporaryCard from '~components/service-components/temporary-card/TemporaryCard.vue'
import BlHSublink from '~components/typography/HSublink.vue'
import BlDescriptionData from '~components/partials/description-data/DescriptionData.vue'
import BlDescriptionDataItem from '~components/partials/description-data/DescriptionDataItem.vue'
import BlDescriptionDataItemWrapper from '~components/partials/description-data/DescriptionDataItemWrapper.vue'
import BlRadioButton from '~components/form-elements/radio-button/RadioButton.vue'
import BlBadge from '~components/partials/badge/Badge.vue'

export default {
  components: {
    BlAlert,
    BlAccentHeader,
    BlIconNavigation,
    BlPreloadCard,
    BlTemporaryCard,
    BlHSublink,
    BlDescriptionData,
    BlDescriptionDataItem,
    BlDescriptionDataItemWrapper,
    BlRadioButton,
    BlBadge
  }
}
</script>
