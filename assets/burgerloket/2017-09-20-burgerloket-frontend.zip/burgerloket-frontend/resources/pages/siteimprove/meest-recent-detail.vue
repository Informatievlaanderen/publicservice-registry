<template>
  <div>
    <header class="bl-navigation-header" title="Dossier studietoelagen 2016 - 2017 Thomas Deprez">
      <div class="bl-navigation-header__main">
        <div class="layout layout--wide">
          <div class="grid grid--v-center">
            <div class="col--1-1">
              <div class="bl-navigation-header__main__heading">
                <nuxt-link class="bl-navigation-header__main__heading__back nuxt-link-active" to="/siteimprove/meest-recent"><i aria-hidden="true" class="vi vi-arrow vi-u-180deg"></i><span class="u-visually-hidden">Ga terug</span></nuxt-link>
                <div class="bl-navigation-header__main__heading__content">
                  <div class="bl-navigation-header__main__heading__content__badge bl-user-badge bl-user-badge--large" data-initials="JD"></div><!---->
                  <p class="bl-navigation-header__main__heading__content__name"><span class="name">Joost Deprez</span><!----></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="bl-navigation-header__file-detail">
        <div class="layout layout--wide">
          <div class="grid">
            <div class="col--1-1">
              <div class="bl-navigation-header__file-detail__content">
                <div class="grid grid--is-stacked">
                  <div class="col--1-4 col--1-2--s col--1-1--xs">
                    <p class="description-data__label">Dossiernummer</p>
                    <p class="description-data__value">2016.82810_Test</p>
                  </div>
                  <div class="col--1-4 col--1-2--s col--1-1--xs">
                    <p class="description-data__label">Type</p>
                    <p class="description-data__value">DossierStatus</p>
                  </div>
                  <div class="col--1-4 col--1-2--s col--1-1--xs">
                    <p class="description-data__label">Dossierbeheerder</p>
                    <div class="description-data__value">
                      <!---->
                      <p>Afdeling School- en Studietoelagen</p>
                      <p>1700</p><!---->
                      <p><a href="http://www.studietoelagen.be" target="_BLANK">Website</a></p>
                    </div>
                  </div>
                  <div class="col--1-4 col--1-2--s col--1-1--xs">
                    <div class="u-align-right">
                      <a class="button" href="http://productencatalogus.vlaanderen.be/fiche/685" target="_BLANK">Naar het dossier</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
    <main id="main" itemprop="mainContentOfPage">
      <div class="region">
        <div class="layout layout--wide">
          <div class="grid">
            <div class="col--9-12 col--10-12--m col--1-1--s">
              <ul class="steps steps--timeline">
                <li class="step">
                  <div class="step__icon">
                    21<span class="step__icon__sub">sep</span>
                  </div>
                  <div class="step__wrapper">
                    <div class="step__header">
                      <div class="step__header__titles">
                        <h3 class="step__title bl-step__title"><!---->We hebben een beslissing genomen in jouw dossier.</h3>
                      </div>
                    </div><!---->
                  </div>
                </li>
                <li class="step">
                  <div class="step__icon">
                    8<span class="step__icon__sub">sep</span>
                  </div>
                  <div class="step__wrapper">
                    <div class="step__header">
                      <div class="step__header__titles">
                        <h3 class="step__title bl-step__title"><!---->We behandelen jouw dossier.</h3>
                      </div>
                    </div><!---->
                  </div>
                </li>
                <li class="step">
                  <div class="step__icon">
                    8<span class="step__icon__sub">aug</span>
                  </div>
                  <div class="step__wrapper">
                    <div class="step__header">
                      <div class="step__header__titles">
                        <h3 class="step__title bl-step__title"><svg aria-hidden="true" class="bl-step__title__icon icon icon--color-warning" height="20" role="presentation" viewbox="0 0 20 20" width="20">
                        <use xlink:href="/svg/icons.svg#icon-warning-fill" xmlns:xlink="http://www.w3.org/1999/xlink"></use></svg>Wij hebben bijkomende gegevens nodig.</h3>
                      </div>
                    </div>
                    <div class="step__content-wrapper">
                      <div class="step__content">
                        <p>Je zoon of dochter in het Hoger Onderwijs, moet nog een document bezorgen aan de dienst studietoelagen.</p>
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script>
import BlNavigationHeader from '~components/navigations/navigation-header/NavigationHeader.vue'
import BlNavigationHeaderFileDetail from '~components/navigations/navigation-header/NavigationHeaderFileDetail.vue'

import BlTimelineSteps from '~components/partials/steps/TimelineSteps.vue'
import BlTimelineStepsItem from '~components/partials/steps/TimelineStepsItem.vue'

export default {
  components: {
    BlNavigationHeader,
    BlNavigationHeaderFileDetail,
    BlTimelineSteps,
    BlTimelineStepsItem
  }
}
</script>
