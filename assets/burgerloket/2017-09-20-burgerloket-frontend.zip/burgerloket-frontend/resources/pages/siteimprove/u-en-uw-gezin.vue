<template>
  <div>
    <header class="bl-accent-header js-accent-header" role="banner">
        <bl-layout :mod-is-wide="true">
          <bl-grid>
            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 's'}]">
              <div class="bl-accent-header__content">
                <div data-initials="WB" class="bl-accent-header__badge" />
                <h1 class="bl-accent-header__title">Warre Buysse</h1>
              </div>
            </bl-column>
            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 's'}]">
              <ul class="bl-accent-header__actions">
                <li class="bl-accent-header__actions__item">
                    <nuxt-link to="/siteimprove/wie-heeft-uw-gegevens-geraadpleegd" class="bl-accent-header__actions__item__cta link u-small-text">Wie heeft uw gegevens geraadpleegd</nuxt-link>
                </li>
                </li>
                <li class="bl-accent-header__actions__item">
                  <nuxt-link to="/login" class="bl-accent-header__actions__item__cta link u-small-text">INSZ</nuxt-link>&nbsp;
                  <a href="#" class="bl-accent-header__actions__item__cta link u-small-text" @click.prevent="$store.dispatch('session/logout', true)">Uitloggen</a>
                </li>
              </ul>
            </bl-column>
          </bl-grid>
        </bl-layout>
      <slot></slot>
    </header>
    <nav class="bl-icon-navigation">
      <bl-layout :mod-is-wide="true">
        <bl-grid>
          <bl-column>
            <ul class="bl-icon-navigation__list">
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/meest-recent" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-bell" size="0 0 19 19" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Meest recent</span>
                </nuxt-link>
              </li>
              <li role="separator" aria-hidden="true" class="bl-icon-navigation__separator"></li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/u-en-uw-gezin" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-people" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">U & uw gezin</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/woonst-en-vastgoed" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-house" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Woonst &<br>vastgoed</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <a href="" @click.prevent="" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-car" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Mobiliteit</span>
                </a>
              </li>
              <li class="bl-icon-navigation__item">
                <a href="" @click.prevent="" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-suitcase" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Werk &<br>pensioen</span>
                </a>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/onderwijs" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-hat" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Onderwijs & inburgering</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/belastingen-en-voordelen" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-cash" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Belastingen &<br>voordelen</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/attesten" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-diploma" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Attesten</span>
                </nuxt-link>
              </li>
            </ul>
          </bl-column>
        </bl-grid>
      </bl-layout>
    </nav>
    <bl-main>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
              <div class="bl-person-banner">
                <div class="bl-person-banner__content">
                  <h1 class="bl-person-banner__title">Thomas Denis Carl Deprez</h1>
                </div>
              </div>
            </bl-column>
            <bl-column>
              <bl-description-data :mod-is-bordered="true" class="u-spacer--small">
                <bl-grid :mod-is-stacked="true">
                  <bl-column :cols="[{nom: 1, den: 4}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                    <bl-description-data-item class-type="data">
                      ° 31.10.1977 in Mechelen
                    </bl-description-data-item>
                    <bl-description-data-item class-type="subdata">
                      Mannellijk
                    </bl-description-data-item>
                    <bl-description-data-item class-type="subdata">
                      uit België
                    </bl-description-data-item>
                  </bl-column>
                  <bl-column :cols="[{nom: 1, den: 4}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                    <!--
                    <bl-description-data-item class-type="data">
                      eID 591-1111111-22
                    </bl-description-data-item>
                    <bl-description-data-item class-type="subdata">
                      vervalt op 28.09.2017
                    </bl-description-data-item>
                    -->
                    <bl-alert type="warning" :has-icon="false" title="eID 591-1111111-22">
                      vervalt op 28.09.2017<br>
                    </bl-alert>
                  </bl-column>
                  <bl-column :cols="[{nom: 1, den: 4}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                    <bl-description-data-item class-type="data">
                      Ingeschreven in het bevolkingsregister
                    </bl-description-data-item>
                    <bl-description-data-item class-type="subdata">
                      beheerd door Mechelen
                    </bl-description-data-item>
                  </bl-column>
                  <bl-column :cols="[{nom: 1, den: 4}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                    <bl-description-data-item class-type="data">
                      Gehuwd met Alexandra Vanderauwera
                    </bl-description-data-item>
                    <bl-description-data-item class-type="subdata">
                      op 13.05.2002 in Mechelen
                    </bl-description-data-item>
                  </bl-column>
                </bl-grid>
              </bl-description-data>
              <bl-typography>
                <a class="link--icon--external" href="#">Bekijk meer details over uw dossier bij het Rijksregister <span class="link__note">(vereist opnieuw aanmelden)</span></a>
              </bl-typography>
            </bl-column>
          </bl-grid>
        </bl-layout>
      </bl-region>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
              <div class="title-sublink">
                <bl-h type="h2" class="h2">Gezinssamenstelling <span class="title-sublink__sub">volgens het rijksregister</span></bl-h>
              </div>
              <div class="u-spacer--small"></div>
              <bl-separator :mod-is-small="true" title="Gezinsleden verblijvend op Begijnenstraat 39, 2800 Mechelen" />
            </bl-column>
            <bl-column>
              <bl-grid :mod-is-stacked="true">
                <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                  <section class="bl-family-tile bl-family-tile--alt">
                    <div class="bl-family-tile__badge">
                      <img class="bl-family-tile__badge__image" src="https://placehold.it/100x100" alt="" />
                    </div>
                    <div class="bl-family-tile__content">
                      <h1 class="bl-family-tile__title">Pieter De Waele</h1>
                      <p class="bl-family-tile__meta">referentiepersoon</p>
                    </div>
                  </section>
                </bl-column>
                <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                  <section class="bl-family-tile">
                    <div class="bl-family-tile__badge">
                      <div class="bl-family-tile__badge__image" data-initials="NV" src="https://placehold.it/100x100" alt=""></div>
                    </div>
                    <div class="bl-family-tile__content">
                      <h1 class="bl-family-tile__title">Nathalie Vandewalle</h1>
                      <p class="bl-family-tile__meta">partner van Pieter De Waele</p>
                    </div>
                  </section>
                </bl-column>
              </bl-grid>
            </bl-column>
            <bl-column>
              <bl-grid :mod-is-stacked="true">
                <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                  <section class="bl-family-tile">
                    <div class="bl-family-tile__badge">
                      <img class="bl-family-tile__badge__image" src="https://placehold.it/100x100" alt="" />
                    </div>
                    <div class="bl-family-tile__content">
                      <h1 class="bl-family-tile__title">Thomas Deprez</h1>
                      <p class="bl-family-tile__meta"><span class="bl-tag">uzelf</span></p>
                      <p class="bl-family-tile__meta">niet verwant aan referentiepersoon</p>
                    </div>
                  </section>
                </bl-column>
                <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                  <section class="bl-family-tile">
                    <div class="bl-family-tile__badge">
                      <img class="bl-family-tile__badge__image" src="https://placehold.it/100x100" alt="" />
                    </div>
                    <div class="bl-family-tile__content">
                      <h1 class="bl-family-tile__title">Broos Deprez</h1>
                      <p class="bl-family-tile__meta">uw zoon <time datetime="19.05.2005">(19.05.2005)</time></p>
                      <p class="bl-family-tile__meta">niet verwant aan referentiepersoon</p>
                    </div>
                  </section>
                </bl-column>
              </bl-grid>
            </bl-column>
            <bl-column>
              <bl-separator :mod-is-small="true" title="Gezinsleden gedeeltelijk verblijvend op Begijnenstraat 39, 2800 Mechelen" />
            </bl-column>
            <bl-column>
              <bl-grid :mod-is-stacked="true">
                <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                  <section class="bl-family-tile">
                    <div class="bl-family-tile__badge">
                      <img class="bl-family-tile__badge__image" src="https://placehold.it/100x100" alt="" />
                    </div>
                    <div class="bl-family-tile__content">
                      <h1 class="bl-family-tile__title">Matthias Deprez</h1>
                      <p class="bl-family-tile__meta">uw zoon</p>
                    </div>
                  </section>
                </bl-column>
              </bl-grid>
            </bl-column>
          </bl-grid>
        </bl-layout>
      </bl-region>
      <bl-region :mod-is-alt="true">
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
              <bl-h type="h2" class="h2">Afstamming</bl-h>
            </bl-column>
            <bl-column>
              <div class="tree">
                <div class="tree__parents" data-items="3">
                  <div class="tree__row grid grid--align-center">
                    <div class="col--1-4 col--1-2--s tree__col">
                      <section class="tree__item tree__item--unknown">
                        <div class="tree__item__image">
                          <img class="tree__item__image__figure" src="http://placehold.it/100x100">
                        </div>
                        <div class="tree__item__content">
                          <h1 class="tree__item__name">niet gekend</h1>
                          <p class="tree__item__meta">uw vader</p>
                        </div>
                      </section>
                    </div>
                    <div class="col--1-4 col--1-2--s tree__col">
                      <section class="tree__item">
                        <div class="tree__item__image tree__item__image--has-icon">
                          <svg role="presentation" class="tree__item__image__icon" v-svg symbol="icon-question" aria-hidden="true"></svg>
                        </div>
                        <div class="tree__item__content">
                          <p class="tree__item__meta">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid reiciendis necessitatibus distinctio, excepturi officiis enim.</p>
                        </div>
                      </section>
                    </div>
                    <div class="col--1-4 col--1-2--s tree__col">
                      <section class="tree__item tree__item--deceased">
                        <span class="tree__item__ribbon"></span>
                        <div class="tree__item__image">
                          <img class="tree__item__image__figure" src="http://placehold.it/100x100">
                        </div>
                        <div class="tree__item__content">
                          <h1 class="tree__item__name">Francesca De Prins</h1>
                          <p class="tree__item__meta">uw moeder</p>
                          <p class="tree__item__meta">° 1947, Mechelen</p>
                        </div>
                      </section>
                    </div>
                  </div>
                </div>
                <div class="tree__you">
                  <div class="grid grid--align-center">
                    <div class="col--1-4 col--1-2--s tree__col">
                      <section class="tree__item">
                        <div class="tree__item__image">
                          <img class="tree__item__image__figure" src="http://placehold.it/100x100">
                        </div>
                        <div class="tree__item__content">
                          <h1 class="tree__item__name">Thomas Deprez</h1>
                          <p class="tree__item__meta"><span class="bl-tag">uzelf</span></p>
                        </div>
                      </section>
                    </div>
                  </div>
                </div>
                <div class="tree__children">
                  <div class="tree__row grid grid--is-stacked grid--align-center" data-items="4">
                    <div class="col--1-4 col--1-2--s tree__col">
                      <section class="tree__item">
                        <div class="tree__item__image">
                          <img class="tree__item__image__figure" src="http://placehold.it/100x100">
                        </div>
                        <div class="tree__item__content">
                          <h1 class="tree__item__name">Broos Deprez</h1>
                          <p class="tree__item__meta">uw zoon</p>
                          <p class="tree__item__meta">° 01.12.2010, Mechelen</p>
                        </div>
                      </section>
                    </div>
                    <div class="col--1-4 col--1-2--s tree__col">
                      <section class="tree__item">
                        <div class="tree__item__image">
                          <img class="tree__item__image__figure" src="http://placehold.it/100x100">
                        </div>
                        <div class="tree__item__content">
                          <h1 class="tree__item__name">Elise Deprez</h1>
                          <p class="tree__item__meta">uw dochter</p>
                          <p class="tree__item__meta">° 01.12.2012, Mechelen</p>
                        </div>
                      </section>
                    </div>
                    <div class="col--1-4 col--1-2--s tree__col">
                      <section class="tree__item">
                        <div class="tree__item__image">
                          <img class="tree__item__image__figure" src="http://placehold.it/100x100">
                        </div>
                        <div class="tree__item__content">
                          <h1 class="tree__item__name">Elodie Deprez</h1>
                          <p class="tree__item__meta">uw adoptiedochter</p>
                          <p class="tree__item__meta">° 01.06.1998, Kanshasa, Congo</p>
                        </div>
                      </section>
                    </div>
                    <div class="col--1-4 col--1-2--s tree__col">
                      <section class="tree__item">
                        <div class="tree__item__image">
                          <img class="tree__item__image__figure" src="http://placehold.it/100x100">
                        </div>
                        <div class="tree__item__content">
                          <h1 class="tree__item__name">Elodie Deprez</h1>
                          <p class="tree__item__meta">uw adoptiedochter</p>
                          <p class="tree__item__meta">° 01.06.1998, Kanshasa, Congo</p>
                        </div>
                      </section>
                    </div>
                  </div>
                  <div class="tree__row grid grid--is-stacked grid--align-center" data-items="4">
                    <div class="col--1-4 col--1-2--s tree__col">
                      <section class="tree__item">
                        <div class="tree__item__image">
                          <img class="tree__item__image__figure" src="http://placehold.it/100x100">
                        </div>
                        <div class="tree__item__content">
                          <h1 class="tree__item__name">Elodie Deprez</h1>
                          <p class="tree__item__meta">uw adoptiedochter</p>
                          <p class="tree__item__meta">° 01.06.1998, Kanshasa, Congo</p>
                        </div>
                      </section>
                    </div>
                    <div class="col--1-4 col--1-2--s tree__col">
                      <section class="tree__item">
                        <div class="tree__item__image">
                          <img class="tree__item__image__figure" src="http://placehold.it/100x100">
                        </div>
                        <div class="tree__item__content">
                          <h1 class="tree__item__name">Broos Deprez</h1>
                          <p class="tree__item__meta">uw zoon</p>
                          <p class="tree__item__meta">° 01.12.2010, Mechelen</p>
                        </div>
                      </section>
                    </div>
                    <div class="col--1-4 col--1-2--s tree__col">
                      <section class="tree__item">
                        <div class="tree__item__image">
                          <img class="tree__item__image__figure" src="http://placehold.it/100x100">
                        </div>
                        <div class="tree__item__content">
                          <h1 class="tree__item__name">Elise Deprez</h1>
                          <p class="tree__item__meta">uw dochter</p>
                          <p class="tree__item__meta">° 01.12.2012, Mechelen</p>
                        </div>
                      </section>
                    </div>
                    <div class="col--1-4 col--1-2--s tree__col">
                      <section class="tree__item">
                        <div class="tree__item__image">
                          <img class="tree__item__image__figure" src="http://placehold.it/100x100">
                        </div>
                        <div class="tree__item__content">
                          <h1 class="tree__item__name">Elodie Deprez</h1>
                          <p class="tree__item__meta">uw adoptiedochter</p>
                          <p class="tree__item__meta">° 01.06.1998, Kanshasa, Congo</p>
                        </div>
                      </section>
                    </div>
                  </div>
                  <div class="tree__row grid grid--is-stacked grid--align-center" data-items="3" data-uneven="true">
                    <div class="col--1-4 col--1-2--s tree__col">
                      <section class="tree__item tree__item--flat">
                        <div class="tree__item__image">
                          <img class="tree__item__image__figure" src="http://placehold.it/100x100">
                        </div>
                        <div class="tree__item__content">
                          <h1 class="tree__item__name">Broos Deprez</h1>
                          <p class="tree__item__meta">uw zoon</p>
                          <p class="tree__item__meta">° 01.12.2010, Mechelen</p>
                        </div>
                      </section>
                    </div>
                    <div class="col--1-4 col--1-2--s tree__col">
                      <section class="tree__item tree__item--flat">
                        <div class="tree__item__image">
                          <img class="tree__item__image__figure" src="http://placehold.it/100x100">
                        </div>
                        <div class="tree__item__content">
                          <h1 class="tree__item__name">Elise Deprez</h1>
                          <p class="tree__item__meta">uw dochter</p>
                          <p class="tree__item__meta">° 01.12.2012, Mechelen</p>
                        </div>
                      </section>
                    </div>
                    <div class="col--1-4 col--1-2--s tree__col">
                      <section class="tree__item tree__item--flat">
                        <div class="tree__item__image">
                          <img class="tree__item__image__figure" src="http://placehold.it/100x100">
                        </div>
                        <div class="tree__item__content">
                          <h1 class="tree__item__name">Elodie Deprez</h1>
                          <p class="tree__item__meta">uw adoptiedochter</p>
                          <p class="tree__item__meta">° 01.06.1998, Kanshasa, Congo</p>
                        </div>
                      </section>
                    </div>
                  </div>
                </div>
              </div>
            </bl-column>
          </bl-grid>
        </bl-layout>
      </bl-region>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid>
            <bl-column>
              <bl-h type="h2" class="h2">Personen die u vertegenwoordigt</bl-h>
              <bl-grid :mod-is-stacked="true">
                <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                  <section class="bl-family-tile">
                    <div class="bl-family-tile__badge">
                      <img class="bl-family-tile__badge__image" src="https://placehold.it/100x100" alt="" />
                    </div>
                    <div class="bl-family-tile__content">
                      <h1 class="bl-family-tile__title">Broos Deprez</h1>
                      <p class="bl-family-tile__meta">uw zoon <time datetime="19.05.2005">(19.05.2005)</time></p>
                      <p class="bl-family-tile__meta">niet verwant aan referentiepersoon</p>
                    </div>
                  </section>
                </bl-column>
              </bl-grid>
            </bl-column>
          </bl-grid>
        </bl-layout>
      </bl-region>
    </bl-main>
  </div>
</template>

<script>

import BlAlert from '~components/partials/alert/Alert.vue'
import BlAccentHeader from '~components/partials/accent-header/AccentHeader.vue'
import BlIconNavigation from '~components/navigations/icon-navigation/IconNavigation.vue'
import BlDescriptionData from '~components/partials/description-data/DescriptionData.vue'
import BlDescriptionDataItem from '~components/partials/description-data/DescriptionDataItem.vue'
import BlPersonParticulars from '~components/service-components/person-particulars/PersonParticulars.vue'
import BlPersonDescent from '~components/service-components/person-descent/PersonDescent.vue'
import BlPersonFamily from '~components/service-components/person-family/PersonFamily.vue'
import BlSeparator from '~components/partials/separator/Separator.vue'

export default {
  components: {
    BlAlert,
    BlAccentHeader,
    BlIconNavigation,
    BlDescriptionData,
    BlDescriptionDataItem,
    BlPersonParticulars,
    BlPersonDescent,
    BlPersonFamily,
    BlSeparator
  }
}
</script>
