<template>
  <div>
    <header class="bl-accent-header js-accent-header" role="banner">
        <bl-layout :mod-is-wide="true">
          <bl-grid>
            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 's'}]">
              <div class="bl-accent-header__content">
                <div data-initials="WB" class="bl-accent-header__badge" />
                <h1 class="bl-accent-header__title">Warre Buysse</h1>
              </div>
            </bl-column>
            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 's'}]">
              <ul class="bl-accent-header__actions">
                <li class="bl-accent-header__actions__item">
                    <nuxt-link to="/siteimprove/wie-heeft-uw-gegevens-geraadpleegd" class="bl-accent-header__actions__item__cta link u-small-text">Wie heeft uw gegevens geraadpleegd</nuxt-link>
                </li>
                </li>
                <li class="bl-accent-header__actions__item">
                  <nuxt-link to="/login" class="bl-accent-header__actions__item__cta link u-small-text">INSZ</nuxt-link>&nbsp;
                  <a href="#" class="bl-accent-header__actions__item__cta link u-small-text" @click.prevent="$store.dispatch('session/logout', true)">Uitloggen</a>
                </li>
              </ul>
            </bl-column>
          </bl-grid>
        </bl-layout>
      <slot></slot>
    </header>
    <nav class="bl-icon-navigation">
      <bl-layout :mod-is-wide="true">
        <bl-grid>
          <bl-column>
            <ul class="bl-icon-navigation__list">
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/meest-recent" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-bell" size="0 0 19 19" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Meest recent</span>
                </nuxt-link>
              </li>
              <li role="separator" aria-hidden="true" class="bl-icon-navigation__separator"></li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/u-en-uw-gezin" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-people" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">U & uw gezin</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/woonst-en-vastgoed" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-house" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Woonst &<br>vastgoed</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <a href="" @click.prevent="" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-car" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Mobiliteit</span>
                </a>
              </li>
              <li class="bl-icon-navigation__item">
                <a href="" @click.prevent="" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-suitcase" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Werk &<br>pensioen</span>
                </a>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/onderwijs" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-hat" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Onderwijs & inburgering</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/belastingen-en-voordelen" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-cash" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Belastingen &<br>voordelen</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/attesten" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-diploma" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Attesten</span>
                </nuxt-link>
              </li>
            </ul>
          </bl-column>
        </bl-grid>
      </bl-layout>
    </nav>
    <bl-main>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true" class="js-equal-height-container">
            <bl-column>
              <bl-h type="h2" class="h2">{{ pageSubtitle }}</bl-h>
              <bl-h type="h3" class="h6">
                Download een attest voor uzelf
                <div class="popover popover--left js-popover">
                  <a href="#" class="js-popover__toggle">
                    <i class="vi vi-u-badge vi-u-badge--action vi-u-badge--xsmall vi-info" aria-hidden="true"></i>
                    <span class="u-visually-hidden">Meer info</span>
                  </a>
                  <div class="popover__content">
                    <p><strong>Attesten:</strong></p>
                    <p>Informatie over attesten</p>
                    <p>Bron: Departement van attesten</p>
                  </div>
                </div>
              </bl-h>
              <div class="u-spacer"></div>
            </bl-column>
          </bl-grid>
        </bl-layout>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 'm'}, {nom: 1, den: 1, mod: 's'}]" v-for="(data, index) in generalAttestenMockData" :key="index">
              <section class="bl-teaser-card bl-teaser-card--has-user-badge">
                <a href="#" class="bl-teaser-card__cta js-equal-height" data-equal-height="height" @click.prevent="showGeneralDrawer(index)">
                  <div class="bl-teaser-card__inner">
                    <div class="bl-teaser-card__header">
                      <div class="document-miniature document-miniature--alt document-miniature--flex">
                        <div class="document-miniature__type">
                          <span class="document-miniature__type__text">PDF</span>
                        </div>
                      </div>
                      <h1 class="bl-teaser-card__title">
                        <span class="bl-teaser-card__title__label">{{ data.title }}</span>
                      </h1>
                    </div>
                  </div>
                </a>
              </section>
            </bl-column>
          </bl-grid>
        </bl-layout>
        <template v-for="(data, index) in generalAttestenMockData">
          <div :class="{'drawer': true, 'js-drawer--visible': data.showDetail}" :key="index">
            <a href="#" class="link--icon--close drawer__close" @click.prevent="data.showDetail = false"><span class="u-visually-hidden">Venster sluiten</span></a>
            <bl-layout :mod-is-wide="true">
              <bl-grid :mod-is-stacked="true">
                <bl-column :cols="[{nom: 4, den: 12}, {nom: 1, den: 1, mod: 's'}]">
                  <div class="typography u-stroke-right">
                    <p>Een {{ data.title.toLowerCase() }} lorem ipsum dolor sit amet consectetur. Nuc ende isti. Lorem ipsum dolor sit amet consectur.</p>
                    <a href="#" target="_BLANK" class="link link--icon link--icon--after link--icon--external">Meer informatie over dit attest</a>
                  </div>
                </bl-column>
                <bl-column :cols="[{nom: 8, den: 12}, {nom: 1, den: 1, mod: 's'}]">
                  <div class="u-align-center" v-if="data.pdfIsLoading">
                    <div class="u-spacer--large"></div>
                    <div class="loader" aria-hidden="true"></div>
                    <p>Een ogenblik geduld. Het attest wordt opgevraagd.</p>
                    <div class="u-spacer--large"></div>
                  </div>
                  <template v-if="!data.pdfIsLoading">
                    <p><bl-button>Attest downloaden <i class="vi vi-external" aria-hidden="true"></i></bl-button>&nbsp;<a href="#" class="link">Attest meteen afdrukken</a></p>
                    <div class="u-spacer"></div>
                    <iframe style="background: #dedede;" src="http://www.rondevanvlaanderen.be/sites/default/files/pdf/dummy_pdf_1.pdf" width="100%" height="500px"></iframe>
                  </template>
                </bl-column>
              </bl-grid>
            </bl-layout>
          </div>
        </template>
        <bl-layout :mod-is-wide="true">
          <div class="u-spacer--large"></div>
          <bl-grid :mod-is-stacked="true" class="js-equal-height-container">
            <bl-column>
              <bl-h type="h3" class="h6">
                Vraag een attest bij de betrokken gemeente of overheid
                <div class="popover popover--left js-popover">
                  <a href="#" class="js-popover__toggle">
                    <i class="vi vi-u-badge vi-u-badge--action vi-u-badge--xsmall vi-info" aria-hidden="true"></i>
                    <span class="u-visually-hidden">Meer info</span>
                  </a>
                  <div class="popover__content">
                    <p><strong>Attesten:</strong></p>
                    <p>Informatie over attesten</p>
                    <p>Bron: Departement van attesten</p>
                  </div>
                </div>
              </bl-h>
              <div class="u-spacer"></div>
            </bl-column>
          </bl-grid>
        </bl-layout>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 'm'}, {nom: 1, den: 1, mod: 's'}]" v-for="(data, index) in cityAttestenMockData" :key="index">
              <section class="bl-teaser-card bl-teaser-card--has-user-badge">
                <a href="#" class="bl-teaser-card__cta js-equal-height" data-equal-height="height" @click.prevent="showCityDrawer(index)">
                  <div class="bl-teaser-card__inner">
                    <div class="bl-teaser-card__header">
                      <div class="bl-teaser-card__header__badges">
                        <bl-badge icon="icon-diploma" :mod-is-alt="true" :mod-is-bordered="true" :mod-is-small="true"></bl-badge>
                      </div>
                      <h1 class="bl-teaser-card__title">
                        <span class="bl-teaser-card__title__label">{{ data.title }}</span>
                      </h1>
                    </div>
                  </div>
                </a>
              </section>
            </bl-column>
          </bl-grid>
        </bl-layout>
        <template v-for="(data, index) in cityAttestenMockData">
          <div :class="{'drawer': true, 'js-drawer--visible': data.showDetail}" :key="index">
            <a href="#" class="link--icon--close drawer__close" @click.prevent="data.showDetail = false"><span class="u-visually-hidden">Venster sluiten</span></a>
            <bl-layout :mod-is-wide="true">
              <bl-grid :mod-is-stacked="true">
                <bl-column :cols="[{nom: 4, den: 12}, {nom: 1, den: 1, mod: 's'}]">
                  <div class="typography u-stroke-right">
                    <p>Een {{ data.title.toLowerCase() }} bevat de officiële gegevens over de geboorte van een persoon. </p>
                    <p>De akte dient u aan te vragen bij <strong>de gemeente waar u geboren bent.</strong></p>
                    <p>Vraagt u de akte aan voor een kind, vul dan de gemeente in waar het kind geboren is.</p>
                    <a href="#" target="_BLANK" class="link link--icon link--icon--after link--icon--external">Meer informatie over dit attest</a>
                  </div>
                </bl-column>
                <bl-column :cols="[{nom: 8, den: 12}, {nom: 1, den: 1, mod: 's'}]">
                  <bl-h type="h3" class="h3">Vraag een {{ data.title.toLowerCase() }} op in de gemeente van de geboorte:</bl-h>
                    <bl-radio-button :mod-is-block="true" :name="'geboorte-akte-' + data.id" label="Uw geboorteplaats: Gent" />
                    <bl-radio-button :mod-is-block="true" :name="'geboorte-akte-' + data.id" :checked="true" label="Een andere gemeente" />
                    <div class="u-spacer--tiny"></div>
                    <div class="search search--inline">
                      <label class="search__label" for="search-inline">Wat?</label>
                      <input class="input-field search__input" type="search" name="search-inline" id="search-inline" value="" placeholder="Zoek op gemeente" title="Wat wil u zoeken?" required/>
                      <button class="button search__submit" type="submit" aria-label="zoekterm">Zoeken</button>
                    </div>
                    <div class="u-spacer--tiny"></div>
                    <bl-alert type="error" title="Voor deze gemeente kunnen wij u niet doorverwijzen">
                      <p>Neem rechtstreeks contact op met de gemeente om daar het attest op te vragen.</p>
                    </bl-alert>
                    <div class="u-spacer"></div>
                    <p><a href="#" class="button">Opvragen <i class="vi vi-external" aria-hidden="true"></i></a><br><span class="u-small-text u-color-grey"> U wordt doorverwezen naar een andere gemeente</span></p>
                </bl-column>
              </bl-grid>
            </bl-layout>
          </div>
        </template>
      </bl-region>
    </bl-main>
  </div>
</template>

<script>

import BlAlert from '~components/partials/alert/Alert.vue'
import BlAccentHeader from '~components/partials/accent-header/AccentHeader.vue'
import BlIconNavigation from '~components/navigations/icon-navigation/IconNavigation.vue'
import BlPreloadCard from '~components/service-components/preload-card/PreloadCard.vue'
import BlTemporaryCard from '~components/service-components/temporary-card/TemporaryCard.vue'
import BlHSublink from '~components/typography/HSublink.vue'
import BlDescriptionData from '~components/partials/description-data/DescriptionData.vue'
import BlDescriptionDataItem from '~components/partials/description-data/DescriptionDataItem.vue'
import BlDescriptionDataItemWrapper from '~components/partials/description-data/DescriptionDataItemWrapper.vue'
import BlRadioButton from '~components/form-elements/radio-button/RadioButton.vue'
import BlBadge from '~components/partials/badge/Badge.vue'

export default {
  components: {
    BlAlert,
    BlAccentHeader,
    BlIconNavigation,
    BlPreloadCard,
    BlTemporaryCard,
    BlHSublink,
    BlDescriptionData,
    BlDescriptionDataItem,
    BlDescriptionDataItemWrapper,
    BlRadioButton,
    BlBadge
  },
  data () {
    return {
      pageSubtitle: 'Attesten',
      generalAttestenMockData: [
        {
          id: 'mock-1',
          title: 'Attest van nationaliteit',
          type: 'attest',
          showDetail: false,
          pdfIsLoading: true
        },
        {
          id: 'mock-2',
          title: 'Attest van leven',
          type: 'attest',
          showDetail: false,
          pdfIsLoading: true
        },
        {
          id: 'mock-3',
          title: 'Attest van wettelijke samenwoning',
          type: 'attest',
          showDetail: false,
          pdfIsLoading: true
        }
      ],
      cityAttestenMockData: [
        {
          id: 'mock-1',
          title: 'Geboorteakte',
          type: 'attest',
          showDetail: false
        },
        {
          id: 'mock-2',
          title: 'Akte van adoptie',
          type: 'attest',
          showDetail: false
        },
        {
          id: 'mock-3',
          title: 'Akte van naamgeving',
          type: 'attest',
          showDetail: false
        }
      ],
      residenceAttestenMockData: [
        {
          title: 'Geboorteakte',
          cardType: 'link'
        },
        {
          title: 'Akte van erkenning voor geboorte',
          cardType: 'link'
        },
        {
          title: 'Akte van erkenning na geboorte',
          cardType: 'link'
        },
        {
          title: 'Akte van adoptie',
          cardType: 'link'
        },
        {
          title: 'Akte van naamgeving',
          cardType: 'link'
        },
        {
          title: 'Akte van betwisting vaderschap',
          cardType: 'link'
        },
        {
          title: 'Akte van voornaamswijziging',
          cardType: 'link'
        },
        {
          title: 'Akte van nieuw geslacht',
          cardType: 'link'
        },
        {
          title: 'Huwelijksakte',
          cardType: 'link'
        },
        {
          title: 'Echtscheidingsakte',
          cardType: 'link'
        },
        {
          title: 'Overlijdensakte',
          cardType: 'link'
        },
        {
          title: 'Akte van nationaliteit',
          cardType: 'link'
        },
        {
          title: 'Uittreksel uit het strafregister',
          cardType: 'link'
        }
      ],
      preloadCards: 3,
      showLoader: false
    }
  },
  methods: {
    searchAttesten (e) {
      const self = this
      // Show the preloader.
      self.showLoader = true
      // Remove preloader after x seconds
      setTimeout(() => {
        self.showLoader = false
        vl.equalheight.resize()
      }, 2000)
    },
    showGeneralDrawer (index) {
      this.generalAttestenMockData.forEach((item) => {
        item.showDetail = false
      })
      this.cityAttestenMockData.forEach((item) => {
        item.showDetail = false
      })
      this.generalAttestenMockData[index].showDetail = !this.generalAttestenMockData[index].showDetail
      setTimeout(() => {
        this.generalAttestenMockData[index].pdfIsLoading = false
      }, 2000)
    },
    showCityDrawer (index) {
      this.generalAttestenMockData.forEach((item) => {
        item.showDetail = false
      })
      this.cityAttestenMockData.forEach((item) => {
        item.showDetail = false
      })
      this.cityAttestenMockData[index].showDetail = !this.cityAttestenMockData[index].showDetail
    }
  }
}
</script>
