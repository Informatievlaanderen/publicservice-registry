<template>
  <div>
    <header class="bl-accent-header js-accent-header" role="banner">
        <bl-layout :mod-is-wide="true">
          <bl-grid>
            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 's'}]">
              <div class="bl-accent-header__content">
                <div data-initials="WB" class="bl-accent-header__badge" />
                <h1 class="bl-accent-header__title">Warre Buysse</h1>
              </div>
            </bl-column>
            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 's'}]">
              <ul class="bl-accent-header__actions">
                <li class="bl-accent-header__actions__item">
                    <nuxt-link to="/siteimprove/wie-heeft-uw-gegevens-geraadpleegd" class="bl-accent-header__actions__item__cta link u-small-text">Wie heeft uw gegevens geraadpleegd</nuxt-link>
                </li>
                </li>
                <li class="bl-accent-header__actions__item">
                  <nuxt-link to="/login" class="bl-accent-header__actions__item__cta link u-small-text">INSZ</nuxt-link>&nbsp;
                  <a href="#" class="bl-accent-header__actions__item__cta link u-small-text" @click.prevent="$store.dispatch('session/logout', true)">Uitloggen</a>
                </li>
              </ul>
            </bl-column>
          </bl-grid>
        </bl-layout>
      <slot></slot>
    </header>
    <nav class="bl-icon-navigation">
      <bl-layout :mod-is-wide="true">
        <bl-grid>
          <bl-column>
            <ul class="bl-icon-navigation__list">
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/meest-recent" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-bell" size="0 0 19 19" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Meest recent</span>
                </nuxt-link>
              </li>
              <li role="separator" aria-hidden="true" class="bl-icon-navigation__separator"></li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/u-en-uw-gezin" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-people" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">U & uw gezin</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/woonst-en-vastgoed" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-house" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Woonst &<br>vastgoed</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <a href="" @click.prevent="" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-car" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Mobiliteit</span>
                </a>
              </li>
              <li class="bl-icon-navigation__item">
                <a href="" @click.prevent="" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-suitcase" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Werk &<br>pensioen</span>
                </a>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/onderwijs" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-hat" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Onderwijs & inburgering</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/belastingen-en-voordelen" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-cash" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Belastingen &<br>voordelen</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/attesten" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-diploma" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Attesten</span>
                </nuxt-link>
              </li>
            </ul>
          </bl-column>
        </bl-grid>
      </bl-layout>
    </nav>
    <bl-main>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
              <bl-h type="h2" class="h2">Hoofdverblijfplaats (gemockt, alle mogelijkheden)</bl-h>
              <div class="u-spacer"></div>
            </bl-column>
          </bl-grid>
        </bl-layout>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
              <bl-panel>
                <bl-panel-header title="Begijnenstraat 39, 2800 Mechelen" :badges="[{ icon: 'icon-pin', modIsAlt: true }]" />
              </bl-panel>
            </bl-column>
            <bl-column>
              <bl-panel>
                <bl-panel-header title="Lange Schipstraat 27, 2800 Mechelen" subtitle="Dit is het referentie-adres | U bent tijdelijk afwezig" :badges="[{ icon: 'icon-pin', modIsAlt: true }]" />
              </bl-panel>
            </bl-column>
            <bl-column>
              <bl-panel>
                <bl-panel-header title="Rue Tivoli 39, 75000 Paris, Frankrijk" subtitle="Diplomatieke post: Den Haag, Nederland" :badges="[{ icon: 'icon-pin', modIsAlt: true }]" />
              </bl-panel>
            </bl-column>
            <bl-column>
              <bl-panel>
                <bl-panel-header title="Rue Tivoli 39, 75000 Paris, Frankrijk" subtitle="Diplomatieke post: Den Haag, Nederland | Postadres:  Dorpsstraat 39, Den Haag, Nederland" :badges="[{ icon: 'icon-pin', modIsAlt: true }]" />
              </bl-panel>
            </bl-column>
            <bl-column>
              <bl-panel>
                <bl-panel-header title="Rue Tivoli 39, 75000 Paris, Frankrijk" subtitle="Diplomatieke post: onbekend (0422), Nederland" :badges="[{ icon: 'icon-pin', modIsAlt: true }]" />
              </bl-panel>
            </bl-column>
            <bl-column>
              <bl-panel>
                <bl-panel-header title="Begijnenstraat 39, 2800 Mechelen" :extra="[{ label: 'U hebt een adreswijziging doorgegeven' }]" :badges="[{ icon: 'icon-pin', modIsAlt: true }]" />
              </bl-panel>
            </bl-column>
          </bl-grid>
        </bl-layout>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">

            <div class="u-spacer--large"></div>

            <bl-column>
              <bl-h type="h2" class="h2">Eigendommen <span class="title-sublink__sub">(3)</span></bl-h>
              <div class="u-spacer"></div>
            </bl-column>

            <bl-column>
              <bl-panel>
                <bl-panel-header title="Geen eigendom gevonden" :badges="[{ modIsPlaceholder: true }]" />
                <bl-panel-body>
                  <template slot="content">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec ullamcorper scelerisque blandit. Aliquam id egestas felis. Aenean efficitur quis lorem sed faucibus. Vestibulum finibus, lacus ut pretium placerat, nisi lectus malesuada eros, at bibendum ligula augue nec sapien. Cras faucibus nisl erat, ut placerat risus facilisis quis.</p>
                  </template>
                </bl-panel-body>
              </bl-panel>
            </bl-column>

            <bl-column>
              <bl-panel>
                <bl-panel-header title="Begijnenstraat 39, 2800 Mechelen" subtitle="Bebouwd | U woonde hier op 01.01.2017" :extra="[{ label: 'Kadastrale afdeling: Mechelen 1' }, { label: 'Kadastrale aanduiding: A/144L/P0000' }]" :badges="[{ icon: 'icon-property-built', modIsAlt: true }]" />
                <bl-panel-body>
                  <template slot="content">
                    <bl-description-data>
                      <bl-grid :mod-is-stacked="true">
                        <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                          <bl-description-data-item-wrapper>
                            <bl-description-data-item class-type="subdata">Eigendom</bl-description-data-item>
                            <bl-description-data-item class-type="data">Natuurlijk persoon</bl-description-data-item>
                            <bl-description-data-item class-type="data">1 aandeel van 2 in volle eigendom</bl-description-data-item><br>
                            <bl-description-data-item class-type="data">U bent de enige eigenaar</bl-description-data-item>
                          </bl-description-data-item-wrapper>
                        </bl-column>
                        <bl-column :cols="[{nom: 2, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                          <bl-grid>
                            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
                              <bl-description-data-item-wrapper>
                                <bl-description-data-item class-type="subdata">Belastbaar kadastraal inkomen (KI)</bl-description-data-item>
                                <bl-description-data-item class-type="data">1.100 €</bl-description-data-item>
                              </bl-description-data-item-wrapper>
                            </bl-column>
                            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
                              <bl-description-data-item-wrapper>
                                <bl-description-data-item class-type="subdata">Administratieve gemeente</bl-description-data-item>
                                <bl-description-data-item class-type="data">Mechelen</bl-description-data-item>
                              </bl-description-data-item-wrapper>
                            </bl-column>
                            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
                              <bl-description-data-item-wrapper>
                                <bl-description-data-item class-type="subdata">Bouwjaar</bl-description-data-item>
                                <bl-description-data-item class-type="data">2001</bl-description-data-item>
                              </bl-description-data-item-wrapper>
                            </bl-column>
                          </bl-grid>
                        </bl-column>
                      </bl-grid>
                    </bl-description-data>
                  </template>
                </bl-panel-body>
              </bl-panel>
            </bl-column>

            <bl-column>
              <bl-panel>
                <bl-panel-header title="Lechten het gehucht, Bocholt" subtitle="Onbebouwd | Dichtsbijzijnde adres: Grote Steenweg 132, 3950 Bocholt" :extra="[{ label: 'Kadastrale afdeling: Mechelen 1' }, { label: 'Kadastrale aanduiding: A/144L/P0000' }]" :badges="[{ icon: 'icon-property-unbuilt', modIsAlt: true }]" />
                <bl-panel-body>
                  <template slot="content">
                    <bl-description-data>
                      <bl-grid :mod-is-stacked="true">
                        <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                          <bl-description-data-item-wrapper>
                            <bl-description-data-item class-type="subdata">Eigendom</bl-description-data-item>
                            <bl-description-data-item class-type="data">In gemeenschap</bl-description-data-item>
                            <bl-description-data-item class-type="data">Volle eigendom</bl-description-data-item><br>
                            <bl-description-data-item class-type="data">3 mede-eigenaars</bl-description-data-item>
                          </bl-description-data-item-wrapper>
                        </bl-column>
                        <bl-column :cols="[{nom: 2, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                          <bl-grid>
                            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
                              <bl-description-data-item-wrapper>
                                <bl-description-data-item class-type="subdata">Belastbaar kadastraal inkomen (KI)</bl-description-data-item>
                                <bl-description-data-item class-type="data">1.100 €</bl-description-data-item>
                              </bl-description-data-item-wrapper>
                            </bl-column>
                            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
                              <bl-description-data-item-wrapper>
                                <bl-description-data-item class-type="subdata">Administratieve gemeente</bl-description-data-item>
                                <bl-description-data-item class-type="data">Bocholt</bl-description-data-item>
                              </bl-description-data-item-wrapper>
                            </bl-column>
                          </bl-grid>
                        </bl-column>
                      </bl-grid>
                    </bl-description-data>
                  </template>
                </bl-panel-body>
              </bl-panel>
            </bl-column>

            <bl-column>
              <bl-panel>
                <bl-panel-header title="Antwerpsesteenweg 89, 9000 Gent" :badges="[{ icon: 'icon-property-unknown', modIsAlt: true }]" />
                <bl-panel-body>
                  <template slot="content">
                    <bl-description-data>
                      <bl-grid :mod-is-stacked="true">
                        <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                          <bl-description-data-item-wrapper>
                            <bl-description-data-item class-type="subdata">Eigendom</bl-description-data-item>
                            <bl-description-data-item class-type="data">In gemeenschap</bl-description-data-item>
                            <bl-description-data-item class-type="data">1 aandeel van 2 in volle eigendom</bl-description-data-item><br>
                            <bl-description-data-item class-type="data">2 mede-eigenaars</bl-description-data-item>
                          </bl-description-data-item-wrapper>
                        </bl-column>
                        <bl-column :cols="[{nom: 2, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                          <bl-grid>
                            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
                              <bl-description-data-item-wrapper>
                                <bl-description-data-item class-type="subdata">Belastbaar kadastraal inkomen (KI)</bl-description-data-item>
                                <bl-description-data-item class-type="data">1.100 €</bl-description-data-item>
                              </bl-description-data-item-wrapper>
                            </bl-column>
                            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
                              <bl-description-data-item-wrapper>
                                <bl-description-data-item class-type="subdata">Administratieve gemeente</bl-description-data-item>
                                <bl-description-data-item class-type="data">Gent</bl-description-data-item>
                              </bl-description-data-item-wrapper>
                            </bl-column>
                            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
                              <bl-description-data-item-wrapper>
                                <bl-description-data-item class-type="subdata">Bouwjaar</bl-description-data-item>
                                <bl-description-data-item class-type="data">van 1910 tot 1917</bl-description-data-item>
                              </bl-description-data-item-wrapper>
                            </bl-column>
                          </bl-grid>
                        </bl-column>
                      </bl-grid>
                    </bl-description-data>
                  </template>
                </bl-panel-body>
              </bl-panel>
            </bl-column>



          </bl-grid>
        </bl-layout>
      </bl-region>
    </bl-main>
  </div>
</template>

<script>

import BlAlert from '~components/partials/alert/Alert.vue'
import BlAccentHeader from '~components/partials/accent-header/AccentHeader.vue'
import BlIconNavigation from '~components/navigations/icon-navigation/IconNavigation.vue'
import BlPreloadCard from '~components/service-components/preload-card/PreloadCard.vue'
import BlPanel from '~components/partials/panel/Panel.vue'
import BlPanelHeader from '~components/partials/panel/panel-header/PanelHeader.vue'
import BlPanelBody from '~components/partials/panel/panel-body/PanelBody.vue'
import BlPanelBodyAccordion from '~components/partials/panel/panel-body/PanelBodyAccordion.vue'
import BlDescriptionData from '~components/partials/description-data/DescriptionData.vue'
import BlDescriptionDataItem from '~components/partials/description-data/DescriptionDataItem.vue'
import BlDescriptionDataItemWrapper from '~components/partials/description-data/DescriptionDataItemWrapper.vue'

export default {
  components: {
    BlAlert,
    BlAccentHeader,
    BlIconNavigation,
    BlPreloadCard,
    BlPanel,
    BlPanelHeader,
    BlPanelBody,
    BlPanelBodyAccordion,
    BlDescriptionData,
    BlDescriptionDataItem,
    BlDescriptionDataItemWrapper
  },
  data () {
    return {
      pageTitle: 'Uw gegevens bij de overheid',
      pageSubtitle: 'Woonst & vastgoed',
      preloadCards: 3,
      showLoader: false
    }
  },
  methods: {
  },
  computed: {
  },
  mounted () {
  }
}
</script>
