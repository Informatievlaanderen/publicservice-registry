<template>
  <div>
    <bl-navigation-header page-title="Uw profiel" :has-badge="false">
      <bl-navigation-header-profile @edit-profile-was-clicked="modals.editProfile.active = !modals.editProfile.active" />
    </bl-navigation-header>
    <bl-main>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column :cols="[{nom: 6, den: 12}, {nom: 8, den: 12, mod: 'm'}, {nom: 1, den: 1, mod: 's'}]">
              <bl-h type="h2" class="h2">Persoonlijke gegevens</bl-h>
              <form action="">
                <!-- <div class="form__row form__row--inline">
                  <div class="form__label">
                    <label for="lastName">Aanspreking:</label>
                  </div>
                  <div class="form__input">
                    <select class="select select--block" name="">
                      <option value="">Dhr.</option>
                      <option value="">Mevr.</option>
                      <option value="">Juff.</option>
                    </select>
                  </div>
                </div> -->
                <bl-form-row :mod-is-inline="true">
                  <bl-label for="lastName">Naam:</bl-label>
                  <bl-input-field name="lastName" id="lastName" :value="lastName" :mod-is-block="true" :disabled="true" />
                </bl-form-row>
                <bl-form-row :mod-is-inline="true">
                  <bl-label for="firstName">Voornaam:</bl-label>
                  <bl-input-field name="firstName" id="firstName" :value="firstName" :mod-is-block="true" :disabled="true" />
                </bl-form-row>
                <bl-form-row :mod-is-inline="true">
                  <bl-label for="calloutName">Roepnaam:</bl-label>
                  <div class="bl-inline-validation-wrapper">
                    <input @blur="updateProfile($event)" class="input-field input-field--block" name="calloutName" id="calloutName" :value="profile.nickname" />
                    <div class="bl-inline-validation" v-if="showLoader || showSuccess">
                      <template v-if="showLoader">
                        <div v-if="showLoader" class="bl-inline-validation__loader loader"></div>
                      </template>
                      <template v-if="showSuccess">
                        <i class="bl-inline-validation__icon vi vi-check"></i>
                        <span class="bl-inline-validation__value">bewaard</span>
                      </template>
                    </div>
                  </div>
                </bl-form-row>
              </form>
            </bl-column>
          </bl-grid>
        </bl-layout>
      </bl-region>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column :cols="[{nom: 8, den: 12}, {nom: 10, den: 12, mod: 'm'}, {nom: 1, den: 1, mod: 's'}]">
              <bl-h type="h2" class="h2 u-spacer--none">{{ contactPreferences.title }}</bl-h>
              <bl-typography>
                <p>{{ contactPreferences.description }}</p>
              </bl-typography>
            </bl-column>
            <bl-column v-for="(item, index) in contactPreferences.list" :key="index">
              <div class="bl-card bl-card--alt js-accordion js-accordion--open">
                <div class="bl-card__header">
                  <button type="button" class="bl-card__header__cta js-accordion__toggle">
                    <span class="bl-card__header__cta__icon vi vi-u-badge vi-u-badge--small vi-arrow vi-u-90deg" aria-hidden="true"></span>
                    <div class="bl-card__header__content bl-card__header__content--flex">
                      <div>
                        <h1 class="bl-card__header__title">{{ item.departement }}</h1>
                        <p class="bl-card__header__meta">{{ item.organization }}</p>
                      </div>
                      <ul class="bl-card__header__content__extra">
                        <li class="bl-card__header__content__extra__item" v-for="(field, index) in item.fields" :key="index">{{ field.value }}</li>
                      </ul>
                    </div>
                  </button>
                </div>
                <div class="accordion__content">
                  <div class="bl-card__content">
                    <bl-grid>
                      <bl-column :cols="[{nom: 1, den: 1}]">
                        <template v-for="(field, index) in item.fields">
                          <bl-form-grid :mod-is-stacked="true" :mod-is-v-center="true">

                            <!-- Edit block -->
                            <template v-if="field.edit">
                              <bl-column v-if="index">
                                <div class="u-spacer--small"></div>
                                <bl-spacer :modIsSmall="true" />
                                <bl-horizontal-ruler />
                                <bl-spacer :modIsTiny="true" />
                              </bl-column>
                              <bl-column :cols="[{nom: 3, den: 12}, {nom: 1, den: 1, mod: 's'}]">
                                <bl-label :for="field.options.label">{{ field.options.label }}:</bl-label>
                              </bl-column>
                              <bl-column :cols="[{nom: 5, den: 12}, {nom: 1, den: 1, mod: 's'}]">
                                <select class="select select--block" :id="field.options.label" :name="field.options.label" v-model="field.selected">
                                  <option v-for="(opt, index) in field.options.list" :key="index" :value="opt">{{ opt }}</option>
                                  <option v-if="field.addNew" :value="field.addNew.id">{{ field.addNew.label }}</option>
                                </select>
                              </bl-column>
                              <bl-column :cols="[{nom: 4, den: 12}]" class="u-hidden-mobile"></bl-column>
                            </template>
                            <!-- END Edit block -->

                            <!-- View block -->
                            <template v-if="!field.edit">
                              <bl-column :cols="[{nom: 3, den: 12}, {nom: 1, den: 1, mod: 's'}]">
                                <bl-label :for="field.options.label">{{ field.options.label }}:</bl-label>
                              </bl-column>
                              <bl-column :cols="[{nom: 5, den: 12}, {nom: 1, den: 1, mod: 's'}]">
                                <p class="u-small-text">{{ field.value }}</p>
                              </bl-column>
                              <bl-column :cols="[{nom: 4, den: 12}]" class="u-hidden-mobile"></bl-column>
                            </template>
                            <!-- END View block -->

                            <!-- New Input block -->
                            <template v-if="field.addNew">
                              <bl-column v-if="field.selected === field.addNew.id">
                                <bl-form-grid :mod-is-stacked="true" :mod-is-v-center="true">
                                  <bl-column :cols="[{nom: 3, den: 12}, {nom: 1, den: 1, mod: 's'}]">
                                    <bl-label :for="field.addNew.id">{{ field.addNew.label }}:</bl-label>
                                  </bl-column>
                                  <bl-column :cols="[{nom: 5, den: 12}, {nom: 1, den: 1, mod: 's'}]">
                                    <bl-input-field :name="field.addNew.id" :id="field.addNew.id" :mod-is-block="true" />
                                  </bl-column>
                                  <bl-column :cols="[{nom: 4, den: 12}, {nom: 1, den: 1, mod: 's'}]">
                                    <bl-button-group>
                                      <bl-button type="submit" label="Bewaren"/>
                                      <bl-button type="reset" v-on:click.native="field.selected = field.value" label="Annuleren" :mod-is-link="true"/>
                                    </bl-button-group>
                                  </bl-column>
                                </bl-form-grid>
                              </bl-column>
                            </template>
                            <!-- END New Input block -->

                            <!-- Consent block -->
                            <template v-if="field.consent">
                              <bl-column :cols="[{nom: 3, den: 12}, {nom: 1, den: 1, mod: 's'}]" class="u-hidden-mobile"></bl-column>
                              <bl-column :cols="[{nom: 5, den: 12}, {nom: 1, den: 1, mod: 's'}]">
                                <bl-checkbox class="u-small-text" :mod-is-block="true" :checked="field.consent.checked" :label="field.consent.label" />
                              </bl-column>
                            </template>
                            <!-- END Consent block -->

                          </bl-form-grid>
                        </template>
                      </bl-column>
                      <!-- External block -->
                      <template v-if="item.external">
                        <bl-column>
                          <div class="u-spacer"></div>
                          <p class="u-small-text">{{ item.external.title }}</p>
                          <div class="u-spacer--tiny"></div>
                          <a :href="item.external.linkUrl" target="_BLANK" class="button">{{ item.external.linkLabel }}</a>
                        </bl-column>
                      </template>
                      <!-- END External block -->
                    </bl-grid>
                  </div>
                </div>
              </div>
            </bl-column>
          </bl-grid>
        </bl-layout>
      </bl-region>
    </bl-main>
    <div class="overlay" v-if="modals.editProfile.active" @click="modals.editProfile.active = false">
      <div class="modal-dialog" role="document" v-if="modals.editProfile.currentStep === 1" @click="(e) => { e.stopPropagation() }">
        <a href="" class="modal-dialog__close link--icon--close" @click.prevent="modals.editProfile.active = false"><span class="u-visually-hidden">Venster sluiten</span></a>
        <h2 class="modal-dialog__title">Wijzig profielfoto</h2>
        <div class="modal-dialog__content">
          <bl-grid :mod-is-stacked="true" class="js-equal-height-container">
            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
              <div class="bl-card bl-card--center js-equal-height">
                <a href="#" class="bl-card__wrap">
                  <label>
                    <div class="bl-card__content">
                      <div class="bl-card__badges" aria-hidden="true">
                        <bl-badge icon="icon-person-placeholder-masculin" :mod-is-alt="true" :mod-is-bordered="true" :mod-is-large="true" :mod-is-icon-stretched="true"></bl-badge>
                      </div>
                      <span class="bl-card__link">Foto kiezen</span>
                      <input class="cropper__upload" type="file" name="image" accept="image/*" style="display:none" @change="setImage($event)" />
                    </div>
                  </label>
                </a>
              </div>
            </bl-column>
            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
              <div class="bl-card bl-card--center js-equal-height">
                <a href="#" class="bl-card__wrap">
                  <div class="bl-card__content">
                    <div class="bl-card__badges" aria-hidden="true">
                      <bl-badge icon="icon-passport" :mod-is-alt="true" :mod-is-bordered="true" :mod-is-large="true" :mod-is-icon-stretched="true"></bl-badge>
                    </div>
                    <span class="bl-card__link">Pasfoto gebruiken</span>
                  </div>
                </a>
              </div>
            </bl-column>
            <bl-column :cols="[{nom: 1, den: 1}]">
              <div class="bl-card bl-card--center u-visible-mobile">
                <a href="#" class="bl-card__wrap">
                  <div class="bl-card__content">
                    <span class="bl-card__link">Initialen gebruiken</span>
                  </div>
                </a>
              </div>
            </bl-column>
          </bl-grid>
        </div>
        <div class="modal-dialog__buttons">
          <bl-grid :mod-is-stacked="true">
            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
              <bl-button-group>
                <bl-button class="modal-dialog__button u-hidden-mobile" label="Initialen gebruiken" :mod-is-link="true" aria-hidden="true"></bl-button>
              </bl-button-group>
            </bl-column>
            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
              <bl-button-group :mod-is-right="true">
                <bl-button v-on:click.prevent.native="modals.editProfile.active = false" class="modal-dialog__button" label="Annuleren" :mod-is-link="true"></bl-button>
                <bl-button class="modal-dialog__button button" label="Opslaan"></bl-button>
              </bl-button-group>
            </bl-column>
          </bl-grid>
        </div>
      </div>
      <div class="modal-dialog" role="document" v-if="modals.editProfile.currentStep === 2" @click="(e) => { e.stopPropagation() }">
        <h2 class="modal-dialog__title">Nieuwe foto toevoegen</h2>
        <div class="modal-dialog__content">
          <div class="cropper">
            <template v-if="!imgSrc">
              <input class="cropper__upload" type="file" name="image" accept="image/*" @change="setImage($event)" />
            </template>
            <div class="cropper__board">
                <vue-cropper v-if="imgSrc"
                    ref="cropper"
                    :view-mode="2"
                    drag-mode="move"
                    :auto-crop-area="0.8"
                    :aspect-ratio="1"
                    :min-crop-box-width="250"
                    :min-crop-box-height="100"
                    :src="imgSrc"
                    alt="Source Image"
                    :cropmove="cropImage">
                </vue-cropper>
                <!-- <vue-cropper ref="cropper"></vue-cropper> -->
            </div>
            <bl-icon-button icon="icon-rotate" icon-size="0 0 20 19" v-if="imgSrc" label="Roteren" class="cropper__rotation" v-on:click.native="rotate"></bl-icon-button>
          </div>
        </div>
        <div class="u-spacer--small"></div>
        <template v-if="imgSrc">
          <bl-grid :mod-is-stacked="true" :mod-is-v-center="true">
            <bl-column :cols="[{nom: 1, den: 4}, {nom: 1, den: 3, mod: 'xs'}]">
              <div class="cropper__preview">
                <img :src="cropImg" class="cropper__preview__image" alt="Voorvertoning" />
              </div>
            </bl-column>
            <bl-column :cols="[{nom: 3, den: 4}, {nom: 2, den: 3, mod: 'xs'}]">
              <bl-h type="h2" class="h4">Dit is een voorvertoning van uw profielfoto</bl-h>
              <p>Sleep om de foto te verplaatsen. Door de blauwe vierkanten aan de blauwe randen vast te pakken, kan de selectie vergroot of verkleind worden.</p>
            </bl-column>
          </bl-grid>
        </template>
        <div class="modal-dialog__buttons">
          <bl-button-group :mod-is-right="true" v-if="imgSrc">
            <a href="#" @click.prevent="changeCurrentStep(1, $event)" role="button" class="modal-dialog__button">Annuleren</a>
            <bl-button v-on:click.prevent.native="modals.editProfile.active = false" class="modal-dialog__button button" label="Opslaan"></bl-button>
          </bl-button-group>
        </div>
      </div>
    </div>
  </div>

</template>

<script>
import { mapGetters } from 'vuex'

import BlNavigationHeader from '~components/navigations/navigation-header/NavigationHeader.vue'
import BlFormGrid from '~components/frame/form-grid/FormGrid.vue'
import BlNavigationHeaderProfile from '~components/navigations/navigation-header/NavigationHeaderProfile.vue'
import BlCheckbox from '~components/form-elements/checkbox/Checkbox.vue'
import BlSpacer from '~components/utilities/spacer/Spacer.vue'
import BlHorizontalRuler from '~components/utilities/horizontal-ruler/HorizontalRuler.vue'
import BlLabel from '~components/form-elements/label/Label.vue'
import BlFormRow from '~components/form-elements/form-row/FormRow.vue'
import BlInputField from '~components/form-elements/input-field/InputField.vue'
import BlSelect from '~components/form-elements/select/Select.vue'
import BlButton from '~components/form-elements/button/Button.vue'
import BlIconButton from '~components/form-elements/icon-button/IconButton.vue'
import BlButtonGroup from '~components/form-elements/button-group/ButtonGroup.vue'
import BlBadge from '~components/partials/badge/Badge.vue'

const VueCropper = process.BROWSER_BUILD ? require('vue-cropperjs').default : null

export default {
  components: {
    BlNavigationHeader,
    BlNavigationHeaderProfile,
    BlCheckbox,
    BlFormGrid,
    BlSpacer,
    BlHorizontalRuler,
    VueCropper,
    BlLabel,
    BlFormRow,
    BlInputField,
    BlSelect,
    BlButton,
    BlIconButton,
    BlButtonGroup,
    BlBadge
  },
  middleware: ['authenticated'],
  data () {
    return {
      profile: {
        nickname: this.$store.getters['session/nickname'] || null
      },
      showSuccess: false,
      showLoader: false,
      accordions: {
        emailAccordion: false,
        telAccordion: false
      },
      modals: {
        editProfile: {
          active: false,
          currentStep: 1
        }
      },
      imgSrc: '',
      cropImg: '',
      contactPreferences: {
        title: 'Contactgegevens en -voorkeuren (gemockte data)',
        description: 'Hieronder ziet u een overzicht van de contactgegevens en -voorkeurendie de aangesloten partners van u kenen. U kan uw contactgegevens en -voorkeuren per partner beheren.',
        list: [
          {
            departement: 'Studietoelagen',
            organization: 'Ahovoks',
            fields: [
              {
                edit: true,
                selected: 'familiedeprez@deprez.be',
                value: 'familiedeprez@deprez.be',
                options: {
                  label: 'E-mailadres',
                  list: [
                    'thomasdeprez@gmail.com',
                    'familiedeprez@deprez.be'
                  ]
                },
                consent: {
                  checked: true,
                  label: 'U geeft Ahovoks de toestemming om u in het kader van Studietoelagen via e-mail te contacteren.'
                },
                addNew: {
                  id: 'new-email-field-1',
                  label: 'Nieuw e-mailadres',
                  type: 'email',
                  isOpen: false
                }
              },
              {
                edit: true,
                selected: '0497 632 332',
                value: '0497 632 332',
                options: {
                  label: 'Telefoonnummer',
                  list: [
                    '0497 632 332',
                    '0472 533 074'
                  ]
                },
                consent: {
                  checked: false,
                  label: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti, praesentium.'
                },
                addNew: {
                  id: 'new-telephone-field-1',
                  label: 'Nieuw telefoonnummer',
                  type: 'text',
                  isOpen: false
                }
              }
            ]
          },
          {
            departement: 'Persoonsvolgend budget',
            organization: 'VAPH',
            fields: [
              {
                edit: false,
                selected: null,
                value: 'thomasdeprez@gmail.com',
                options: {
                  label: 'E-mailadres',
                  list: null
                },
                consent: null,
                addNew: null
              },
              {
                edit: false,
                selected: null,
                value: '0497 632 332',
                options: {
                  label: 'Telefoonnummer',
                  list: null
                },
                consent: null,
                addNew: null
              }
            ],
            external: {
              title: 'Uw contactgegevens en -voorkeuren dient u bij Studietoelagen te wijzigen',
              linkUrl: '#',
              linkLabel: 'Gegevens wijzigen bij Studietoelagen'
            }
          }
        ]
      }
    }
  },
  methods: {
    updateProfile (e) {
      const self = this
      // Return when current value and nickname are the same.
      if (e.target.value === this.profile.nickname) {
        return
      }
      // Sync values.
      this.profile.nickname = e.target.value || null
      // Set success state default to false.
      self.showSuccess = false
      // Show the preloader.
      self.showLoader = true
      // Update the profile.
      this.$store.dispatch('session/updateProfile', this.profile).then(() => {
        // Show the success message.
        self.showSuccess = true
        // Remove the loader.
        self.showLoader = false
      })
      // Check with Warre for loading and error!
    },
    changeCurrentStep (step, event) {
      event.stopPropagation()
      this.modals.editProfile.currentStep = step
    },
    isAdvancedUpload () {
      var div = document.createElement('div')
      return (('draggable' in div) || ('ondragstart' in div && 'ondrop' in div)) && 'FormData' in window && 'FileReader' in window
    },
    setImage (e) {
      const self = this
      const file = e.target.files[0]

      if (!file.type.includes('image/')) {
        alert('Please select an image file')
        return
      }

      if (typeof FileReader === 'function') {
        const reader = new FileReader()

        reader.onload = (event) => {
          self.imgSrc = event.target.result
          self.cropImg = event.target.result

          self.changeCurrentStep(2, event)
        }
        reader.readAsDataURL(file)
      } else {
        alert('Sorry, FileReader API not supported')
      }
    },
    cropImage () {
      const self = this
      self.cropImg = self.$refs.cropper.getCroppedCanvas().toDataURL()
    },
    rotate () {
      const self = this
      self.$refs.cropper.rotate(90)
      self.cropImage()
    }
  },
  computed: {
    ...mapGetters({
      firstName: 'session/firstName',
      lastName: 'session/lastName',
      fullName: 'session/fullName'
    })
  },
  mounted () {
    vl.accordion.dressAll()
    this.$store.dispatch('session/profile')
  }
}
</script>
