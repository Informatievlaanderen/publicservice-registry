<template>
  <div>
    <header class="bl-accent-header js-accent-header" role="banner">
        <bl-layout :mod-is-wide="true">
          <bl-grid>
            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 's'}]">
              <div class="bl-accent-header__content">
                <div data-initials="WB" class="bl-accent-header__badge" />
                <h1 class="bl-accent-header__title">Warre Buysse</h1>
              </div>
            </bl-column>
            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 's'}]">
              <ul class="bl-accent-header__actions">
                <li class="bl-accent-header__actions__item">
                    <nuxt-link to="/siteimprove/wie-heeft-uw-gegevens-geraadpleegd" class="bl-accent-header__actions__item__cta link u-small-text">Wie heeft uw gegevens geraadpleegd</nuxt-link>
                </li>
                </li>
                <li class="bl-accent-header__actions__item">
                  <nuxt-link to="/login" class="bl-accent-header__actions__item__cta link u-small-text">INSZ</nuxt-link>&nbsp;
                  <a href="#" class="bl-accent-header__actions__item__cta link u-small-text" @click.prevent="$store.dispatch('session/logout', true)">Uitloggen</a>
                </li>
              </ul>
            </bl-column>
          </bl-grid>
        </bl-layout>
      <slot></slot>
    </header>
    <nav class="bl-icon-navigation">
      <bl-layout :mod-is-wide="true">
        <bl-grid>
          <bl-column>
            <ul class="bl-icon-navigation__list">
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/meest-recent" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-bell" size="0 0 19 19" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Meest recent</span>
                </nuxt-link>
              </li>
              <li role="separator" aria-hidden="true" class="bl-icon-navigation__separator"></li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/u-en-uw-gezin" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-people" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">U & uw gezin</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/woonst-en-vastgoed" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-house" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Woonst &<br>vastgoed</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <a href="" @click.prevent="" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-car" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Mobiliteit</span>
                </a>
              </li>
              <li class="bl-icon-navigation__item">
                <a href="" @click.prevent="" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-suitcase" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Werk &<br>pensioen</span>
                </a>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/onderwijs" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-hat" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Onderwijs & inburgering</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/belastingen-en-voordelen" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-cash" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Belastingen &<br>voordelen</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/attesten" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-diploma" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Attesten</span>
                </nuxt-link>
              </li>
            </ul>
          </bl-column>
        </bl-grid>
      </bl-layout>
    </nav>
    <bl-main>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
                <bl-h type="h2" class="h2">{{ pageSubtitle }}</bl-h>
            </bl-column>
            <bl-column>
              <bl-typography>
                <p>
                  Hier vindt u een chronologisch overzicht van uw diploma’s en leerbewijzen die bekend zijn bij de Vlaamse Overheid. Opgelet: niet elke diploma is opgenomen. We starten vanaf 1999 of 2013, afhankelijk van het type opleiding.
                </p>
              </bl-typography>
              <!--<a v-if="$store.getters['education/eventsReference'] !== null" class="link--icon--external link--icon--after" :href="$store.getters['education/eventsReference'].url" target="_BLANK">Bekijk meer details in de {{ $store.getters['education/eventsReference'].label }}</a>-->
              <a href="#">Welke diploma's worden vermeld en welke niet?</a>
            </bl-column>
            <template v-if="!$store.getters['education/eventsFailed']">
              <template v-if="!educationEventsTimelineLoaded">
                <bl-column>
                  <bl-separator :title="new Date().getFullYear()" />
                </bl-column>
                <bl-column v-for="(pl, index) in mockEducationEventsTimeline" :key="index" class="js-preloading">
                  <bl-preload-card />
                </bl-column>
              </template>
              <template v-else>
                <template v-if="educationEventsTimeline.length">
                  <bl-column v-for="(educationEvent, i) in educationEventsTimeline" :key="i">
                    <bl-separator :title="(educationEvent.year === null || educationEvent.year === 0 ? 'Datum ongekend' : educationEvent.year)" />
                    <bl-grid :mod-is-stacked="true">
                      <bl-column v-for="(item, j) in educationEvent.items" :key="j">
                        <template v-if="item.type === 'default'">
                          <bl-education-card :data="item" />
                        </template>
                        <template v-if="item.type === 'dutch-language'">
                          <bl-dutch-language-card :data="item" />
                        </template>
                        <template v-if="item.type === 'integration'">
                          <bl-integration-card :data="item" />
                        </template>
                      </bl-column>
                    </bl-grid>
                  </bl-column>
                </template>
                <template v-else>
                  <bl-column>
                    <bl-alert title="Geen behaalde leer- en ervaringsbewijzen">
                      <p>U bezit momenteel geen behaalde leer- en ervaringsbewijzen.</p>
                    </bl-alert>
                  </bl-column>
                </template>
              </template>
            </template>
            <template v-else>
              <bl-column>
                <bl-alert type="error" title="Geen verbinding">
                  <bl-typography>
                    <p>Er kan op dit moment geen verbinding gemaakt worden waardoor we hier uw behaalde leer- en ervaringsbewijzen niet kunnen tonen. Van zodra het probleem is opgelost, vindt u hier een overzicht van uw leer- en ervaringsbewijzen.</p>
                  </bl-typography>
                </bl-alert>
              </bl-column>
            </template>
          </bl-grid>
        </bl-layout>
      </bl-region>
    </bl-main>
  </div>
</template>

<script>

import BlAlert from '~components/partials/alert/Alert.vue'
import BlAccentHeader from '~components/partials/accent-header/AccentHeader.vue'
import BlIconNavigation from '~components/navigations/icon-navigation/IconNavigation.vue'
import BlPreloadCard from '~components/service-components/preload-card/PreloadCard.vue'
import BlEducationCard from '~components/service-components/education-card/EducationCard.vue'
import BlDutchLanguageCard from '~components/service-components/dutch-language-card/DutchLanguageCard.vue'
import BlIntegrationCard from '~components/service-components/integration-card/IntegrationCard.vue'
import BlHSublink from '~components/typography/HSublink.vue'
import BlSeparator from '~components/partials/separator/Separator.vue'

export default {
  components: {
    BlAlert,
    BlAccentHeader,
    BlIconNavigation,
    BlPreloadCard,
    BlEducationCard,
    BlDutchLanguageCard,
    BlIntegrationCard,
    BlHSublink,
    BlSeparator
  },
  data () {
    return {
      pageSubtitle: 'Onderwijsloopbaan',
      mockEducationEventsTimeline: 2,
      educationEventsTimeline: [],
      educationEventsTimelineLoaded: false
    }
  },
  mounted () {
    // Get a reference to ourself.
    const self = this

    setTimeout(() => {
      // Get the education events timeline.
      self.educationEventsTimeline = [
         {
            "year":2017,
            "items":[
               {
                  "id":"w7h1yqinsnltjki1sfez5mi",
                  "type":"dutch-language",
                  "category":null,
                  "year":2017,
                  "institute":{
                     "name":"Integratie en Inburgering Antwerpen",
                     "address":{
                        "street":{
                           "name":"Carnotstraat",
                           "number":"3",
                           "box":null
                        },
                        "city":{
                           "name":"Antwerpen",
                           "code":"2060"
                        },
                        "country":{
                           "name":"België",
                           "code":"BE"
                        }
                     }
                  },
                  "education":"Adviestraject Nederlandse taal",
                  "reference":{
                     "url":"https://www.kbi-connect.be/burger",
                     "label":"Kruispuntbank Inburgering",
                     "type":"text/html"
                  },
                  "meta":{
                     "grantsCertificateSecundary":false
                  },
                  "certificates":{
                     "reference":null,
                     "items":[

                     ],
                     "meta":{

                     }
                  },
                  "registrations":{
                     "reference":null,
                     "items":[

                     ],
                     "meta":{
                        "firstRegistration":null
                     }
                  }
               },
               {
                  "id":"rxsi2qd60z2st30n2wjct0529",
                  "type":"integration",
                  "category":null,
                  "year":2017,
                  "institute":{
                     "name":"Integratie en Inburgering Antwerpen",
                     "address":{
                        "street":{
                           "name":"Carnotstraat",
                           "number":"3",
                           "box":null
                        },
                        "city":{
                           "name":"Antwerpen",
                           "code":"2060"
                        },
                        "country":{
                           "name":"België",
                           "code":"BE"
                        }
                     }
                  },
                  "education":"Inburgeringstraject",
                  "reference":null,
                  "meta":{
                     "grantsCertificateSecundary":false,
                     "status":{
                        "name":"open traject",
                        "code":"TS"
                     },
                     "decision":{
                        "date":null,
                        "name":null,
                        "code":null,
                        "reason":""
                     },
                     "careerOrientationAdvice":null,
                     "target":{
                        "type":{
                           "naam":"Verplichte inburgeraar",
                           "code":"PLICHT"
                        },
                        "reason":{
                           "noTarget":null,
                           "notMandatory":null
                        }
                     },
                     "violations":{
                        "reference":null,
                        "items":[
                           {
                              "type":{
                                 "name":"Niet tijdig aangemeld",
                                 "code":"1"
                              },
                              "recordDate":{
                                 "value":"2017-03-03",
                                 "granularity":"TIME"
                              },
                              "noticeSendDate":{
                                 "value":"2017-03-06",
                                 "granularity":"TIME"
                              },
                              "sactioningOrganisation":{
                                 "name":"VDAB",
                                 "code":"VDAB"
                              }
                           },
                           {
                              "type":{
                                 "name":"Niet meegewerkt aan Intake",
                                 "code":"2"
                              },
                              "recordDate":{
                                 "value":"2017-03-03",
                                 "granularity":"TIME"
                              },
                              "noticeSendDate":{
                                 "value":"2017-03-06",
                                 "granularity":"TIME"
                              },
                              "sactioningOrganisation":{
                                 "name":"OCMW",
                                 "code":"OCMW"
                              }
                           },
                           {
                              "type":{
                                 "name":"Niet meegewerkt aan Onderzoek",
                                 "code":"3"
                              },
                              "recordDate":{
                                 "value":"2017-03-03",
                                 "granularity":"TIME"
                              },
                              "noticeSendDate":{
                                 "value":"2017-03-06",
                                 "granularity":"TIME"
                              },
                              "sactioningOrganisation":{
                                 "name":"Vlaamse maatschappij voor sociaal wonen",
                                 "code":"VMSW"
                              }
                           }
                        ]
                     }
                  },
                  "certificates":{
                     "reference":null,
                     "items":[

                     ],
                     "meta":{

                     }
                  },
                  "registrations":{
                     "reference":null,
                     "items":[

                     ],
                     "meta":{
                        "firstRegistration":null
                     }
                  }
               }
            ]
         }
      ]
      // Mark the education events timeline as loaded.
      self.educationEventsTimelineLoaded = true
      // Dress the components using Flanders UI.
      setTimeout(() => { vl.accordion.dressAll() }, 10)
    }, 1000)
  }
}
</script>
