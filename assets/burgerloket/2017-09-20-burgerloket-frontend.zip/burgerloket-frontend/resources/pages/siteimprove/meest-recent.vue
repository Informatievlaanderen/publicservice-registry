<template>
  <div>
    <header class="bl-accent-header js-accent-header" role="banner">
        <bl-layout :mod-is-wide="true">
          <bl-grid>
            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 's'}]">
              <div class="bl-accent-header__content">
                <div data-initials="WB" class="bl-accent-header__badge" />
                <h1 class="bl-accent-header__title">Warre Buysse</h1>
              </div>
            </bl-column>
            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 's'}]">
              <ul class="bl-accent-header__actions">
                <li class="bl-accent-header__actions__item">
                    <nuxt-link to="/siteimprove/wie-heeft-uw-gegevens-geraadpleegd" class="bl-accent-header__actions__item__cta link u-small-text">Wie heeft uw gegevens geraadpleegd</nuxt-link>
                </li>
                </li>
                <li class="bl-accent-header__actions__item">
                  <nuxt-link to="/login" class="bl-accent-header__actions__item__cta link u-small-text">INSZ</nuxt-link>&nbsp;
                  <a href="#" class="bl-accent-header__actions__item__cta link u-small-text" @click.prevent="$store.dispatch('session/logout', true)">Uitloggen</a>
                </li>
              </ul>
            </bl-column>
          </bl-grid>
        </bl-layout>
      <slot></slot>
    </header>
    <nav class="bl-icon-navigation">
      <bl-layout :mod-is-wide="true">
        <bl-grid>
          <bl-column>
            <ul class="bl-icon-navigation__list">
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/meest-recent" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-bell" size="0 0 19 19" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Meest recent</span>
                </nuxt-link>
              </li>
              <li role="separator" aria-hidden="true" class="bl-icon-navigation__separator"></li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/u-en-uw-gezin" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-people" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">U & uw gezin</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/woonst-en-vastgoed" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-house" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Woonst &<br>vastgoed</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <a href="" @click.prevent="" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-car" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Mobiliteit</span>
                </a>
              </li>
              <li class="bl-icon-navigation__item">
                <a href="" @click.prevent="" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-suitcase" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Werk &<br>pensioen</span>
                </a>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/onderwijs" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-hat" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Onderwijs & inburgering</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/belastingen-en-voordelen" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-cash" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Belastingen &<br>voordelen</span>
                </nuxt-link>
              </li>
              <li class="bl-icon-navigation__item">
                <nuxt-link to="/siteimprove/attesten" :class="{ 'bl-icon-navigation__item__cta': true }">
                  <div class="bl-icon-navigation__item__cta__icon-wrapper">
                    <svg role="presentation" class="bl-icon-navigation__item__cta__icon" v-svg symbol="icon-diploma" size="0 0 25 25" aria-hidden="true"></svg>
                  </div>
                  <span class="bl-icon-navigation__item__cta__label">Attesten</span>
                </nuxt-link>
              </li>
            </ul>
          </bl-column>
        </bl-grid>
      </bl-layout>
    </nav>
    <bl-main>
      <bl-region>
        <bl-layout :mod-is-wide="true" class="js-equal-height-container">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
              <bl-h type="h2" class="h2">{{ pageSubtitle }}</bl-h>
            </bl-column>
            <template v-if="!cardsLoaded">
              <bl-column>
                <bl-separator :title="new Date().getFullYear().toString()" />
              </bl-column>
              <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 'm'}, {nom: 1, den: 1, mod: 's'}]" v-for="(pl, index) in cards" :key="index" class="js-preloading">
                <bl-preload-card />
              </bl-column>
            </template>
            <template v-else>
              <template v-if="timeline.length">
                <template v-for="(section, index) in timeline">
                  <bl-column>
                    <bl-separator :title="section.year.toString()" />
                  </bl-column>
                  <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 'm'}, {nom: 1, den: 1, mod: 's'}]" v-for="(card, index) in section.items" :key="card.id">
                    <section :class="{'bl-teaser-card bl-teaser-card--has-user-badge': true, 'js-preloading': !cardsLoaded}">
                      <component :is="!cardsLoaded ? 'div' : 'nuxt-link'" :to="'/siteimprove/meest-recent-detail'" class="bl-teaser-card__cta js-equal-height" data-equal-height="height">
                        <div class="bl-teaser-card__inner">
                          <div class="bl-teaser-card__header">
                            <div class="bl-teaser-card__header__badges">
                              <bl-badge icon="icon-document" :mod-is-accent="true" :mod-is-small="true"></bl-badge>
                            </div>
                            <h1 class="bl-teaser-card__title">
                              <span class="bl-teaser-card__title__label">{{ card.name || null }}</span>
                              <time class="bl-teaser-card__title__timestamp" v-if="card.changed" :datetime="card.changed">
                                {{ $date(card.changed, 'long') }}
                              </time>
                            </h1>
                          </div>
                          <div class="bl-teaser-card__content">
                            <h2 class="bl-teaser-card__subtitle" v-if="card.phase">{{ card.phase.label }}</h2>
                            <div class="bl-teaser-card__description" v-if="card.status">
                              <p>{{ card.status.label }}</p>
                              <p v-if="card.status.requiresAction"><svg role="presentation" v-svg symbol="icon-warning-fill" class="icon icon--color-warning" size="0 0 20 20" aria-hidden="true"></svg> {{ card.status.message }}</p>
                            </div>
                          </div>
                        </div>
                      </component>
                    </section>
                  </bl-column>
                </template>
              </template>
              <template v-else>
                <bl-column>
                  <bl-alert title="Geen lopende zaken">
                    <p>Je bezit momenteel geen lopende zaken.</p>
                  </bl-alert>
                </bl-column>
              </template>
            </template>
          </bl-grid>
        </bl-layout>
      </bl-region>
    </bl-main>
  </div>
</template>

<script>
import BlAlert from '~components/partials/alert/Alert.vue'
import BlAccentHeader from '~components/partials/accent-header/AccentHeader.vue'
import BlIconNavigation from '~components/navigations/icon-navigation/IconNavigation.vue'
import BlSeparator from '~components/partials/separator/Separator.vue'
import BlPreloadCard from '~components/service-components/preload-card/PreloadCard.vue'
import BlBadge from '~components/partials/badge/Badge.vue'

export default {
  components: {
    BlAlert,
    BlAccentHeader,
    BlIconNavigation,
    BlSeparator,
    BlPreloadCard,
    BlBadge
  },
  data () {
    return {
      cards: 2,
      cardsLoaded: false,
      pageSubtitle: 'Meest recent',
      timeline: []
    }
  },
  mounted () {
    const self = this
    setTimeout(() => {
      self.timeline = [
         {
            "year":2016,
            "items":[
               {
                  "id":"2016.82810_Test",
                  "service":"Ahovoks - Studietoelagen",
                  "type":"DossierStatus",
                  "title":"Studietoelage voor het hoger onderwijs",
                  "titleShort":"Studietoelage hoger onderwijs",
                  "reference":"http://productencatalogus.vlaanderen.be/fiche/685",
                  "name":"Dossier studietoelagen 2016 - 2017",
                  "admin":{
                     "name":null,
                     "service":"Afdeling School- en Studietoelagen",
                     "phone":"1700",
                     "email":null,
                     "website":"http://www.studietoelagen.be"
                  },
                  "created":"2017-08-28T15:12:04.723Z",
                  "changed":"2016-09-21T12:51:43.000Z",
                  "granularity":3,
                  "beforeChanged":"Laatste wijziging",
                  "status":{
                     "code":"Beslist",
                     "label":"We hebben een beslissing genomen in jouw dossier.",
                     "requiresAction":false,
                     "message":null
                  },
                  "phase":{
                     "index":5,
                     "code":"Afgerond",
                     "label":"Afgerond"
                  },
                  "phases":[
                     "Samenstelling",
                     "Behandeling",
                     "Beslissing",
                     "Beroep",
                     "Uitvoering",
                     "Afgerond"
                  ],
                  "action":{
                     "required":false,
                     "label":null
                  },
                  "history":[
                     {
                        "Identificatie":{
                           "Bron":"http://ov.vlaanderen.be/studietoelagen/daf",
                           "DossierNummer":"2016.82810_Test"
                        },
                        "OntvangstDatum":"2017-08-28T15:12:04.723Z",
                        "StatusVlaamsCode":{
                           "Bron":"https://test.dosis.vlaanderen.be/api/cl/dosis/v1/codelijsten/StatusVlaamsCode",
                           "Code":"Beslist",
                           "Omschrijving":"Beslist"
                        },
                        "StatusVlaamsFase":{
                           "Bron":"https://test.dosis.vlaanderen.be/api/cl/dosis/v1/codelijsten/StatusVlaamsFase",
                           "Code":"Afgerond",
                           "Omschrijving":"Afgerond"
                        },
                        "StatusEDRL":null,
                        "StatusDetail1":"We hebben een beslissing genomen in jouw dossier.",
                        "StatusDetail2":null,
                        "WijzigingsDatum":"2016-09-21T12:51:43.000Z",
                        "StreefDatum":null,
                        "Actie":{
                           "ActieNodig":false,
                           "Actie":null
                        }
                     },
                     {
                        "Identificatie":{
                           "Bron":"http://ov.vlaanderen.be/studietoelagen/daf",
                           "DossierNummer":"2016.82810_Test"
                        },
                        "OntvangstDatum":"2017-07-05T15:50:16.613Z",
                        "StatusVlaamsCode":{
                           "Bron":"https://test.dosis.vlaanderen.be/api/cl/dosis/v1/codelijsten/StatusVlaamsCode",
                           "Code":"InBehandeling",
                           "Omschrijving":"In Behandeling"
                        },
                        "StatusVlaamsFase":{
                           "Bron":"https://test.dosis.vlaanderen.be/api/cl/dosis/v1/codelijsten/StatusVlaamsFase",
                           "Code":"Behandeling",
                           "Omschrijving":"Behandeling"
                        },
                        "StatusEDRL":null,
                        "StatusDetail1":"We behandelen jouw dossier.",
                        "StatusDetail2":null,
                        "WijzigingsDatum":"2016-09-08T12:51:43.000Z",
                        "StreefDatum":null,
                        "Actie":{
                           "ActieNodig":false,
                           "Actie":null
                        }
                     },
                     {
                        "Identificatie":{
                           "Bron":"http://ov.vlaanderen.be/studietoelagen/daf",
                           "DossierNummer":"2016.82810_Test"
                        },
                        "OntvangstDatum":"2017-07-05T15:50:11.990Z",
                        "StatusVlaamsCode":{
                           "Bron":"https://test.dosis.vlaanderen.be/api/cl/dosis/v1/codelijsten/StatusVlaamsCode",
                           "Code":"DossierOnvolledig",
                           "Omschrijving":"Dossier onvolledig"
                        },
                        "StatusVlaamsFase":{
                           "Bron":"https://test.dosis.vlaanderen.be/api/cl/dosis/v1/codelijsten/StatusVlaamsFase",
                           "Code":"Behandeling",
                           "Omschrijving":"Behandeling"
                        },
                        "StatusEDRL":null,
                        "StatusDetail1":"Wij hebben bijkomende gegevens nodig.",
                        "StatusDetail2":null,
                        "WijzigingsDatum":"2016-08-08T12:51:43.000Z",
                        "StreefDatum":null,
                        "Actie":{
                           "ActieNodig":true,
                           "Actie":"Je zoon of dochter in het Hoger Onderwijs, moet nog een document bezorgen aan de dienst studietoelagen."
                        }
                     }
                  ],
                  "steps":[
                     {
                        "isActive":true,
                        "isCurrent":false,
                        "phase":"Samenstelling",
                        "history":[

                        ]
                     },
                     {
                        "isActive":true,
                        "isCurrent":false,
                        "phase":"Behandeling",
                        "history":[
                           {
                              "Identificatie":{
                                 "Bron":"http://ov.vlaanderen.be/studietoelagen/daf",
                                 "DossierNummer":"2016.82810_Test"
                              },
                              "OntvangstDatum":"2017-07-05T15:50:16.613Z",
                              "StatusVlaamsCode":{
                                 "Bron":"https://test.dosis.vlaanderen.be/api/cl/dosis/v1/codelijsten/StatusVlaamsCode",
                                 "Code":"InBehandeling",
                                 "Omschrijving":"In Behandeling"
                              },
                              "StatusVlaamsFase":{
                                 "Bron":"https://test.dosis.vlaanderen.be/api/cl/dosis/v1/codelijsten/StatusVlaamsFase",
                                 "Code":"Behandeling",
                                 "Omschrijving":"Behandeling"
                              },
                              "StatusEDRL":null,
                              "StatusDetail1":"We behandelen jouw dossier.",
                              "StatusDetail2":null,
                              "WijzigingsDatum":"2016-09-08T12:51:43.000Z",
                              "StreefDatum":null,
                              "Actie":{
                                 "ActieNodig":false,
                                 "Actie":null
                              }
                           },
                           {
                              "Identificatie":{
                                 "Bron":"http://ov.vlaanderen.be/studietoelagen/daf",
                                 "DossierNummer":"2016.82810_Test"
                              },
                              "OntvangstDatum":"2017-07-05T15:50:11.990Z",
                              "StatusVlaamsCode":{
                                 "Bron":"https://test.dosis.vlaanderen.be/api/cl/dosis/v1/codelijsten/StatusVlaamsCode",
                                 "Code":"DossierOnvolledig",
                                 "Omschrijving":"Dossier onvolledig"
                              },
                              "StatusVlaamsFase":{
                                 "Bron":"https://test.dosis.vlaanderen.be/api/cl/dosis/v1/codelijsten/StatusVlaamsFase",
                                 "Code":"Behandeling",
                                 "Omschrijving":"Behandeling"
                              },
                              "StatusEDRL":null,
                              "StatusDetail1":"Wij hebben bijkomende gegevens nodig.",
                              "StatusDetail2":null,
                              "WijzigingsDatum":"2016-08-08T12:51:43.000Z",
                              "StreefDatum":null,
                              "Actie":{
                                 "ActieNodig":true,
                                 "Actie":"Je zoon of dochter in het Hoger Onderwijs, moet nog een document bezorgen aan de dienst studietoelagen."
                              }
                           }
                        ]
                     },
                     {
                        "isActive":true,
                        "isCurrent":false,
                        "phase":"Beslissing",
                        "history":[

                        ]
                     },
                     {
                        "isActive":true,
                        "isCurrent":false,
                        "phase":"Beroep",
                        "history":[

                        ]
                     },
                     {
                        "isActive":true,
                        "isCurrent":false,
                        "phase":"Uitvoering",
                        "history":[

                        ]
                     },
                     {
                        "isActive":true,
                        "isCurrent":true,
                        "phase":"Afgerond",
                        "history":[
                           {
                              "Identificatie":{
                                 "Bron":"http://ov.vlaanderen.be/studietoelagen/daf",
                                 "DossierNummer":"2016.82810_Test"
                              },
                              "OntvangstDatum":"2017-08-28T15:12:04.723Z",
                              "StatusVlaamsCode":{
                                 "Bron":"https://test.dosis.vlaanderen.be/api/cl/dosis/v1/codelijsten/StatusVlaamsCode",
                                 "Code":"Beslist",
                                 "Omschrijving":"Beslist"
                              },
                              "StatusVlaamsFase":{
                                 "Bron":"https://test.dosis.vlaanderen.be/api/cl/dosis/v1/codelijsten/StatusVlaamsFase",
                                 "Code":"Afgerond",
                                 "Omschrijving":"Afgerond"
                              },
                              "StatusEDRL":null,
                              "StatusDetail1":"We hebben een beslissing genomen in jouw dossier.",
                              "StatusDetail2":null,
                              "WijzigingsDatum":"2016-09-21T12:51:43.000Z",
                              "StreefDatum":null,
                              "Actie":{
                                 "ActieNodig":false,
                                 "Actie":null
                              }
                           }
                        ]
                     }
                  ]
               },
               {
                  "id":"2016_83508_Test",
                  "service":"Ahovoks - Studietoelagen",
                  "type":"DossierStatus",
                  "title":"Studietoelage voor het hoger onderwijs",
                  "titleShort":"Studietoelage hoger onderwijs",
                  "reference":"http://productencatalogus.vlaanderen.be/fiche/685",
                  "name":"Dossier studietoelagen 2016 - 2017",
                  "admin":{
                     "name":null,
                     "service":"Afdeling School- en Studietoelagen",
                     "phone":"1700",
                     "email":null,
                     "website":"http://www.studietoelagen.be"
                  },
                  "created":"2017-08-28T15:12:01.863Z",
                  "changed":"2016-08-08T12:51:43.000Z",
                  "granularity":3,
                  "beforeChanged":"Laatste wijziging",
                  "status":{
                     "code":"DossierOnvolledig",
                     "label":"Wij hebben bijkomende gegevens nodig.",
                     "requiresAction":true,
                     "message":"Je moet nog een document bezorgen aan de dienst studietoelagen"
                  },
                  "phase":{
                     "index":1,
                     "code":"Behandeling",
                     "label":"Behandeling"
                  },
                  "phases":[
                     "Samenstelling",
                     "Behandeling",
                     "Beslissing",
                     "Beroep",
                     "Uitvoering",
                     "Afgerond"
                  ],
                  "action":{
                     "required":true,
                     "label":"Je moet nog een document bezorgen aan de dienst studietoelagen"
                  },
                  "history":[
                     {
                        "Identificatie":{
                           "Bron":"http://ov.vlaanderen.be/studietoelagen/daf",
                           "DossierNummer":"2016_83508_Test"
                        },
                        "OntvangstDatum":"2017-08-28T15:12:01.863Z",
                        "StatusVlaamsCode":{
                           "Bron":"https://test.dosis.vlaanderen.be/api/cl/dosis/v1/codelijsten/StatusVlaamsCode",
                           "Code":"DossierOnvolledig",
                           "Omschrijving":"Dossier onvolledig"
                        },
                        "StatusVlaamsFase":{
                           "Bron":"https://test.dosis.vlaanderen.be/api/cl/dosis/v1/codelijsten/StatusVlaamsFase",
                           "Code":"Behandeling",
                           "Omschrijving":"Behandeling"
                        },
                        "StatusEDRL":null,
                        "StatusDetail1":"Wij hebben bijkomende gegevens nodig.",
                        "StatusDetail2":null,
                        "WijzigingsDatum":"2016-08-08T12:51:43.000Z",
                        "StreefDatum":null,
                        "Actie":{
                           "ActieNodig":true,
                           "Actie":"Je moet nog een document bezorgen aan de dienst studietoelagen"
                        }
                     }
                  ],
                  "steps":[
                     {
                        "isActive":true,
                        "isCurrent":false,
                        "phase":"Samenstelling",
                        "history":[

                        ]
                     },
                     {
                        "isActive":true,
                        "isCurrent":true,
                        "phase":"Behandeling",
                        "history":[
                           {
                              "Identificatie":{
                                 "Bron":"http://ov.vlaanderen.be/studietoelagen/daf",
                                 "DossierNummer":"2016_83508_Test"
                              },
                              "OntvangstDatum":"2017-08-28T15:12:01.863Z",
                              "StatusVlaamsCode":{
                                 "Bron":"https://test.dosis.vlaanderen.be/api/cl/dosis/v1/codelijsten/StatusVlaamsCode",
                                 "Code":"DossierOnvolledig",
                                 "Omschrijving":"Dossier onvolledig"
                              },
                              "StatusVlaamsFase":{
                                 "Bron":"https://test.dosis.vlaanderen.be/api/cl/dosis/v1/codelijsten/StatusVlaamsFase",
                                 "Code":"Behandeling",
                                 "Omschrijving":"Behandeling"
                              },
                              "StatusEDRL":null,
                              "StatusDetail1":"Wij hebben bijkomende gegevens nodig.",
                              "StatusDetail2":null,
                              "WijzigingsDatum":"2016-08-08T12:51:43.000Z",
                              "StreefDatum":null,
                              "Actie":{
                                 "ActieNodig":true,
                                 "Actie":"Je moet nog een document bezorgen aan de dienst studietoelagen"
                              }
                           }
                        ]
                     },
                     {
                        "isActive":false,
                        "isCurrent":false,
                        "phase":"Beslissing",
                        "history":[

                        ]
                     },
                     {
                        "isActive":false,
                        "isCurrent":false,
                        "phase":"Beroep",
                        "history":[

                        ]
                     },
                     {
                        "isActive":false,
                        "isCurrent":false,
                        "phase":"Uitvoering",
                        "history":[

                        ]
                     },
                     {
                        "isActive":false,
                        "isCurrent":false,
                        "phase":"Afgerond",
                        "history":[

                        ]
                     }
                  ]
               }
            ]
         },
         {
            "year":2015,
            "items":[
               {
                  "id":"2015_83508_Test",
                  "service":"Ahovoks - Studietoelagen",
                  "type":"DossierStatus",
                  "title":"Studietoelage voor het hoger onderwijs",
                  "titleShort":"Studietoelage hoger onderwijs",
                  "reference":"http://productencatalogus.vlaanderen.be/fiche/685",
                  "name":"Dossier studietoelagen 2015 - 2016",
                  "admin":{
                     "name":null,
                     "service":"Afdeling School- en Studietoelagen",
                     "phone":"1700",
                     "email":null,
                     "website":"http://www.studietoelagen.be"
                  },
                  "created":"2017-08-28T15:12:05.510Z",
                  "changed":"2015-07-07T12:00:11.000Z",
                  "granularity":3,
                  "beforeChanged":"Laatste wijziging",
                  "status":{
                     "code":"Beslist",
                     "label":"We hebben een beslissing genomen in jouw dossier.",
                     "requiresAction":false,
                     "message":null
                  },
                  "phase":{
                     "index":5,
                     "code":"Afgerond",
                     "label":"Afgerond"
                  },
                  "phases":[
                     "Samenstelling",
                     "Behandeling",
                     "Beslissing",
                     "Beroep",
                     "Uitvoering",
                     "Afgerond"
                  ],
                  "action":{
                     "required":false,
                     "label":null
                  },
                  "history":[
                     {
                        "Identificatie":{
                           "Bron":"http://ov.vlaanderen.be/studietoelagen/daf",
                           "DossierNummer":"2015_83508_Test"
                        },
                        "OntvangstDatum":"2017-08-28T15:12:05.510Z",
                        "StatusVlaamsCode":{
                           "Bron":"https://test.dosis.vlaanderen.be/api/cl/dosis/v1/codelijsten/StatusVlaamsCode",
                           "Code":"Beslist",
                           "Omschrijving":"Beslist"
                        },
                        "StatusVlaamsFase":{
                           "Bron":"https://test.dosis.vlaanderen.be/api/cl/dosis/v1/codelijsten/StatusVlaamsFase",
                           "Code":"Afgerond",
                           "Omschrijving":"Afgerond"
                        },
                        "StatusEDRL":null,
                        "StatusDetail1":"We hebben een beslissing genomen in jouw dossier.",
                        "StatusDetail2":null,
                        "WijzigingsDatum":"2015-07-07T12:00:11.000Z",
                        "StreefDatum":null,
                        "Actie":{
                           "ActieNodig":false,
                           "Actie":null
                        }
                     }
                  ],
                  "steps":[
                     {
                        "isActive":true,
                        "isCurrent":false,
                        "phase":"Samenstelling",
                        "history":[

                        ]
                     },
                     {
                        "isActive":true,
                        "isCurrent":false,
                        "phase":"Behandeling",
                        "history":[

                        ]
                     },
                     {
                        "isActive":true,
                        "isCurrent":false,
                        "phase":"Beslissing",
                        "history":[

                        ]
                     },
                     {
                        "isActive":true,
                        "isCurrent":false,
                        "phase":"Beroep",
                        "history":[

                        ]
                     },
                     {
                        "isActive":true,
                        "isCurrent":false,
                        "phase":"Uitvoering",
                        "history":[

                        ]
                     },
                     {
                        "isActive":true,
                        "isCurrent":true,
                        "phase":"Afgerond",
                        "history":[
                           {
                              "Identificatie":{
                                 "Bron":"http://ov.vlaanderen.be/studietoelagen/daf",
                                 "DossierNummer":"2015_83508_Test"
                              },
                              "OntvangstDatum":"2017-08-28T15:12:05.510Z",
                              "StatusVlaamsCode":{
                                 "Bron":"https://test.dosis.vlaanderen.be/api/cl/dosis/v1/codelijsten/StatusVlaamsCode",
                                 "Code":"Beslist",
                                 "Omschrijving":"Beslist"
                              },
                              "StatusVlaamsFase":{
                                 "Bron":"https://test.dosis.vlaanderen.be/api/cl/dosis/v1/codelijsten/StatusVlaamsFase",
                                 "Code":"Afgerond",
                                 "Omschrijving":"Afgerond"
                              },
                              "StatusEDRL":null,
                              "StatusDetail1":"We hebben een beslissing genomen in jouw dossier.",
                              "StatusDetail2":null,
                              "WijzigingsDatum":"2015-07-07T12:00:11.000Z",
                              "StreefDatum":null,
                              "Actie":{
                                 "ActieNodig":false,
                                 "Actie":null
                              }
                           }
                        ]
                     }
                  ]
               }
            ]
         }
      ]
      self.cardsLoaded = true
      setTimeout(() => {
          vl.drawer.dressAll()
          vl.equalheight.resize()
      }, 10)
    }, 1000)
  }
}
</script>
