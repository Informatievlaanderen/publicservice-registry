<template>
  <div>
    <bl-content-header :title="pageTitle" />
    <bl-main>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
              <bl-h type="h2" class="h2">Beta login systeem (demo purposes)</bl-h>
              <bl-typography>
                <p>U bent ingelogd.</p>
              </bl-typography>
            </bl-column>
          </bl-grid>
        </bl-layout>
      </bl-region>
    </bl-main>
  </div>
</template>

<script>

import BlContentHeader from '~components/partials/content-header/ContentHeader.vue'

export default {
  components: {
    BlContentHeader
  },
  data () {
    return {
      pageTitle: 'Burgerloket'
    }
  },
  mounted () {
    if (hasClass(document.body, 'body--has-modal')) {
      removeClass(document.body, 'body--has-modal')
    }
  }
}
</script>
