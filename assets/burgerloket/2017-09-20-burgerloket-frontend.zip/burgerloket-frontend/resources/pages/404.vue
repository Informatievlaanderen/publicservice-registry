<template>
  <div>
    <bl-content-header :data="{ title: pageTitle }" />
    <bl-main>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
              <bl-h type="h2" class="h2">{{ errorCode }} - Pagina niet gevonden</bl-h>
              <bl-typography>
                <p>De gevraagde pagina is niet gevonden. De pagina bestaat niet (meer) of is verplaatst. <nuxt-link to="/">Ga naar de homepage</nuxt-link>.</p>
              </bl-typography>
            </bl-column>
          </bl-grid>
        </bl-layout>
      </bl-region>
    </bl-main>
  </div>
</template>

<script>

import BlContentHeader from '~components/partials/content-header/ContentHeader.vue'

export default {
  components: {
    BlContentHeader
  },
  data () {
    return {
      pageTitle: 'Burgerloket',
      errorCode: '404'
    }
  }
}
</script>
