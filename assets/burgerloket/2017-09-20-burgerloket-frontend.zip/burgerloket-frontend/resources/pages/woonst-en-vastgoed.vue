<template>
  <div>
    <bl-accent-header />
    <bl-icon-navigation />
    <bl-main>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
              <bl-h type="h2" class="h2">{{ residenceSubtitle }}</bl-h>
              <div class="u-spacer"></div>
            </bl-column>
          </bl-grid>
        </bl-layout>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">

            <!-- Service works -->
            <template v-if="!$store.getters['accommodation/residenceFailed']">
              <!-- Preload -->
              <bl-column v-if="residenceLoading">
                <bl-preload-card :mod-has-content="false" />
              </bl-column>
              <!-- ./ Preload -->
              <!-- Loaded & data -->
              <bl-column v-if="residenceLoaded && residence">
                <bl-panel>
                  <bl-panel-header :title="(residence.address ? formatAddress(residence.address) : '')" :badges="[{ icon: 'icon-pin', modIsAlt: true }]" :subtitle="residencePanelSubtitle(residence)" :extra="[(residence.isChanging ? { label: 'U hebt een adreswijziging doorgegeven' } : '')]" />
                </bl-panel>
              </bl-column>
               <!-- ./ Loaded & data -->
               <!-- Loaded & empty -->
              <template v-if="residenceLoaded && !residence">
                <bl-column>
                  <bl-alert title="Geen gegevens beschikbaar">
                    <p>Er zijn op dit moment geen gegevens beschikbaar.</p>
                  </bl-alert>
                </bl-column>
              </template>
              <!-- ./ Loaded & empty -->
            </template>
            <!-- ./ Service works -->
            <!-- Service failed -->
            <template v-else>
              <bl-column>
                <bl-alert type="error" title="Geen verbinding">
                  <bl-typography>
                    <p>Er kan op dit moment geen verbinding gemaakt worden waardoor we hier uw opvragingen niet kunnen tonen. Van zodra het probleem is opgelost, vind u hier een overzicht van uw geraadpleegde gegevens.</p>
                  </bl-typography>
                </bl-alert>
              </bl-column>
            </template>
            <!-- ./ Service failed -->
          </bl-grid>
        </bl-layout>
      </bl-region>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column>
              <bl-h type="h2" class="h2">Eigendom<template v-if="propertiesLoaded && properties.length > 1">men</template>&nbsp;<span class="title-sublink__sub" v-if="propertiesLoaded && properties.length">({{ properties.length }})</span></bl-h>
              <div class="u-spacer"></div>
            </bl-column>

            <!-- Service works -->
            <template v-if="!$store.getters['accommodation/propertyFailed']">
              <!-- Preload -->
              <bl-column v-if="propertiesLoading">
                <bl-preload-card />
              </bl-column>
              <!-- ./ Preload -->
              <!-- Loaded & data -->
              <bl-column v-if="property && property.address" v-for="(property, index) in properties" :key="index">
                <bl-panel>
                  <bl-panel-header :title="(property.address ? formatAddress(property.address) : '')" :subtitle="propertyPanelSubtitle(property)" :extra="propertyPanelExtra(property)" :badges="[{ icon: propertyIcon(property), modIsAlt: true }]" />
                  <bl-panel-body>
                    <template slot="content">
                      <bl-description-data>
                        <bl-grid :mod-is-stacked="true">
                          <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                            <bl-description-data-item-wrapper v-if="property.ownership && property.ownership.length">
                              <bl-description-data-item class-type="subdata">Eigendom</bl-description-data-item>
                              <template v-for="(item, index) in property.ownership">
                                <bl-description-data-item class-type="data" v-if="item.type">{{ item.type }}</bl-description-data-item>
                                <template v-for="(right, index) in item.rights">
                                  <bl-description-data-item class-type="data"><template v-if="right.shares && right.shares.owned">{{ right.shares.owned }} aandeel</template><template v-if="right.shares && right.shares.total"> van {{ right.shares.total }}</template><template v-if="right.type"> in {{ right.type.toLowerCase() }}</template></bl-description-data-item>
                                  <bl-description-data-item class-type="subdata" v-if="right.expires">tot <time :datetime="right.expires.value">{{ $date(right.expires) }}</time></bl-description-data-item>
                                </template>
                                <br>
                                <bl-description-data-item class-type="data">
                                  <template v-if="property.coOwners">{{ property.coOwners }} mede-eigenaars</template>
                                  <template v-else>U bent de enige eigenaar</template>
                                </bl-description-data-item>
                              </template>
                            </bl-description-data-item-wrapper>
                          </bl-column>
                          <bl-column :cols="[{nom: 2, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                            <bl-grid>
                              <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
                                <bl-description-data-item-wrapper v-if="property.cadastralIncome">
                                  <bl-description-data-item class-type="subdata">Belastbaar kadastraal inkomen (KI)</bl-description-data-item>
                                  <bl-description-data-item class-type="data" v-if="property.cadastralIncome.amount">{{ property.cadastralIncome.amount }} €</bl-description-data-item>
                                  <bl-description-data-item class-type="subdata" v-if="property.cadastralIncome.end">Einde vrijstelling: <time :datetime="property.cadastralIncome.end.value">{{ $date(property.cadastralIncome.end) }}</time></bl-description-data-item>
                                </bl-description-data-item-wrapper>
                              </bl-column>
                              <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
                                <bl-description-data-item-wrapper v-if="property.administration">
                                  <bl-description-data-item class-type="subdata">Administratieve gemeente</bl-description-data-item>
                                  <bl-description-data-item class-type="data" v-if="property.administration.city && property.administration.city.name">{{ property.administration.city.name }}</bl-description-data-item>
                                </bl-description-data-item-wrapper>
                              </bl-column>
                              <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
                                <bl-description-data-item-wrapper v-if="property.yearOfConstruction && (!property.plots || !property.plots.length)">
                                  <bl-description-data-item class-type="subdata">Bouwjaar</bl-description-data-item>
                                  <bl-description-data-item class-type="data">{{ property.yearOfConstruction.code }}</bl-description-data-item>
                                </bl-description-data-item-wrapper>
                              </bl-column>
                            </bl-grid>
                          </bl-column>
                        </bl-grid>
                        <template v-if="property.plots && property.plots.length">
                          <div class="u-spacer--large"></div>
                          <bl-grid class="js-equal-height-container" :mod-is-stacked="true">
                            <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]" v-for="(plot, index) in property.plots" :key="index">
                              <bl-description-data-item-wrapper :mod-is-alt="true" class="js-equal-height">
                                <bl-description-data-item class-type="subdata">
                                  <template v-if="property.type === 'building'">
                                  Gebouw {{ index + 1 }}
                                  </template>
                                  <template v-else-if="property.type === 'vacant'">
                                  Grond {{ index + 1 }}
                                  </template>
                                </bl-description-data-item>
                                <bl-description-data-item class-type="data" v-if="plot.address">{{ formatAddress(plot.address) }}</bl-description-data-item>
                                <bl-description-data-item class-type="data" v-if="plot.yearOfConstruction">Bouwjaar: {{ plot.yearOfConstruction }}</bl-description-data-item>
                              </bl-description-data-item-wrapper>
                            </bl-column>
                          </bl-grid>
                        </template>
                      </bl-description-data>
                    </template>
                  </bl-panel-body>
                </bl-panel>
              </bl-column>
              <!-- ./ Loaded & data -->
              <!-- Loaded & empty -->
              <template v-if="propertiesLoaded && !properties.length">
                <bl-column>
                  <bl-panel>
                    <bl-panel-header title="Geen eigendom gevonden" :badges="[{ modIsPlaceholder: true }]" />
                    <bl-panel-body>
                      <template slot="content">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec ullamcorper scelerisque blandit. Aliquam id egestas felis. Aenean efficitur quis lorem sed faucibus. Vestibulum finibus, lacus ut pretium placerat, nisi lectus malesuada eros, at bibendum ligula augue nec sapien. Cras faucibus nisl erat, ut placerat risus facilisis quis.</p>
                      </template>
                    </bl-panel-body>
                  </bl-panel>
                </bl-column>
              </template>
              <!-- ./ Loaded & empty -->
            </template>
            <!-- ./ Service works -->
            <!-- Service failed -->
            <template v-else>
              <bl-column>
                <bl-alert type="error" title="Geen verbinding">
                  <bl-typography>
                    <p>Er kan op dit moment geen verbinding gemaakt worden waardoor we hier uw opvragingen niet kunnen tonen. Van zodra het probleem is opgelost, vind u hier een overzicht van uw geraadpleegde gegevens.</p>
                  </bl-typography>
                </bl-alert>
              </bl-column>
            </template>
            <!-- ./ Service failed -->




            <!--
            <bl-column>
              <bl-panel>
                <bl-panel-header title="Begijnenstraat 39, 2800 Mechelen" subtitle="Bebouwd | U woonde hier op 01.01.2017" :extra="[{ label: 'Kadastrale afdeling: Mechelen 1' }, { label: 'Kadastrale aanduiding: A/144L/P0000' }]" :badges="[{ icon: 'icon-property-built', modIsAlt: true }]" />
                <bl-panel-body>
                  <template slot="content">
                    <bl-description-data>
                      <bl-grid :mod-is-stacked="true">
                        <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                          <bl-description-data-item-wrapper>
                            <bl-description-data-item class-type="subdata">Eigendom</bl-description-data-item>
                            <bl-description-data-item class-type="data">Natuurlijk persoon</bl-description-data-item>
                            <bl-description-data-item class-type="data">1 aandeel van 2 in volle eigendom</bl-description-data-item><br>
                            <bl-description-data-item class-type="data">U bent de enige eigenaar</bl-description-data-item>
                          </bl-description-data-item-wrapper>
                        </bl-column>
                        <bl-column :cols="[{nom: 2, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                          <bl-grid>
                            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
                              <bl-description-data-item-wrapper>
                                <bl-description-data-item class-type="subdata">Belastbaar kadastraal inkomen (KI)</bl-description-data-item>
                                <bl-description-data-item class-type="data">1.100 €</bl-description-data-item>
                              </bl-description-data-item-wrapper>
                            </bl-column>
                            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
                              <bl-description-data-item-wrapper>
                                <bl-description-data-item class-type="subdata">Administratieve gemeente</bl-description-data-item>
                                <bl-description-data-item class-type="data">Mechelen</bl-description-data-item>
                              </bl-description-data-item-wrapper>
                            </bl-column>
                            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
                              <bl-description-data-item-wrapper>
                                <bl-description-data-item class-type="subdata">Bouwjaar</bl-description-data-item>
                                <bl-description-data-item class-type="data">2001</bl-description-data-item>
                              </bl-description-data-item-wrapper>
                            </bl-column>
                          </bl-grid>
                        </bl-column>
                      </bl-grid>
                    </bl-description-data>
                  </template>
                </bl-panel-body>
              </bl-panel>
            </bl-column>

            <bl-column>
              <bl-panel>
                <bl-panel-header title="Lechten het gehucht, Bocholt" subtitle="Onbebouwd | Dichtsbijzijnde adres: Grote Steenweg 132, 3950 Bocholt" :extra="[{ label: 'Kadastrale afdeling: Mechelen 1' }, { label: 'Kadastrale aanduiding: A/144L/P0000' }]" :badges="[{ icon: 'icon-property-unbuilt', modIsAlt: true }]" />
                <bl-panel-body>
                  <template slot="content">
                    <bl-description-data>
                      <bl-grid :mod-is-stacked="true">
                        <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                          <bl-description-data-item-wrapper>
                            <bl-description-data-item class-type="subdata">Eigendom</bl-description-data-item>
                            <bl-description-data-item class-type="data">In gemeenschap</bl-description-data-item>
                            <bl-description-data-item class-type="data">Volle eigendom</bl-description-data-item><br>
                            <bl-description-data-item class-type="data">3 mede-eigenaars</bl-description-data-item>
                          </bl-description-data-item-wrapper>
                        </bl-column>
                        <bl-column :cols="[{nom: 2, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                          <bl-grid>
                            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
                              <bl-description-data-item-wrapper>
                                <bl-description-data-item class-type="subdata">Belastbaar kadastraal inkomen (KI)</bl-description-data-item>
                                <bl-description-data-item class-type="data">1.100 €</bl-description-data-item>
                              </bl-description-data-item-wrapper>
                            </bl-column>
                            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
                              <bl-description-data-item-wrapper>
                                <bl-description-data-item class-type="subdata">Administratieve gemeente</bl-description-data-item>
                                <bl-description-data-item class-type="data">Bocholt</bl-description-data-item>
                              </bl-description-data-item-wrapper>
                            </bl-column>
                          </bl-grid>
                        </bl-column>
                      </bl-grid>
                    </bl-description-data>
                  </template>
                </bl-panel-body>
              </bl-panel>
            </bl-column>

            <bl-column>
              <bl-panel>
                <bl-panel-header title="Antwerpsesteenweg 89, 9000 Gent" :badges="[{ icon: 'icon-property-unknown', modIsAlt: true }]" />
                <bl-panel-body>
                  <template slot="content">
                    <bl-description-data>
                      <bl-grid :mod-is-stacked="true">
                        <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                          <bl-description-data-item-wrapper>
                            <bl-description-data-item class-type="subdata">Eigendom</bl-description-data-item>
                            <bl-description-data-item class-type="data">In gemeenschap</bl-description-data-item>
                            <bl-description-data-item class-type="data">1 aandeel van 2 in volle eigendom</bl-description-data-item><br>
                            <bl-description-data-item class-type="data">2 mede-eigenaars</bl-description-data-item>
                          </bl-description-data-item-wrapper>
                        </bl-column>
                        <bl-column :cols="[{nom: 2, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                          <bl-grid>
                            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
                              <bl-description-data-item-wrapper>
                                <bl-description-data-item class-type="subdata">Belastbaar kadastraal inkomen (KI)</bl-description-data-item>
                                <bl-description-data-item class-type="data">1.100 €</bl-description-data-item>
                              </bl-description-data-item-wrapper>
                            </bl-column>
                            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
                              <bl-description-data-item-wrapper>
                                <bl-description-data-item class-type="subdata">Administratieve gemeente</bl-description-data-item>
                                <bl-description-data-item class-type="data">Gent</bl-description-data-item>
                              </bl-description-data-item-wrapper>
                            </bl-column>
                            <bl-column :cols="[{nom: 1, den: 2}, {nom: 1, den: 1, mod: 'xs'}]">
                              <bl-description-data-item-wrapper>
                                <bl-description-data-item class-type="subdata">Bouwjaar</bl-description-data-item>
                                <bl-description-data-item class-type="data">van 1910 tot 1917</bl-description-data-item>
                              </bl-description-data-item-wrapper>
                            </bl-column>
                          </bl-grid>
                        </bl-column>
                      </bl-grid>
                    </bl-description-data>
                  </template>
                </bl-panel-body>
              </bl-panel>
            </bl-column>
            -->


          </bl-grid>
        </bl-layout>
      </bl-region>
    </bl-main>
  </div>
</template>

<script>

import { mapGetters } from 'vuex'

import BlAlert from '~components/partials/alert/Alert.vue'
import BlAccentHeader from '~components/partials/accent-header/AccentHeader.vue'
import BlIconNavigation from '~components/navigations/icon-navigation/IconNavigation.vue'
import BlPreloadCard from '~components/service-components/preload-card/PreloadCard.vue'
import BlPanel from '~components/partials/panel/Panel.vue'
import BlPanelHeader from '~components/partials/panel/panel-header/PanelHeader.vue'
import BlPanelBody from '~components/partials/panel/panel-body/PanelBody.vue'
import BlPanelBodyAccordion from '~components/partials/panel/panel-body/PanelBodyAccordion.vue'
import BlDescriptionData from '~components/partials/description-data/DescriptionData.vue'
import BlDescriptionDataItem from '~components/partials/description-data/DescriptionDataItem.vue'
import BlDescriptionDataItemWrapper from '~components/partials/description-data/DescriptionDataItemWrapper.vue'

export default {
  middleware: ['authenticated'],
  components: {
    BlAlert,
    BlAccentHeader,
    BlIconNavigation,
    BlPreloadCard,
    BlPanel,
    BlPanelHeader,
    BlPanelBody,
    BlPanelBodyAccordion,
    BlDescriptionData,
    BlDescriptionDataItem,
    BlDescriptionDataItemWrapper
  },
  data () {
    return {
      pageTitle: 'Uw gegevens bij de overheid',
      pageSubtitle: 'Woonst & vastgoed',
      residenceSubtitle: 'Hoofdverblijfplaats',
      preloadCards: 3,
      showLoader: false
    }
  },
  methods: {
    formatAddress (address) {
      return (address ? (address.location ? address.location : (address.street ? (address.street.name ? address.street.name + (address.street.number ? ' ' + address.street.number + (address.street.box ? ' ' + address.street.box : '') : '') : '') : '') + (address.city ? (address.street && address.street.name && (address.city.code || address.city.name) ? ', ' : '') + (address.city.code ? address.city.code + ' ' : '') + (address.city.name ? address.city.name : '') : '')) + (address.country && address.country.name && address.country.code && address.country.code !== 'BE' ? ', ' + address.country.name : '') : '')
    },
    residencePanelSubtitle (residence) {
      var subtitleParts = []
      if (residence.isReference) subtitleParts.push('Dit is het referentie-adres')
      if (residence.isAbsent) subtitleParts.push('U bent tijdelijk afwezig')
      if (residence.isForeign && residence.diplomaticPost) subtitleParts.push('Diplomatieke post: ' + this.formatAddress(residence.diplomaticPost))
      if (residence.isForeign && residence.postAddress && residence.postAddress.location) subtitleParts.push('Postadres: ' + residence.postAddress.location + (residence.postAddress.country && residence.postAddress.country.name && residence.postAddress.country.code && residence.postAddress.country.code !== 'BE' ? ', ' + residence.postAddress.country.name : ''))
      return subtitleParts.join(' | ')
    },
    propertyPanelSubtitle (property) {
      var subtitleParts = []
      if (property.type === 'building') subtitleParts.push('Bebouwd')
      if (property.type === 'vacant') subtitleParts.push('Onbebouwd')
      if (property.since) subtitleParts.push('U woonde hier op ' + this.$date(property.since))
      return subtitleParts.join(' | ')
    },
    propertyPanelExtra (property) {
      var extraParts = []
      if (property.cadastre && property.cadastre.department) extraParts.push({label: 'Kadastrale afdeling: ' + property.cadastre.department})
      if (property.cadastre && property.cadastre.lot && property.cadastre.partition && property.cadastre.section) extraParts.push({label: 'Kadastrale aanduiding: ' + property.cadastre.section + '/' + property.cadastre.lot + '/' + property.cadastre.partition})
      return extraParts
    },
    propertyIcon (property) {
      if (property.type === 'building') return 'icon-property-built'
      else if (property.type === 'vacant') return 'icon-property-unbuilt'
      else return 'icon-property-unknown'
    }
  },
  computed: {
    ...mapGetters({
      residence: 'accommodation/residence',
      residenceLoaded: 'accommodation/residenceResolved',
      properties: 'accommodation/property',
      propertiesLoaded: 'accommodation/propertyResolved'
    }),
    residenceLoading () {
      const resolved = this.$store.getters['accommodation/residenceResolved']
      const failed = this.$store.getters['accommodation/residenceFailed']
      return !resolved && !failed
    },
    propertiesLoading () {
      const resolved = this.$store.getters['accommodation/propertyResolved']
      const failed = this.$store.getters['accommodation/propertyFailed']
      return !resolved && !failed
    }
  },
  mounted () {
    // Get a reference to ourself.
    const self = this
    // Resolve the residence.
    self.$store.dispatch('accommodation/residence')
    // Resolve the property.
    self.$store.dispatch('accommodation/property').then(() => {
      // equal height
      setTimeout(() => { vl.equalheight.resize() }, 10)
    })
  }
}
</script>
