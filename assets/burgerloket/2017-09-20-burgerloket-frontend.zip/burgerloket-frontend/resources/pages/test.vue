<template>
  <bl-region>
    <bl-layout :mod-is-wide="true">
      <bl-grid :mod-is-stacked="true">
        <bl-column>
          <bl-panel :mod-is-alt="true">
            <bl-panel-header :mod-has-info-toggle="true" title="Dit is de titel van de panel header" subtitle="En dit is de subtitel" :badges="[{ icon: 'icon-house' }, { modIsSuccess: true, modIsOverlap: true, icon: 'icon-document-certificate' }]" :extra="[{ label: 'jos@jos.be' }, { label: '0497 07 21 24' }]" />
          </bl-panel>
        </bl-column>
        <bl-column>
          <bl-panel>
            <bl-panel-header title="Dit is de titel van de panel header" subtitle="En dit is de subtitel" />
          </bl-panel>
        </bl-column>
        <bl-column>
          <bl-panel :mod-is-alt="true">
            <bl-panel-header title="Dit is de titel van de panel header" subtitle="En dit is de subtitel" />
          </bl-panel>
        </bl-column>
        <bl-column>
          <bl-panel>
            <bl-panel-header title="Dit is de titel van de panel header" />
          </bl-panel>
        </bl-column>
        <bl-column>
          <bl-panel :mod-is-alt="true">
            <bl-panel-header :mod-has-info-toggle="true" title="Dit is de titel van de panel header" subtitle="En dit is de subtitel" :badges="[{ icon: 'icon-house' }]" />
          </bl-panel>
        </bl-column>
        <bl-column>
          <bl-panel :mod-is-alt="true">
            <bl-panel-header title="Dit is de titel van de panel header" :badges="[{ icon: 'icon-house' }]" />
          </bl-panel>
        </bl-column>
        <bl-column>
          <bl-panel :mod-is-accordion="true" :mod-is-alt="true">
            <bl-panel-header :mod-is-accordion="true" type="button" title="Dit is de titel van de panel header" subtitle="En dit is de subtitel" :extra="[{ label: 'jos@jos.be' }, { label: '0497 07 21 24' }]" />
            <bl-panel-body :mod-is-accordion="true">
              <template slot="content">
                <bl-description-data>
                  <bl-grid :mod-is-stacked="true">
                    <bl-column :cols="[{nom: 1, den: 3}, {nom: 1, den: 2, mod: 's'}, {nom: 1, den: 1, mod: 'xs'}]">
                        <bl-description-data-item-wrapper :mod-is-bordered="true">
                          <bl-description-data-item class-type="subdata">Lorem</bl-description-data-item>
                          <bl-description-data-item class-type="data">Ipsum</bl-description-data-item>
                        </bl-description-data-item-wrapper>
                    </bl-column>
                  </bl-grid>
                </bl-description-data>
              </template>
              <template slot="accordions">
                <bl-panel-body-accordion v-for="(accordion, index) in accordions" :key="index" :data="accordion" @accordion-was-clicked="accordion.open = !accordion.open">
                  <p>Lorem ipsum dolor sit amet.</p>
                </bl-panel-body-accordion>
              </template>
              <template slot="footer">
                <a href="#" class="link--icon--external" target="_BLANK">Externe link</a>
                <!-- <p class="bl-panel__body__footer__meta">3 opvragingen | <time>08/11/1991</time></p> -->
              </template>
            </bl-panel-body>
          </bl-panel>
        </bl-column>
      </bl-grid>
    </bl-layout>
  </bl-region>
</template>

<script>

import BlPanel from '~components/partials/panel/Panel.vue'
import BlPanelHeader from '~components/partials/panel/panel-header/PanelHeader.vue'
import BlPanelBody from '~components/partials/panel/panel-body/PanelBody.vue'
import BlPanelBodyAccordion from '~components/partials/panel/panel-body/PanelBodyAccordion.vue'
import BlDescriptionData from '~components/partials/description-data/DescriptionData.vue'
import BlDescriptionDataItem from '~components/partials/description-data/DescriptionDataItem.vue'
import BlDescriptionDataItemWrapper from '~components/partials/description-data/DescriptionDataItemWrapper.vue'
import BlBadge from '~components/partials/badge/Badge.vue'

export default {
  i18: {
    messages: {
      en: {
        hello: 'Hello World'
      }
    }
  },
  components: {
    BlPanel,
    BlPanelHeader,
    BlPanelBody,
    BlPanelBodyAccordion,
    BlDescriptionData,
    BlDescriptionDataItem,
    BlDescriptionDataItemWrapper,
    BlBadge
  },
  data () {
    return {
      accordions: [
        { id: 1, open: true, toggle: 'Traject' },
        { id: 2, open: true, toggle: 'Opmerking' }
      ]
    }
  }
}
</script>

<style lang="scss" scoped>
  $color: orange;
  .test {
    background-color: $color
  }
</style>
