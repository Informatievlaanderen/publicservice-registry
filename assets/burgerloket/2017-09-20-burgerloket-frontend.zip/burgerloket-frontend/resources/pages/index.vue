<template>
  <div>
    <bl-content-header :data="{ title: pageTitle }" />
    <bl-main>
      <bl-region>
        <bl-layout :mod-is-wide="true">
          <bl-grid :mod-is-stacked="true">
            <bl-column :cols="[{nom: 8, den: 12}, {nom: 1, den: 1, mod: 's'}]" class="u-spacer">
              <bl-h type="h2" class="h2">Een overheid die je beter begrijpt</bl-h>
              <bl-typography>
                <p>Met de Vlaamse overheid streven we naar een overheid die je beter begrijpt. Daarom kan je vanaf nu zien wat de overheid precies over jou weet, welke overheidsinstanties jouw gegevens hebben geraadpleegd en waarom. Maar je kan ook op elk moment de status van bijvoorbeeld jouw premie- of studietoelage-aanvraag bekijken. We hebben al deze gegevens voor jou samengebracht op jouw persoonlijke pagina. Je hoeft enkel nog aan te melden.</p>
              </bl-typography>
            </bl-column>
            <bl-column :cols="[{nom: 4, den: 12}, {nom: 1, den: 1, mod: 's'}]" class="u-spacer">
              <div class="u-align-center" style="background: #e8ebee">
                <br>
                <i class="vi vi-id" aria-hidden style="font-size: 6rem; color: #cbd2da"></i>
                <br>
                <bl-h type="h3" class="h5">Mijn gegevens bij de overheid</bl-h>
                <br>
                <a href="#" @click.prevent="$store.dispatch('session/login', '/login')" class="button">Aanmelden</a>
                <br>
                <br>
              </div>
            </bl-column>
            <bl-column :cols="[{nom: 4, den: 12}, {nom: 1, den: 1, mod: 's'}]" class="u-spacer">
              <img src="https://placehold.it/600x300" width="100%" alt="">
            </bl-column>
            <bl-column :cols="[{nom: 8, den: 12}, {nom: 1, den: 1, mod: 's'}]" class="u-spacer">
              <bl-h type="h2" class="h2">Wat weet de overheid over mij</bl-h>
              <bl-typography>
                <p>Een volledig overzicht van alle gegevens die de overheid over jou weet samengebracht op één plaats. Zijn de gegevens niet correct? Dan kan je dat makkelijk melden. Bovendien kan je ook zien welke overheidsdiensten jouw gegevens hebben opgevraagd en waarvoor ze die gegevens hebben gebruikt.</p>
              </bl-typography>
            </bl-column>
            <bl-column :cols="[{nom: 8, den: 12}, {nom: 1, den: 1, mod: 's'}]" class="u-spacer">
              <bl-h type="h2" class="h2">Lopende zaken</bl-h>
              <bl-typography>
                <p>Heb je aanvraag voor bijvoorbeeld een premie of studietoelage ingediend bij de overheid? Dan kan je via jouw persoonlijke pagina de status van de aanvraag opvolgen. Zo weet je precies hoe het staat met jouw aanvraag en wie jouw dossierbeheerder is.</p>
              </bl-typography>
            </bl-column>
            <bl-column :cols="[{nom: 4, den: 12}, {nom: 1, den: 1, mod: 's'}]" class="u-spacer">
              <img src="https://placehold.it/600x300" width="100%" alt="">
            </bl-column>
            <bl-column :cols="[{nom: 4, den: 12}, {nom: 1, den: 1, mod: 's'}]" class="u-spacer">
              <img src="https://placehold.it/600x300" width="100%" alt="">
            </bl-column>
            <bl-column :cols="[{nom: 8, den: 12}, {nom: 1, den: 1, mod: 's'}]">
              <bl-h type="h2" class="h2">Meldingen</bl-h>
              <bl-typography>
                <p>Meldingen houden je pro-actief op de hoogte van zaken die van belang voor u zijn. Is bijvoorbeeld de status van uw aanvraag gewijzigd, dan krijgt u hiervan een melding. Deze meldingen ontvang je hier, maar als je wil, kan dat ook per e-mail of SMS. Dat beheer je gemakkelijk in jouw voorkeuren op jouw persoonlijke pagina.</p>
              </bl-typography>
            </bl-column>
          </bl-grid>
        </bl-layout>
      </bl-region>
      <bl-column>
        <div class="u-align-center" style="background: #e8ebee">
          <br>
          <br>
          <br>
          <i class="vi vi-id" aria-hidden style="font-size: 8rem; color: #cbd2da"></i>
          <br>
          <bl-h type="h3" class="h3">Mijn gegevens bij de overheid</bl-h>
          <a href="#" @click.prevent="$store.dispatch('session/login', '/login')" class="button">Aanmelden</a>
          <br>
          <br>
          <br>
          <br>
        </div>
      </bl-column>
    </bl-main>
  </div>
</template>

<script>

import BlContentHeader from '~components/partials/content-header/ContentHeader.vue'

export default {
  components: {
    BlContentHeader
  },
  data () {
    return {
      pageTitle: 'Vlaanderen.be'
    }
  }
}
</script>
