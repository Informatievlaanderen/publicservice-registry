'use strict'

import axios from 'axios'

/*
|--------------------------------------------------------------------------
| [Module] Education Service Vuex Store
|--------------------------------------------------------------------------
|
| Defines the Education Service related state, getters and actions.
*/

export const state = {
  testCases: null,
  testCasesFailed: false,

  events: null,
  eventsTimeline: null,
  eventsReference: null,
  eventsFailed: false,

  dashboardStatus: null,
  dashboardStatusFailed: false
}

export const getters = {

  /**
   * Get a list of test cases.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object[]}
   *   An array of objects which represents the different
   *   test case groups.
   */
  testCases (state) {
    return state.testCases || []
  },

  /**
   * Get the number test cases available.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Number}
   *   Number of test cases.
   */
  testCasesCount (state, getters) {
    return getters.testCases.length
  },

  /**
   * Get an indication whether test cases have been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if resolved, otherwise false.
   */
  testCasesResolved (state, getters) {
    return getters.testCasesFailed === false && state.testCases !== null
  },

  /**
   * Get an indication whether test cases failed to resolve.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if failed, otherwise false.
   */
  testCasesFailed (state) {
    return state.testCasesFailed
  },

  /**
   * Get a list of education events.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object[]}
   *   An array of objects which represents the different
   *   education events.
   */
  events (state) {
    return state.events || []
  },

  /**
   * Get the number education events available.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Number}
   *   Number of test cases.
   */
  eventsCount (state, getters) {
    return getters.events.length
  },

  /**
   * Get a list of education events timeline items.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object[]}
   *   An array of object which represent the timeline items.
   */
  eventsTimeline (state) {
    return state.eventsTimeline || []
  },

  /**
   * Get the number of education event timeline items.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Number}
   *   Number of timeline items.
   */
  eventsTimelineCount (state, getters) {
    return getters.eventsTimeline.length
  },

  /**
   * Get the education events reference (LED).
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object|null}
   *   An object which contains the following properties if available, otherwise null:
   *   <ul>
   *     <li>url: Url to the application</li>
   *     <li>method: Method which should be used for navigation to the application</li>
   *     <li>params: An object which contains the key/value pairs that should be enclosed in the navigation</li>
   *   </ul>
   */
  eventsReference (state) {
    return state.eventsReference
  },

  /**
   * Get an indication whether the events have been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if resolved, otherwise false.
   */
  eventsResolved (state, getters) {
    return getters.eventsFailed === false && state.events !== null
  },

  /**
   * Get an indication whether the events failed to resolve.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Boolean}
   *   True if failed, otherwise false.
   */
  eventsFailed (state) {
    return state.eventsFailed
  },

  /**
   * Get the dashboard status.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object}
   *   An object which represents the dashboard status.
   */
  dashboardStatus (state) {
    return state.dashboardStatus || null
  },

  /**
   * Get an indication whether dashboard status have been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if resolved, otherwise false.
   */
  dashboardStatusResolved (state, getters) {
    return getters.dashboardStatusFailed === false && getters.dashboardStatus !== null
  },

  /**
   * Get an indication whether the dashboard status failed to resolve.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Boolean}
   *   True if failed, otherwise false.
   */
  dashboardStatusFailed (state) {
    return state.dashboardStatusFailed
  }

}

export const mutations = {

  /**
   * Mutate Vuex Store to a success state for test cases.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object[]} testCases
   *   An array of test case groups.
   */
  test_cases_success (state, testCases) {
    // Update the test cases state.
    state.testCases = testCases
    // Clear the failed state.
    state.testCasesFailed = false
  },

  /**
   * Mutate Vuex Store to a failed state for test cases.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  test_cases_failure (state) {
    // Set the failed flag.
    state.testCasesFailed = true
    // Update the test cases state.
    state.testCases = null
  },

  /**
   * Mutate Vuex Store to a success state for education events.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} educationEvents
   *   An object which represents the education events.
   * @param {Object[]} educationEvents.items
   *   A list of education events.
   * @param {Object[]} educationEvents.timeline
   *   A list of education  event timeline items.
   * @param {Object} educationEvents.reference
   *   An object which describes the events application reference.
   */
  events_success (state, educationEvents) {
    // Update the education events related states.
    state.events = educationEvents.events || []
    state.eventsTimeline = educationEvents.timeline || []
    state.eventsReference = educationEvents.reference || null
    // Clear the failed state.
    state.eventsFailed = false
  },

  /**
   * Mutate Vuex Store to a failed state for education events.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  events_failure (state) {
    // Set the failed state.
    state.eventsFailed = true
    // Update the education events related states.
    state.events = null
    state.eventsTimeline = null
    state.eventsReference = null
  },

  /**
   * Mutate Vuex Store to a success state for dashboard status.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} dashboardStatus
   *   An object which represents the dashboard status.
   * @param {Boolean} dashboardStatus.status
   *   Flag which indicates whether information is available.
   * @param {Object} dashboardStatus.meta
   *   An object which holds flags specific to the dashboard.
   * @param {Boolean} dashboardStatus.meta.integration
   *   Flag which indicates whether integration data is available.
   */
  dashboard_status_success (state, dashboardStatus) {
    // Update the dashboard status.
    state.dashboardStatus = dashboardStatus
    // Clear the failed state.
    state.dashboardStatusFailed = false
  },

  /**
   * Mutate Vuex Store to a failed state for dashboard status.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  dashboard_status_failure (state) {
    // Set the failed state.
    state.dashboardStatusFailed = true
    // Update the dashboard status.
    state.dashboardStatus = null
  },

  /**
   * Mutate Vuex Store to an initial state.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  reset (state) {
    // Reset the test case related state:
    state.testCases = null
    state.testCasesFailed = false

    // Reset the education events related state:
    state.events = null
    state.eventsTimeline = null
    state.eventsReference = null
    state.eventsFailed = false

    // Reset the dashboard status related state:
    state.dashboardStatus = null
    state.dashboardStatusFailed = false
  }

}

export const actions = {

  /**
   * {@inheritdoc}
   */
  * nuxtServerInit ({ commit }, { req }) {
    // Create a EducationService instance.
    const service = req.app.make('App/Service/EducationService')
    // Get the cached test cases.
    const testCases = yield service.getTestCases().setCacheMode(2).exec()
    // Check whether the data could be resolved from cache.
    if (testCases !== null) {
      // Commit the test cases to store to prevent additional request overhead.
      commit('education/test_cases_success', testCases)
    }

    // Get the current user.
    const user = yield req.auth.getUser()
    // Check whether an authenticated user session is available.
    if (user !== null) {
      // Get the dashboard status from cache only.
      const dashboardStatus = yield service.getDashboardStatus(user.token).setCacheMode(2).exec()
      // Check whether the data could be resolved from cache.
      if (dashboardStatus !== null) {
        // Commit dashboard status to store to prevent additional request overhead.
        commit('education/dashboard_success', dashboardStatus)
      }

      // Get the education events from cache only.
      const educationEvents = yield service.getEvents(user.token).setCacheMode(2).exec()
      // Check whether the data could be resolved from cache.
      if (educationEvents !== null) {
        // Commit the education events to store to prevent additional request overhead.
        commit('education/events_success', educationEvents)
        // Check whether the dashboard status was not resolved using dashboard status service
        // cache.
        if (dashboardStatus !== null) {
          // Commit the dashboard status to store to prevent additional request overhead.
          commit('education/dashboard_status_success', educationEvents.dashboardStatus)
        }
      }
    }
  },

  /**
   * Action for resolving the test cases.
   *
   * @param {Object} context
   *   An object which represents the local context.
   *
   * @returns {Promise}
   *   A Promise to resolve the test cases.
   */
  testCases (context) {
    // Create a promise to resolve the test cases.
    return new Promise((resolve, reject) => {
      // Check whether test cases have been resolved or failed.
      if (context.getters.testCasesResolved || context.getters.testCasesFailed) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/education/testCases')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit the Vuex Store to a success state.
              context.commit('test_cases_success', res.data.result)
            } else {
              // Commit the Vuex Store to a failure state.
              context.commit('test_cases_failure', res.data.result)
            }
            // Resolve the promise.
            resolve()
          })
          .catch((error) => {
            // Commit the Vuex Store to a failure state.
            context.commit('test_cases_failure', error.message)
            // Resolve the promise.
            resolve()
          })
      }
    })
  },

  /**
   * Action for resolving the education events.
   *
   * @param {Object} context
   *   An object which represents the local context.
   *
   * @returns {Promise}
   *   A Promise to resolve the education events.
   */
  events (context) {
    // Create a promise to resolve the Certificate files.
    return new Promise((resolve, reject) => {
      // Check whether education events have been resolved or failed.
      if (context.getters.eventsResolved || context.getters.eventsFailed) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/education/events')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit the Vuex Store to a success state.
              context.commit('events_success', res.data.result)
              // Commit the Vuex Store to a success state.
              context.commit('dashboard_status_success', res.data.result.dashboardStatus)
            } else {
              // Commit the Vuex Store to a failure state.
              context.commit('events_failure', res.data.result)
            }
            // Resolve the promise.
            resolve()
          })
          .catch((error) => {
            // Commit the Vuex Store to a failure state.
            context.commit('events_failure', error.message)
            // Resolve the promise as a state has been reached.
            resolve()
          })
      }
    })
  },

  /**
   * Action for resolving the dashboard status.
   *
   * @param {Object} context
   *   An object which represents the local context.
   *
   * @returns {Promise}
   *   A Promise to resolve the dashboard status.
   */
  dashboardStatus (context) {
    // Create a promise to reset the local Vuex Store.
    return new Promise((resolve, reject) => {
      // Check whether dashboard status has been resolved or failed.
      if (context.getters.dashboardStatusResolved || context.getters.dashboardStatusFailed) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/education/dashboardStatus')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit the Vuex Store to a success state.
              context.commit('dashboard_status_success', res.data.result)
            } else {
              // Commit the Vuex Store to a failure state.
              context.commit('dashboard_status_failure', res.data.result)
            }
            // Resolve the promise.
            resolve()
          })
          .catch((error) => {
            // Commit the Vuex Store to a failure state.
            context.commit('dashboard_status_failure', error.message)
            // Resolve the promise as a state has been reached.
            resolve()
          })
      }
    })
  },

  /**
   * Action which resets the local Vuex Store.
   *
   * @param {Object} context
   *   An object which represents the local context.
   */
  reset (context) {
    // Create a promise to reset the local Vuex Store.
    return new Promise((resolve, reject) => {
      // Commit initial state to Vuex Store.
      context.commit('reset')
      // Resolve the promise.
      resolve()
    })
  }

}
