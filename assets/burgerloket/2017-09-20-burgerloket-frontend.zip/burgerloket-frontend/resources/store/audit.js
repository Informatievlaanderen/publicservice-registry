'use strict'

import axios from 'axios'

/*
|--------------------------------------------------------------------------
| [Module] Audit Vuex Store
|--------------------------------------------------------------------------
|
| Defines the Audit related state, getters and actions.
*/

export const state = {
  testCases: null,
  testCasesFailed: false,

  extractions: null,
  extractionsFailed: false,

  dashboardStatus: null,
  dashboardStatusFailed: false
}

export const getters = {
  /**
   * Get a list of test cases.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object[]}
   *   An array of objects which represents the different
   *   test case groups.
   */
  testCases (state) {
    return state.testCases || []
  },

  /**
   * Get the number test cases available.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Number}
   *   Number of test cases.
   */
  testCasesCount (state, getters) {
    return getters.testCases.length
  },

  /**
   * Get an indication whether test cases have been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if resolved, otherwise false.
   */
  testCasesResolved (state, getters) {
    return getters.testCasesFailed === false && state.testCases !== null
  },

  /**
   * Get an indication whether test cases failed to resolve.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if failed, otherwise false.
   */
  testCasesFailed (state) {
    return state.testCasesFailed
  },

  /**
   * Get a list of audit data extractions.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object[]}
   *   An array of objects which represents the different
   *   audit data extractions.
   */
  extractions (state) {
    return state.extractions || []
  },

  /**
   * Get an indication whether the audit data extractions have been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if resolved, otherwise false.
   */
  extractionsResolved (state, getters) {
    return getters.extractionsFailed === false && state.extractions !== null
  },

  /**
   * Get an indication whether the audit data extractions failed to resolve.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Boolean}
   *   True if failed, otherwise false.
   */
  extractionsFailed (state) {
    return state.extractionsFailed
  },

  /**
   * Get the dashboard status.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object}
   *   An object which represents the dashboard status.
   */
  dashboardStatus (state) {
    return state.dashboardStatus || null
  },

  /**
   * Get an indication whether dashboard status have been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if resolved, otherwise false.
   */
  dashboardStatusResolved (state, getters) {
    return getters.dashboardStatusFailed === false && getters.dashboardStatus !== null
  },

  /**
   * Get an indication whether the dashboard status failed to resolve.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Boolean}
   *   True if failed, otherwise false.
   */
  dashboardStatusFailed (state) {
    return state.dashboardStatusFailed
  }

}

export const mutations = {
  /**
   * Mutate Vuex Store to a success state for test cases.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object[]} testCases
   *   An array of test case groups.
   */
  test_cases_success (state, testCases) {
    // Update the test cases state.
    state.testCases = testCases
    // Clear the failed state.
    state.testCasesFailed = false
  },

  /**
   * Mutate Vuex Store to a failed state for test cases.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  test_cases_failure (state) {
    // Set the failed flag.
    state.testCasesFailed = true
    // Update the test cases state.
    state.testCases = null
  },

  /**
   * Mutate Vuex Store to a success state for audit extraction data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object[]} extractions
   *   An array of audit extraction objects.
   */
  extractions_success (state, extractions) {
    // Update the extractions.
    state.extractions = extractions
    // Clear the failed state.
    state.extractionsFailed = false
  },

  /**
   * Mutate Vuex Store to a failed state for audit extraction data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  extractions_failure (state) {
    // Set the failed flag.
    state.extractionsFailed = true
    // Update the extractions.
    state.extractions = null
  },

  /**
   * Mutate Vuex Store to a success state for dashboard status.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} dashboardStatus
   *   An object which represents the dashboard status.
   * @param {Boolean} dashboardStatus.status
   *   Flag which indicates whether information is available.
   */
  dashboard_status_success (state, dashboardStatus) {
    // Update the dashboard status.
    state.dashboardStatus = dashboardStatus
    // Clear the failed state.
    state.dashboardStatusFailed = false
  },

  /**
   * Mutate Vuex Store to a failed state for dashboard status.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  dashboard_status_failure (state) {
    // Set the failed state.
    state.dashboardStatusFailed = true
    // Update the dashboard status.
    state.dashboardStatus = null
  },

  /**
   * Mutate Vuex Store to an initial state.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  reset (state) {
    state.extractions = null
    state.extractionsFailed = false

    // Reset the dashboard status related state:
    state.dashboardStatus = null
    state.dashboardStatusFailed = false
  }

}

export const actions = {

  /**
   * {@inheritdoc}
   */
  * nuxtServerInit ({ commit }, { req }) {
    // Get the current user.
    const user = yield req.auth.getUser()
    // Check whether an authenticated user session is available.
    if (user !== null) {
      // Create a AuditService instance.
      const service = req.app.make('App/Service/AuditService')

      // Get the dashboard status from cache only.
      const dashboardStatus = yield service.getDashboardStatus(user.token).setCacheMode(2).exec()
      // Check whether the data could be resolved from cache.
      if (dashboardStatus !== null) {
        // Commit dashboard status to store to prevent additional request overhead.
        commit('audit/dashboard_success', dashboardStatus)
      }

      // Get the cached test cases.
      const testCases = yield service.getTestCases().setCacheMode(2).exec()
      // Check whether the data could be resolved from cache.
      if (testCases !== null) {
        // Commit the test cases to store to prevent additional request overhead.
        commit('audit/test_cases_success', testCases)
      }

      // Get the audit extractions from cache only.
      const extractions = yield service.getAuditData(user.token).setCacheMode(2).exec()
      // Check whether the data could be resolved from cache.
      if (extractions !== null) {
        // Commit the audit extractions to store to prevent additional request overhead.
        commit('audit/extractions_success', extractions)
      }
    }
  },

  /**
   * Action for resolving the test cases.
   */
  testCases ({ getters, commit }) {
    // Create a promise to resolve the test cases.
    return new Promise((resolve, reject) => {
      // Check whether test cases have been resolved or failed.
      if (getters.testCasesResolved || getters.testCasesFailed) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/audit/testCases')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit the Vuex Store to a success state.
              commit('test_cases_success', res.data.result)
            } else {
              // Commit the Vuex Store to a failure state.
              commit('test_cases_failure', res.data.result)
            }
            // Resolve the promise.
            resolve()
          })
          .catch((error) => {
            // Commit the Vuex Store to a failure state.
            commit('test_cases_failure', error.message)
            // Resolve the promise.
            resolve()
          })
      }
    })
  },

  /**
   * Action for resolving the audit extractions.
   */
  extractions ({ getters, commit }) {
    // Create a promise to resolve the extractions.
    return new Promise((resolve, reject) => {
      // Check whether files have been resolved or failed.
      if (getters.extractionsResolved) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/audit/extractions')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit to Vuex Store as a success state.
              commit('extractions_success', res.data.result)
            } else {
              // Commit to Vuex Store as failure state.
              commit('extractions_failure', res.data.result)
            }
          })
          .then(() => { resolve() })
          .catch((error) => {
            // Commit to Vuex Store as a failure state.
            commit('extractions_failure', error.message)
            // Resolve the promise as a state has been reached.
            resolve()
          })
      }
    })
  },

  /**
   * Action for resolving the dashboard status.
   *
   * @param {Object} context
   *   An object which represents the local context.
   *
   * @returns {Promise}
   *   A Promise to resolve the dashboard status.
   */
  dashboardStatus (context) {
    // Create a promise to reset the local Vuex Store.
    return new Promise((resolve, reject) => {
      // Check whether dashboard status has been resolved or failed.
      if (context.getters.dashboardStatusResolved || context.getters.dashboardStatusFailed) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/audit/dashboardStatus')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit the Vuex Store to a success state.
              context.commit('dashboard_status_success', res.data.result)
            } else {
              // Commit the Vuex Store to a failure state.
              context.commit('dashboard_status_failure', res.data.result)
            }
            // Resolve the promise.
            resolve()
          })
          .catch((error) => {
            // Commit the Vuex Store to a failure state.
            context.commit('dashboard_status_failure', error.message)
            // Resolve the promise as a state has been reached.
            resolve()
          })
      }
    })
  },

  /**
   * Action which resets the local Vuex Store.
   */
  reset ({ commit }) {
    // Create a promise to reset the local Vuex Store.
    return new Promise((resolve, reject) => {
      // Commit initial state to Vuex Store.
      commit('reset')
      // Resolve the promise.
      resolve()
    })
  }

}
