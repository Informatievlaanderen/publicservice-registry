'use strict'

import axios from 'axios'

/*
|--------------------------------------------------------------------------
| [Module] Dosis Vuex Store
|--------------------------------------------------------------------------
|
| Defines the Dosis related state, getters and actions.
*/

export const state = {
  notifications: null,
  notificationsUnreadCount: null,
  notificationsFailed: false
}

export const getters = {

  /**
   * Get a list of notifications.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object[]}
   *   An array of objects which represents the different
   *   education events.
   */
  notifications (state) {
    return state.notifications || []
  },

  /**
   * Get the number notifications available.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Number}
   *   Number of notifications
   */
  notificationsCount (state, getters) {
    return getters.notifications.length
  },

  /**
   * Get the number of unread notifications.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Number}
   *   Number of notifications.
   */
  notificationsUnreadCount (state, getters) {
    // Check whether the notifications unread count needs to be resolved.
    if (state.notificationsUnreadCount === null) {
      // Initialize variable to zero as default behavior.
      state.notificationsUnreadCount = 0
      // Iterate through the notifications.
      getters.notifications.forEach((notification) => {
        // Check whether the notification is unread.
        if (notification.isRead === false) {
          // Increment the counter by one.
          state.notificationsUnreadCount++
        }
      })
    }

    return state.notificationsUnreadCount
  },

  /**
   * Get an indication whether the notifications have been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if resolved, otherwise false.
   */
  notificationsResolved (state, getters) {
    return getters.notificationsFailed === false && state.notifications !== null
  },

  /**
   * Get an indication whether the notifications failed to resolve.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Boolean}
   *   True if failed, otherwise false.
   */
  notificationsFailed (state) {
    return state.notificationsFailed
  }

}

export const mutations = {

  /**
   * Mutate Vuex Store to a success state for notifications.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object[]} notifications
   *   An array of notification objects.
   */
  notifications_success (state, notifications) {
    // Update the notifications.
    state.notifications = notifications
    state.notificationsUnreadCount = null
    // Clear the failed state.
    state.notificationsFailed = false
  },

  /**
   * Mutate Vuex Store to a failed state for notifications.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  notifications_failure (state) {
    // Set the failed flag.
    state.notificationsFailed = true
    // Update the notifications.
    state.notifications = null
    state.notificationsUnreadCount = null
  },

  /**
   * Mutate Vuex Store to a state where a notification with given ID
   * is marked as read.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  notification_mark_as_read (state, id) {
    // Get the notification from state.
    const notifications = state.notifications
    // Check whether notifications is available.
    if (notifications !== null) {
      // Iterate through the notifications.
      for (var i = 0; i < notifications.length; i++) {
        // Get the notification as specified index.
        var notification = notifications[i]
        // Check whether the notification matches the given ID.
        if (notification.id === id) {
          // Mark the notification as read.
          notification.isRead = true
        }
      }
    }
    // Reset the notification unread counter.
    state.notificationsUnreadCount = null
  },

  /**
   * Mutate Vuex Store to an initial state.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  reset (state) {
    state.notifications = null
    state.notificationsUnreadCount = null
    state.notificationsFailed = false
  }

}

export const actions = {

  /**
   * {@inheritdoc}
   */
  * nuxtServerInit ({ commit }, { req }) {
    // Get the current user.
    const user = yield req.auth.getUser()
    // Check whether an authenticated user session is available.
    if (user !== null) {
      // Create a NotificationService instance.
      const service = req.app.make('App/Service/NotificationService')
      // Get the notifications from cache only.
      const notifications = yield service.getNotifications(user.token).setCacheMode(2).exec()
      // Check whether the data could be resolved from cache.
      if (notifications !== null) {
        // Commit the notifications to store to prevent additional request overhead.
        commit('notification/notifications_success', notifications)
      }
    }
  },

  /**
   * Action for resolving the notifications.
   */
  notifications (context) {
    // Create a promise to resolve the notifications.
    return new Promise((resolve, reject) => {
      // Check whether files have been resolved or failed.
      if (context.getters.notificationsResolved || context.getters.notificationsFailed) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/notification/list')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit to Vuex Store as a success state.
              context.commit('notifications_success', res.data.result)
            } else {
              // Commit to Vuex Store as failure state.
              context.commit('notifications_failure', res.data.result)
            }
          })
          .then(() => { resolve() })
          .catch((error) => {
            // Commit to Vuex Store as a failure state.
            context.commit('notifications_failure', error.message)
            // Resolve the promise as a state has been reached.
            resolve()
          })
      }
    })
  },

  /**
   * Action for marking notifications as read.
   */
  markNotificationAsRead (context, notification) {
    // Create a promise to mark notifications as read.
    return new Promise((resolve, reject) => {
      // Check whether notification is unread.
      if (notification.isRead === false) {
        // Invoke the service backend to replicate the changes.
        axios
          .post('/api/v1/notification/markAsRead', {
            id: notification.id
          })
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success && res.data.result) {
              // Commit the changes to the notification.
              context.commit('notification_mark_as_read', notification.id)
              // Resolve as the operation was successful.
              resolve(notification)
            } else {
              // Reject due to failure in updating the notification status.
              reject(new Error('Unable to update notification status'))
            }
          })
          .catch((error) => {
            // Reject the operation due to an error.
            reject(error)
          })
      } else {
        // Resolve as notification is already marked as read.
        resolve(notification)
      }
    })
  },

  /**
   * Action which resets the local Vuex Store.
   *
   * @param {Object} context
   *   An object which represents the local context.
   */
  reset (context) {
    // Create a promise to reset the local Vuex Store.
    return new Promise((resolve, reject) => {
      // Commit initial state to Vuex Store.
      context.commit('reset')
      // Resolve the promise.
      resolve()
    })
  }

}
