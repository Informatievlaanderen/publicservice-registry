'use strict'

import axios from 'axios'
const router = require('~router')

/*
|--------------------------------------------------------------------------
| [Module] Session Vuex Store
|--------------------------------------------------------------------------
|
| Defines the session related state, getters, mutations and actions.
*/

export const state = {
  user: null,
  profile: null,
  profileFailed: false
}

export const getters = {

  /**
   * Determine whether current session is authenticated.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @return {Boolean}
   *   True if current session is authenticated, otherwise false.
   */
  authenticated (state) {
    return state.user !== null
  },

  /**
   * Determine whether current session has administrator priviledges.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @return {Boolean}
   *   True if current session has administrator priviledges,
   *   otherwise false.
   */
  isAdmin (state, getters) {
    // Check whether the user is authenticated.
    if (getters.authenticated) {
      // Determine whether admin flag is set.
      return !!getters.user.isAdmin
    }

    return false
  },

  /**
   * Get the user information.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @return {Object|null}
   *   An object which contains the following properties:
   *   <ul>
   *     <li>firstName: First name of the user.</li>
   *     <li>lastName: Last name of the user.</li>
   *     <li>token: A unique identifier</li>
   *   </ul>
   */
  user (state) {
    return state.user
  },

  /**
   * Get the profile information.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @return {Object|null}
   *   An object which contains the following properties:
   *   <ul>
   *     <li>street</li>
   *     <li>streetNumber</li>
   *     <li>streetBus</li>
   *     <li>postalCode</li>
   *     <li>city</li>
   *     <li>avatar</li>
   *   </ul>
   */
  profile (state) {
    return state.profile || null
  },

  /**
   * Indicates whether profile has been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @return {Boolean}
   *   True if profile has been resolved, otherwise false.
   */
  profileResolved (state, getters) {
    return getters.profileFailed === false && getters.profile !== null
  },

  /**
   * Get an indication whether a failure occurred.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Boolean}
   *   True if a failure occurred, otherwise false.
   */
  profileFailed (state, getters) {
    return state.profileFailed
  },

  /**
   * Get the full name.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {String}
   *   A string which contains the first and last name.
   */
  fullName (state, getters) {
    // Build the full name of the user.
    return (getters.firstName + ' ' + getters.lastName).trim()
  },

  /**
   * Get the first name.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {String}
   *   A string which contains the first name.
   */
  firstName (state, getters) {
    // Get the profile object.
    const profile = getters.profile || {}
    // Get the first name of the profile.
    return profile.firstName || ''
  },

  /**
   * Get the last name.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {String}
   *   A string which contains the last name.
   */
  lastName (state, getters) {
    // Get the profile object.
    const profile = getters.profile || {}
    // Get the last name of the profile.
    return profile.lastName || ''
  },

  /**
   * Get the nickname.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   */
  nickname (state, getters) {
    // Get the profile object.
    const profile = getters.profile || {}
    // Get the nickname of the profile.
    return profile.nickname || ''
  },

  /**
   * Get the avatar.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   */
  avatar (state, getters) {
    // @todo Avatar data not available yet
    return ''
  },

  /**
   * Get the city.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   */
  city (state, getters) {
    // @todo City data not available yet
    return ''
  }
}

export const mutations = {

  /**
   * Update the user information state.
   *
   * Note: setting this informtion will not change the user
   * information on the server. Use the Session Login REST API
   * to perform the login flow for another user.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object|null} user
   *   An object which contains the user information. the
   *   following properties should be present:
   *   <ul>
   *     <li>firstName: First name of the user.</li>
   *     <li>lastName: Last name of the user.</li>
   *     <li>avatar: String which contains a data URI.</li>
   *   </ul>
   *   Use null to clear the user information.
   */
  user (state, user) {
    // Update the user information.
    state.user = user || null
  },

  /**
   * Mutate Vuex Store to a success state.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} profile
   *   An object which contains the profile data.
   */
  profile_success (state, profile) {
    // Update the files state.
    state.profile = profile
    // Clear the failed state.
    state.profileFailed = false
  },

  /**
   * Mutate Vuex Store to a failed state.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  profile_failure (state) {
    // Set the failed state.
    state.profileFailed = true
    // Update the files state.
    state.profile = null
  },

  /**
   * Mutate Vuex Store to an initial state.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  reset (state) {
    // We do not include the "user" state as this is controlled
    // by the actions.
    state.profile = null
    state.profileFailed = false
  }

}

export const actions = {

  /**
   * {@inheritdoc}
   */
  * nuxtServerInit ({ commit }, { req }) {
    // Get the current user object if available.
    const user = yield req.auth.getUser()

    // Check whether an authenticated user session is available.
    if (user !== null) {
      // Assign the admin flag to the user object.
      user.isAdmin = yield req.auth.isAdmin()
      // Create a ProfileService instance.
      const service = req.app.make('App/Service/ProfileService')
      // Get the profile from cache only.
      const profile = yield service.getProfile(user.token).setCacheMode(2).exec()
      // Check whether the data could be resolved from cache.
      if (profile !== null) {
        // Commit the profile to store to prevent additional request overhead.
        commit('session/profile_success', profile)
      }
    }

    // Setup initial store baseline for session related states.
    commit('session/user', user)
  },

  /**
   * Start the login process.
   *
   * @param {Object} context
   *   An object which contains the store context.
   * @param {String} redirectPath
   *   Path to which we should be redirect once login
   *   process is completed.
   */
  login (context, redirectPath) {
    return axios
      .post('/api/v1/session/login', { redirectPath })
      .then((res) => {
        // Evaluate the response type.
        switch (res.data.type) {
          // Server instructs the client to redirect to an external
          // URL.
          case 'externalRedirect':
            // Redirect the browser directly as Vue Router
            // does not provide support for this and will
            // generate a 404 page.
            window.location.href = res.data.redirectUrl
            break

          default:
            // Update the user information.
            context.commit('user', res.data.user)
            // Prefetch the profile information.
            context.dispatch('profile')
            // Check whether a redirect path was provided.
            if (res.data.redirectUrl) {
              // Redirect to given URL.
              router.default.push(res.data.redirectUrl)
            }
            break
        }
      })
  },

  /**
   * Logout the current user session.
   *
   * @param {Object} context
   *   An object which contains the store context.
   */
  logout (context) {
    // Create a promise to logout the current user session.
    return new Promise((resolve, reject) => {
      /**
       * Resolve user session logout response.
       *
       * @param {Response} response
       *   An instance of Response.
       */
      function resolveLogoutResponse (response) {
        // Commit the resolved user information.
        context.commit('user', response.data.user || null)
        // Check whether the current user session has been terminated.
        if (context.getters.authenticated === false) {
          // Trigger reset behavior.
          context.dispatch('reset')
          // Reload the current current route to triggeer route
          // middleware.
          router.default.go(router.default.currentRoute)
        }
        // Resolve the promise.
        resolve()
      }

      // Send signal to the Backend API that user session should
      // be terminated.
      axios
        .post('/api/v1/session/logout')
        .then(resolveLogoutResponse)
        .catch(() => { resolve() })
    })
  },

  /**
   * Action for resolving the user profile.
   *
   * @param {Object} context
   *   An object which represents the local context.
   *
   * @returns {Promise}
   *   A Promise to resolve the user profile.
   */
  profile (context) {
    // Create a promise to resolve the user profile.
    return new Promise((resolve, reject) => {
      // Check whether profile have been resolved or failed.
      if (context.getters.profileResolved || context.getters.profileFailed) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/profile')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit to Vuex Store as a success state.
              context.commit('profile_success', res.data.result)
            } else {
              // Commit to Vuex Store as failure state.
              context.commit('profile_failure', res.data.result)
            }
          })
          .then(() => { resolve() })
          .catch((error) => {
            // Commit to Vuex Store as a failure state.
            context.commit('profile_failure', error.message)
            // Resolve the promise as a state has been reached.
            resolve()
          })
      }
    })
  },

  /**
   * Action for updating the user profile.
   *
   * @param {Object} context
   *   An object which represents the local context.
   * @param {Object} profile
   *   An object which represents the profile.
   *
   * @returns {Promise}
   *   A Promise to resolve updating the user profile.
   */
  updateProfile (context, profile) {
    // Create a promise to resolve updating the user profile.
    return new Promise((resolve, reject) => {
      // Post the profile to the service API.
      axios
        .post('/api/v1/profile', profile)
        .then((res) => {
          // Check whether the updates were successful.
          if (res.data.success) {
            // Commit to Vuex Store as a success state.
            context.commit('profile_success', res.data.result)
            // Resolve as operation was successful.
            resolve(profile)
          } else {
            // Reject due to failure in saving changes to profile.
            reject(new Error('Unable to save changes to the profile'))
          }
        })
        .catch((error) => {
          // Reject due to specified error.
          reject(error)
        })
    })
  },

  /**
   * Action for deleting the user profile.
   *
   * @param {Object} context
   *   An object which represents the local context.
   *
   * @returns {Promise}
   *   A Promise to resolve deleting the user profile.
   */
  deleteProfile (context) {
    // Create a promise to resolve updating the user profile.
    return new Promise((resolve, reject) => {
      // Remove the profile using the service API.
      axios
        .delete('/api/v1/profile')
        .then((res) => {
          // Check whether the removal was successful.
          if (res.data.success) {
            // Reset the proflie.
            context.commit('profile_success', null)
            // Resolve as operation was successful.
            resolve()
          } else {
            // Reject due to failure in removing the profile.
            reject(new Error('Unable to delete the profile'))
          }
        })
        .catch((error) => {
          // Reject due to specified error.
          reject(error)
        })
    })
  },

  /**
   * Action which resets the local Vuex Store.
   *
   * @param {Object} context
   *   An object which represents the local context.
   */
  reset (context) {
    // Create a promise to reset the local Vuex Store.
    return new Promise((resolve, reject) => {
      // Commit initial state to Vuex Store.
      context.commit('reset')
      // Reset the Vuex Stores which contains user sensitive information
      // that should no longer be exposed due to terminated user session.
      context.commit('dosis/reset', null, { root: true })
      context.commit('education/reset', null, { root: true })
      // Resolve the promise.
      resolve()
    })
  }

}
