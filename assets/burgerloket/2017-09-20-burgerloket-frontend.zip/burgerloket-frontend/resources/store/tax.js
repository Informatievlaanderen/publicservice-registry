'use strict'

import axios from 'axios'

/*
|--------------------------------------------------------------------------
| [Module] Tax/Benefits Vuex Store
|--------------------------------------------------------------------------
|
| Defines the Tax/Benefits related state, getters and actions.
*/

export const state = {
  testCases: null,
  testCasesFailed: false,

  assistance: null,
  assistanceFailed: false,

  careerBreaks: null,
  careerBreaksFailed: null
}

export const getters = {
  /**
   * Get a list of test cases.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object[]}
   *   An array of objects which represents the different
   *   test case groups.
   */
  testCases (state) {
    return state.testCases || []
  },

  /**
   * Get the number test cases available.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Number}
   *   Number of test cases.
   */
  testCasesCount (state, getters) {
    return getters.testCases.length
  },

  /**
   * Get an indication whether test cases have been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if resolved, otherwise false.
   */
  testCasesResolved (state, getters) {
    return getters.testCasesFailed === false && state.testCases !== null
  },

  /**
   * Get an indication whether test cases failed to resolve.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if failed, otherwise false.
   */
  testCasesFailed (state) {
    return state.testCasesFailed
  },

  /**
   * Get the assistance data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object}
   *   An object which represents the assistance data.
   */
  assistance (state) {
    return state.assistance
  },

  /**
   * Get an indication whether the assistance data has been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if resolved, otherwise false.
   */
  assistanceResolved (state, getters) {
    return getters.assistanceFailed === false && state.assistance !== null
  },

  /**
   * Get an indication whether the assistance data failed to resolve.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Boolean}
   *   True if failed, otherwise false.
   */
  assistanceFailed (state) {
    return state.assistanceFailed
  },

  /**
   * Get the career breaks data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object}
   *   An object which represents the career breaks data.
   */
  careerBreaks (state) {
    return state.careerBreaks
  },

  /**
   * Get an indication whether the career breaks data has been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if resolved, otherwise false.
   */
  careerBreaksResolved (state, getters) {
    return getters.careerBreaksFailed === false && state.careerBreaks !== null
  },

  /**
   * Get an indication whether the career breaks data failed to resolve.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Boolean}
   *   True if failed, otherwise false.
   */
  careerBreaksFailed (state) {
    return state.careerBreaksFailed
  }

}

export const mutations = {
  /**
   * Mutate Vuex Store to a success state for test cases.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object[]} testCases
   *   An array of test case groups.
   */
  test_cases_success (state, testCases) {
    // Update the test cases state.
    state.testCases = testCases
    // Clear the failed state.
    state.testCasesFailed = false
  },

  /**
   * Mutate Vuex Store to a failed state for test cases.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  test_cases_failure (state) {
    // Set the failed flag.
    state.testCasesFailed = true
    // Update the test cases state.
    state.testCases = null
  },

  /**
   * Mutate Vuex Store to a success state for assistance data
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} assistance
   *   The assistance object.
   */
  assistance_success (state, assistance) {
    // Update the assistance.
    state.assistance = assistance
    // Clear the failed state.
    state.assistanceFailed = false
  },

  /**
   * Mutate Vuex Store to a failed state for assistance data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  assistance_failure (state) {
    // Set the failed flag.
    state.assistanceFailed = true
    // Update the assistance.
    state.assistance = null
  },

  /**
   * Mutate Vuex Store to a success state for career breaks data
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} career breaks
   *   The career breaks object.
   */
  career_breaks_success (state, careerBreaks) {
    // Update the career breaks.
    state.careerBreaks = careerBreaks
    // Clear the failed state.
    state.careerBreaksFailed = false
  },

  /**
   * Mutate Vuex Store to a failed state for career breaks data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  career_breaks_failure (state) {
    // Set the failed flag.
    state.careerBreaksFailed = true
    // Update the career breaks.
    state.careerBreaks = null
  },

  /**
   * Mutate Vuex Store to an initial state.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  reset (state) {
    state.assistance = null
    state.assistanceFailed = false
    state.careerBreaks = null
    state.careerBreaksFailed = false
  }

}

export const actions = {

  /**
   * {@inheritdoc}
   */
  * nuxtServerInit ({ commit }, { req }) {
    // Get the current user.
    const user = yield req.auth.getUser()
    // Check whether an authenticated user session is available.
    if (user !== null) {
      const service = req.app.make('App/Service/TaxService')

      // Get the cached test cases.
      const testCases = yield service.getTestCases().setCacheMode(2).exec()
      // Check whether the data could be resolved from cache.
      if (testCases !== null) {
        // Commit the test cases to store to prevent additional request overhead.
        commit('tax/test_cases_success', testCases)
      }

      // Get the assistance from cache only.
      const assistance = yield service.getAssistance(user.token).setCacheMode(2).exec()
      // Check whether the data could be resolved from cache.
      if (assistance !== null) {
        // Commit the assistance to store to prevent additional request overhead.
        commit('tax/assistance_success', assistance)
      }

      // Get the career breaks from cache only.
      const careerBreaks = yield service.getCareerBreaks(user.token).setCacheMode(2).exec()
      // Check whether the data could be resolved from cache.
      if (careerBreaks !== null) {
        // Commit the career breaks to store to prevent additional request overhead.
        commit('tax/career_breaks_success', careerBreaks)
      }
    }
  },

  /**
   * Action for resolving the test cases.
   */
  testCases ({ getters, commit }) {
    // Create a promise to resolve the test cases.
    return new Promise((resolve, reject) => {
      // Check whether test cases have been resolved or failed.
      if (getters.testCasesResolved || getters.testCasesFailed) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/tax/testCases')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit the Vuex Store to a success state.
              commit('test_cases_success', res.data.result)
            } else {
              // Commit the Vuex Store to a failure state.
              commit('test_cases_failure', res.data.result)
            }
            // Resolve the promise.
            resolve()
          })
          .catch((error) => {
            // Commit the Vuex Store to a failure state.
            commit('test_cases_failure', error.message)
            // Resolve the promise.
            resolve()
          })
      }
    })
  },

  /**
   * Action for resolving the assistance.
   */
  assistance ({ getters, commit }) {
    // Create a promise to resolve the assistance.
    return new Promise((resolve, reject) => {
      // Check whether assistance has been resolved or failed.
      if (getters.assistanceResolved) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/tax/assistance')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit to Vuex Store as a success state.
              commit('assistance_success', res.data.result)
            } else {
              // Commit to Vuex Store as failure state.
              commit('assistance_failure', res.data.result)
            }
          })
          .then(() => { resolve() })
          .catch((error) => {
            // Commit to Vuex Store as a failure state.
            commit('assistance_failure', error.message)
            // Resolve the promise as a state has been reached.
            resolve()
          })
      }
    })
  },

  /**
   * Action for resolving the career breaks.
   */
  careerBreaks ({ getters, commit }) {
    // Create a promise to resolve the career breaks.
    return new Promise((resolve, reject) => {
      // Check whether career breaks data has been resolved or failed.
      if (getters.careerBreaksResolved) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/tax/careerBreaks')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit to Vuex Store as a success state.
              commit('career_breaks_success', res.data.result)
            } else {
              // Commit to Vuex Store as failure state.
              commit('career_breaks_failure', res.data.result)
            }
          })
          .then(() => { resolve() })
          .catch((error) => {
            // Commit to Vuex Store as a failure state.
            commit('career_breaks_failure', error.message)
            // Resolve the promise as a state has been reached.
            resolve()
          })
      }
    })
  },

  /**
   * Action which resets the local Vuex Store.
   */
  reset ({ commit }) {
    // Create a promise to reset the local Vuex Store.
    return new Promise((resolve, reject) => {
      // Commit initial state to Vuex Store.
      commit('reset')
      // Resolve the promise.
      resolve()
    })
  }

}
