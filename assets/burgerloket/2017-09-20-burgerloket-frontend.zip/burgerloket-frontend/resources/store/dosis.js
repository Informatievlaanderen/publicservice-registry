'use strict'

import axios from 'axios'

/*
|--------------------------------------------------------------------------
| [Module] Dosis Vuex Store
|--------------------------------------------------------------------------
|
| Defines the Dosis related state, getters and actions.
*/

export const state = {
  filesFailed: false,
  files: null,
  filesTimeline: null
}

export const getters = {

  /**
   * Get a list of files.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object[]}
   *   An array of object which represent the different files.
   */
  files (state) {
    return state.files || []
  },

  /**
   * Get the number of files.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Number}
   *   Number of files.
   */
  filesCount (state, getters) {
    return getters.files.length
  },

  /**
   * Get a list of files converted into a timeline.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object[]}
   *   An array of objects which represent the timeline items.
   */
  filesTimeline (state) {
    return state.filesTimeline || []
  },

  /**
   * Get the number of timeline items.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   */
  filesTimelineCount (state, getters) {
    return getters.filesTimeline.length
  },

  /**
   * Indicates whether files have been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @return {Boolean}
   *   True if files have been resolved, otherwise false.
   */
  filesResolved (state, getters) {
    return getters.filesFailed === false && state.files !== null
  },

  /**
   * Get an indication whether a failure occurred.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Boolean}
   *   True if a failure occurred, otherwise false.
   */
  filesFailed (state) {
    return state.filesFailed
  }

}

export const mutations = {

  /**
   * Mutate Vuex Store to a success state.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} obj
   *   An object which contains the files and timeline.
   */
  files_success (state, obj) {
    // Update the files state.
    state.files = obj.files || []
    state.filesTimeline = obj.timeline || []
    // Clear the failed state.
    state.filesFailed = false
  },

  /**
   * Mutate Vuex Store to a failed state.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  files_failure (state) {
    // Set the failed state.
    state.filesFailed = true
    // Update the files state.
    state.files = null
    state.filesTimeline = null
  },

  /**
   * Mutate Vuex Store to an initial state.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  reset (state) {
    state.files = null
    state.filesTimeline = null
    state.filesFailed = false
  }

}

export const actions = {

  /**
   * {@inheritdoc}
   */
  * nuxtServerInit ({ commit }, { req }) {
    // Get the current user.
    // const user = yield req.auth.getUser()
    // @todo For some strange reason the above line is causing
    //       problems.
    // Create a DosisService instance.
    // const test = req.app.make('App/Service/DosisService')
    // Get the Dosis files from cache only.
    // const files = yield test.getFiles('80123199830', 'nl').setCacheMode(2).exec()
    // Check whether the data could be resolved from cache.
    // if (files !== null) {
      // Commit the dosis files to store to prevent additional request overhead.
      // commit('dosis/files_success', files)
    // }
  },

  /**
   * Action for resolving the Dosis files.
   *
   * @param {Object} context
   *   An object which represents the local context.
   *
   * @returns {Promise}
   *   A Promise to resolve the Dosis files.
   */
  files (context) {
    // Create a promise to resolve the Dosis files.
    return new Promise((resolve, reject) => {
      // Check whether files have been resolved or failed.
      if (context.getters.filesResolved || context.getters.filesFailed) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/dosis/files')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit to Vuex Store as a success state.
              context.commit('files_success', res.data.result)
            } else {
              // Commit to Vuex Store as failure state.
              context.commit('files_failure', res.data.result)
            }
          })
          .then(() => { resolve() })
          .catch((error) => {
            // Commit to Vuex Store as a failure state.
            context.commit('files_failure', error.message)
            // Resolve the promise as a state has been reached.
            resolve()
          })
      }
    })
  },

  /**
   * Action which resets the local Vuex Store.
   *
   * @param {Object} context
   *   An object which represents the local context.
   */
  reset (context) {
    // Create a promise to reset the local Vuex Store.
    return new Promise((resolve, reject) => {
      // Commit initial state to Vuex Store.
      context.commit('reset')
      // Resolve the promise.
      resolve()
    })
  }

}
