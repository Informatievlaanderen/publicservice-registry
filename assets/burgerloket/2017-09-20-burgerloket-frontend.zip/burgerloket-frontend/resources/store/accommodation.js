'use strict'

import axios from 'axios'

/*
|--------------------------------------------------------------------------
| [Module] Accommodation Vuex Store
|--------------------------------------------------------------------------
|
| Defines the Accommodation related state, getters and actions.
*/

export const state = {
  testCases: null,
  testCasesFailed: false,

  residence: null,
  residenceFailed: false,

  property: null,
  propertyFailed: false
}

export const getters = {
  /**
   * Get a list of test cases.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object[]}
   *   An array of objects which represents the different
   *   test case groups.
   */
  testCases (state) {
    return state.testCases || []
  },

  /**
   * Get the number test cases available.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Number}
   *   Number of test cases.
   */
  testCasesCount (state, getters) {
    return getters.testCases.length
  },

  /**
   * Get an indication whether test cases have been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if resolved, otherwise false.
   */
  testCasesResolved (state, getters) {
    return getters.testCasesFailed === false && state.testCases !== null
  },

  /**
   * Get an indication whether test cases failed to resolve.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if failed, otherwise false.
   */
  testCasesFailed (state) {
    return state.testCasesFailed
  },

  /**
   * Get the residence data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object}
   *   An object which represents the residence data.
   */
  residence (state) {
    return state.residence
  },

  /**
   * Get an indication whether the residence data has been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if resolved, otherwise false.
   */
  residenceResolved (state, getters) {
    return getters.residenceFailed === false && state.residence !== null
  },

  /**
   * Get an indication whether the residence data failed to resolve.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Boolean}
   *   True if failed, otherwise false.
   */
  residenceFailed (state) {
    return state.residenceFailed
  },

  /**
   * Get the property data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object}
   *   An object which represents the property data.
   */
  property (state) {
    return state.property
  },

  /**
   * Get an indication whether the property data has been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if resolved, otherwise false.
   */
  propertyResolved (state, getters) {
    return getters.propertyFailed === false && state.property !== null
  },

  /**
   * Get an indication whether the property data failed to resolve.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Boolean}
   *   True if failed, otherwise false.
   */
  propertyFailed (state) {
    return state.propertyFailed
  }

}

export const mutations = {
  /**
   * Mutate Vuex Store to a success state for test cases.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object[]} testCases
   *   An array of test case groups.
   */
  test_cases_success (state, testCases) {
    // Update the test cases state.
    state.testCases = testCases
    // Clear the failed state.
    state.testCasesFailed = false
  },

  /**
   * Mutate Vuex Store to a failed state for test cases.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  test_cases_failure (state) {
    // Set the failed flag.
    state.testCasesFailed = true
    // Update the test cases state.
    state.testCases = null
  },

  /**
   * Mutate Vuex Store to a success state for residence data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} residence
   *   The residence object.
   */
  residence_success (state, residence) {
    // Update the residence.
    state.residence = residence
    // Clear the failed state.
    state.residenceFailed = false
  },

  /**
   * Mutate Vuex Store to a failed state for residence data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  residence_failure (state) {
    // Set the failed flag.
    state.residenceFailed = true
    // Update the residence.
    state.residence = null
  },

  /**
   * Mutate Vuex Store to a success state for property data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} property
   *   The property object.
   */
  property_success (state, property) {
    // Update the property.
    state.property = property
    // Clear the failed state.
    state.propertyFailed = false
  },

  /**
   * Mutate Vuex Store to a failed state for property data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  property_failure (state) {
    // Set the failed flag.
    state.propertyFailed = true
    // Update the property.
    state.property = null
  },

  /**
   * Mutate Vuex Store to an initial state.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  reset (state) {
    state.residence = null
    state.residenceFailed = false
    state.property = null
    state.propertyFailed = false
  }

}

export const actions = {

  /**
   * {@inheritdoc}
   */
  * nuxtServerInit ({ commit }, { req }) {
    // Get the current user.
    const user = yield req.auth.getUser()
    // Check whether an authenticated user session is available.
    if (user !== null) {
      const service = req.app.make('App/Service/AccommodationService')

      // Get the cached test cases.
      const testCases = yield service.getTestCases().setCacheMode(2).exec()
      // Check whether the data could be resolved from cache.
      if (testCases !== null) {
        // Commit the test cases to store to prevent additional request overhead.
        commit('accommodation/test_cases_success', testCases)
      }

      // Get the residence from cache only.
      const residence = yield service.getResidence(user.token).setCacheMode(2).exec()
      // Check whether the data could be resolved from cache.
      if (residence !== null) {
        // Commit the residence to store to prevent additional request overhead.
        commit('accommodation/residence_success', residence)
      }

      // Get the property from cache only.
      const property = yield service.getProperty(user.token).setCacheMode(2).exec()
      // Check whether the data could be resolved from cache.
      if (property !== null) {
        // Commit the property to store to prevent additional request overhead.
        commit('accommodation/property_success', property)
      }
    }
  },

  /**
   * Action for resolving the test cases.
   */
  testCases ({ getters, commit }) {
    // Create a promise to resolve the test cases.
    return new Promise((resolve, reject) => {
      // Check whether test cases have been resolved or failed.
      if (getters.testCasesResolved || getters.testCasesFailed) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/accommodation/testCases')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit the Vuex Store to a success state.
              commit('test_cases_success', res.data.result)
            } else {
              // Commit the Vuex Store to a failure state.
              commit('test_cases_failure', res.data.result)
            }
            // Resolve the promise.
            resolve()
          })
          .catch((error) => {
            // Commit the Vuex Store to a failure state.
            commit('test_cases_failure', error.message)
            // Resolve the promise.
            resolve()
          })
      }
    })
  },

  /**
   * Action for resolving the residence.
   */
  residence ({ getters, commit }) {
    // Create a promise to resolve the residence.
    return new Promise((resolve, reject) => {
      // Check whether residence has been resolved or failed.
      if (getters.residenceResolved) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/accommodation/residence')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit to Vuex Store as a success state.
              commit('residence_success', res.data.result)
            } else {
              // Commit to Vuex Store as failure state.
              commit('residence_failure', res.data.result)
            }
          })
          .then(() => { resolve() })
          .catch((error) => {
            // Commit to Vuex Store as a failure state.
            commit('residence_failure', error.message)
            // Resolve the promise as a state has been reached.
            resolve()
          })
      }
    })
  },

  /**
   * Action for resolving the property.
   */
  property ({ getters, commit }) {
    // Create a promise to resolve the property.
    return new Promise((resolve, reject) => {
      // Check whether property has been resolved or failed.
      if (getters.propertyResolved) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/accommodation/property')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit to Vuex Store as a success state.
              commit('property_success', res.data.result)
            } else {
              // Commit to Vuex Store as failure state.
              commit('property_failure', res.data.result)
            }
          })
          .then(() => { resolve() })
          .catch((error) => {
            // Commit to Vuex Store as a failure state.
            commit('property_failure', error.message)
            // Resolve the promise as a state has been reached.
            resolve()
          })
      }
    })
  },

  /**
   * Action which resets the local Vuex Store.
   */
  reset ({ commit }) {
    // Create a promise to reset the local Vuex Store.
    return new Promise((resolve, reject) => {
      // Commit initial state to Vuex Store.
      commit('reset')
      // Resolve the promise.
      resolve()
    })
  }

}
