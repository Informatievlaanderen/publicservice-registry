'use strict'

const co = require('co')

/*
|--------------------------------------------------------------------------
| Default Vuex Store
|--------------------------------------------------------------------------
|
| This file contains empty state, getters, mutations and actions. They
| should be left like this. Additional implementation should be implemented
| as a module by creating a new Javascript file in store directory. The
| name of the file is the module name.
|
| As Nuxt will only call the index.js "nuxtServerInit" this implementation
| provides the required bootstrap code for delegating the call to each
| module. Keep in mind that implementing module should use the generator
| function syntax.
*/

export const state = {/* LEAVE EMPTY */}

export const getters = {/* LEAVE EMPTY */}

export const mutations = {/* LEAVE EMPTY */}

export const actions = {

  /**
   * {@inheritdoc}
   */
  nuxtServerInit () {
    // Get the current function scope and arguments. This will be used
    // to bootstrap the module specific "nuxtServerInit" functions.
    const fnScope = this
    const fnArgs = arguments
    // Wrap our generator function as a promise. This allows us to follow
    // the Adonis generator function approach without the conversion
    // overhead.
    return co(function *() {
      // Get a list of all the Vuex Store modules.
      const files = require.context('~/store', false, /^\.\/.*\.js$/)
      // Get a list of filenames which matched our contextual require
      // statement.
      const filenames = files.keys()
      // Iterate through the filenames.
      for (let filename of filenames) {
        // Exclude the index.js module as this is only used to glue everything
        // toghether.
        if (filename.replace(/^\.\//, '').replace(/\.js$/, '') !== 'index') {
          // Load the file content.
          let file = files(filename)
          // Check whether the module supports "nuxtServerInit" function.
          if (file.actions && file.actions.nuxtServerInit) {
            // Execute the "nuxtServerInit" module specific function and yield
            // execution.
            yield file.actions.nuxtServerInit.apply(fnScope, fnArgs)
          }
        }
      }
    })
  }

}
