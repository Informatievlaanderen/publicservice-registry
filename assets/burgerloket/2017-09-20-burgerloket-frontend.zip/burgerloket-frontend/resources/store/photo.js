'use strict'

import axios from 'axios'

/*
|--------------------------------------------------------------------------
| [Module] Photo Vuex Store
|--------------------------------------------------------------------------
|
| Defines the photo related state, getters, mutations and actions.
*/

export const state = {
  passport: null,
  passportFailed: false,
  profile: null,
  profileFailed: false
}

export const getters = {
  /**
   * Get the passport photo data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @return {Object|null}
   */
  passport (state) {
    return state.passport
  },

  /**
   * Indicates whether passport photo has been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @return {Boolean}
   *   True if profile has been resolved, otherwise false.
   */
  passportResolved (state, getters) {
    return getters.passportFailed === false && getters.passport !== null
  },

  /**
   * Get an indication whether a failure occurred.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Boolean}
   *   True if a failure occurred, otherwise false.
   */
  passportFailed (state, getters) {
    return state.passportFailed
  },

  /**
   * Get the profile photo data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @return {Object|null}
   *   An object which contains the following properties:
   */
  profile (state) {
    return state.profile
  },

  /**
   * Indicates whether profile photo has been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @return {Boolean}
   *   True if profile has been resolved, otherwise false.
   */
  profileResolved (state, getters) {
    return getters.profileFailed === false && getters.profile !== null
  },

  /**
   * Get an indication whether a failure occurred.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Boolean}
   *   True if a failure occurred, otherwise false.
   */
  profileFailed (state, getters) {
    return state.profileFailed
  }
}

export const mutations = {

  /**
   * Mutate Vuex Store to a success state.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} photo
   *   An object which contains the passport photo data.
   */
  passport_success (state, photo) {
    // Clear the failed state.
    state.passportFailed = false

    if (photo) {
      // Update passport state to base64 encoded data url
      state.passport = makeDataUrl(photo)
    } else {
      // Explicitly set passport state to false to indicate no photo exists
      state.passport = false
    }
  },

  /**
   * Mutate Vuex Store to a failed state.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  passport_failure (state) {
    // Set the failed state.
    state.passportFailed = true
    // Update the files state.
    state.passport = null
  },

  /**
   * Mutate Vuex Store to a success state.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} photo
   *   An object which contains the passport photo data.
   */
  profile_success (state, photo) {
    // Clear the failed state.
    state.passportFailed = false

    if (photo) {
      // Update profile state to base64 encoded data url
      state.profile = makeDataUrl(photo)
    } else {
      // Explicitly set passport state to false to indicate no photo exists
      state.profile = false
    }
  },

  /**
   * Mutate Vuex Store to a failed state.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  profile_failure (state) {
    // Set the failed state.
    state.profileFailed = true
    // Update the files state.
    state.profile = null
  },

  /**
   * Mutate Vuex Store to an initial state.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  reset (state) {
    state.passport = null
    state.passportFailed = false
    state.profile = null
    state.profileFailed = false
  }

}

export const actions = {

  /**
   * Action for resolving the user passport photo.
   *
   * @param {Object} context
   *   An object which represents the local context.
   *
   * @returns {Promise}
   *   A Promise to resolve the user passport photo.
   */
  passport (context) {
    // Create a promise to resolve the user passport photo.
    return new Promise((resolve, reject) => {
      // Check whether passport photo has been resolved or failed.
      if (context.getters.passportResolved || context.getters.passportFailed) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/photo/passport')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit to Vuex Store as a success state.
              context.commit('passport_success', res.data.result)
            } else {
              // Commit to Vuex Store as failure state.
              context.commit('passport_failure', res.data.result)
            }
          })
          .then(() => { resolve() })
          .catch((error) => {
            // Commit to Vuex Store as a failure state.
            context.commit('passport_failure', error.message)
            // Resolve the promise as a state has been reached.
            resolve()
          })
      }
    })
  },

  /**
   * Action for resolving the user profile photo.
   *
   * @param {Object} context
   *   An object which represents the local context.
   *
   * @returns {Promise}
   *   A Promise to resolve the user profile photo.
   */
  profile (context) {
    // Create a promise to resolve the user profile photo.
    return new Promise((resolve, reject) => {
      // Check whether profile photo has been resolved or failed.
      if (context.getters.profileResolved || context.getters.profileFailed) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/photo/profile')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit to Vuex Store as a success state.
              context.commit('profile_success', res.data.result)
            } else {
              // Commit to Vuex Store as failure state.
              context.commit('profile_failure', res.data.result)
            }
          })
          .then(() => { resolve() })
          .catch((error) => {
            // Commit to Vuex Store as a failure state.
            context.commit('profile_failure', error.message)
            // Resolve the promise as a state has been reached.
            resolve()
          })
      }
    })
  },

  /**
   * Action for updating the user profile photo.
   *
   * @param {Object} context
   *   An object which represents the local context.
   * @param {String} content
   *   A base64 encoded image string
   *
   * @returns {Promise}
   *   A Promise that resolves when the user profile photo is updated.
   */
  setProfile (context, content) {
    content = stripDataUrlMeta(content)
    return context.dispatch('updateProfile', { content })
  },

  /**
   * Action for updating the user profile photo to his/her passport photo.
   *
   * @param {Object} context
   *   An object which represents the local context.
   *
   * @returns {Promise}
   *   A Promise that resolves when the user profile photo is updated.
   */
  usePassportAsProfile (context) {
    return context.dispatch('updateProfile', { reference: 'passport' })
  },

  /**
   * Action for updating the user profile photo and refreshing store.
   *
   * @param {Object} context
   *   An object which represents the local context.
   * @param {Object} resource
   *   An object containing either content or reference property
   * @param {String} resource.content
   *   A base64 encoded image string
   * @param {String} resource.reference
   *   A reference to existing images (currently always 'passport')
   *
   * @returns {Promise}
   *   A Promise that resolves when the user profile photo is updated.
   */
  updateProfile (context, { content, reference }) {
    // Create a promise to resolve updating the user profile photo.
    return new Promise((resolve, reject) => {
      // Put the photo to the API.
      axios
        .put('/api/v1/photo/profile', { content, reference })
        .then((res) => {
          // Check whether the updates were successful.
          if (res.data.success) {
            // Commit to Vuex Store as a success state.
            context.commit('profile_success', res.data.result)
          } else {
            // Reject due to failure in saving changes to photo.
            reject(new Error('Unable to save changes to the profile photo'))
          }
        })
        .catch((error) => {
          // Reject due to specified error.
          reject(error)
        })
    })
  },

  /**
   * Action for removing the user profile photo and refreshing store.
   *
   * @param {Object} context
   *   An object which represents the local context.
   *
   * @returns {Promise}
   *   A Promise that resolves when the user profile photo is removed.
   */
  unsetProfile (context) {
    // Create a promise to resolve updating the user profile photo.
    return new Promise((resolve, reject) => {
      // Put the photo to the API.
      axios
        .delete('/api/v1/photo/profile')
        .then((res) => {
          // Check whether the updates were successful.
          if (res.data.success) {
            context.commit('profile_success', false)
          } else {
            // Reject due to failure in saving changes to photo.
            reject(new Error('Unable to remove the profile photo'))
          }
        })
        .catch((error) => {
          // Reject due to specified error.
          reject(error)
        })
    })
  },

  /**
   * Action which resets the local Vuex Store.
   *
   * @param {Object} context
   *   An object which represents the local context.
   */
  reset (context) {
    // Create a promise to reset the local Vuex Store.
    return new Promise((resolve, reject) => {
      // Commit initial state to Vuex Store.
      context.commit('reset')
      // Resolve the promise.
      resolve()
    })
  }

}

function makeDataUrl (photo) {
  if (!photo) return ''

  const contentType = photo.contentType || ''
  const content = photo.content

  return `data:${contentType};base64,${content}`
}

function stripDataUrlMeta (url) {
  if (!url) return ''
  return url.split(';base64,')[1] || ''
}
