'use strict'

import axios from 'axios'

/*
|--------------------------------------------------------------------------
| [Module] Person Vuex Store
|--------------------------------------------------------------------------
|
| Defines the Person related state, getters and actions.
*/

export const state = {
  testCases: null,
  testCasesFailed: false,

  particulars: null,
  particularsFailed: false,

  descent: null,
  descentFailed: false,

  family: null,
  familyFailed: false
}

export const getters = {
  /**
   * Get a list of test cases.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object[]}
   *   An array of objects which represents the different
   *   test case groups.
   */
  testCases (state) {
    return state.testCases || []
  },

  /**
   * Get the number test cases available.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Number}
   *   Number of test cases.
   */
  testCasesCount (state, getters) {
    return getters.testCases.length
  },

  /**
   * Get an indication whether test cases have been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if resolved, otherwise false.
   */
  testCasesResolved (state, getters) {
    return getters.testCasesFailed === false && state.testCases !== null
  },

  /**
   * Get an indication whether test cases failed to resolve.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if failed, otherwise false.
   */
  testCasesFailed (state) {
    return state.testCasesFailed
  },

  /**
   * Get an object containing current user's particulars.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object}
   *   An object which represents the particulars of current user.
   */
  particulars (state) {
    return state.particulars
  },

  /**
   * Get an indication whether the current user's particulars have been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if resolved, otherwise false.
   */
  particularsResolved (state, getters) {
    return getters.particularsFailed === false && state.particulars !== null
  },

  /**
   * Get an indication whether the current user's particulars failed to resolve.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Boolean}
   *   True if failed, otherwise false.
   */
  particularsFailed (state) {
    return state.particularsFailed
  },

  /**
   * Get an object containing current user's descent data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object}
   *   An object which represents the descent data of current user.
   */
  descent (state) {
    return state.descent
  },

  /**
   * Get an indication whether the current user's descent data has been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if resolved, otherwise false.
   */
  descentResolved (state, getters) {
    return getters.descentFailed === false && state.descent !== null
  },

  /**
   * Get an indication whether the current user's descent data failed to resolve.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Boolean}
   *   True if failed, otherwise false.
   */
  descentFailed (state) {
    return state.descentFailed
  },

  /**
   * Get an object containing current user's family data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Object}
   *   An object which represents the family data of current user.
   */
  family (state) {
    return state.family
  },

  /**
   * Get an indication whether the current user's family data has been resolved.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} getters
   *   Local module getters.
   *
   * @returns {Boolean}
   *   True if resolved, otherwise false.
   */
  familyResolved (state, getters) {
    return getters.familyFailed === false && state.family !== null
  },

  /**
   * Get an indication whether the current user's family data failed to resolve.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   *
   * @returns {Boolean}
   *   True if failed, otherwise false.
   */
  familyFailed (state) {
    return state.familyFailed
  }

}

export const mutations = {
  /**
   * Mutate Vuex Store to a success state for test cases.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object[]} testCases
   *   An array of test case groups.
   */
  test_cases_success (state, testCases) {
    // Update the test cases state.
    state.testCases = testCases
    // Clear the failed state.
    state.testCasesFailed = false
  },

  /**
   * Mutate Vuex Store to a failed state for test cases.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  test_cases_failure (state) {
    // Set the failed flag.
    state.testCasesFailed = true
    // Update the test cases state.
    state.testCases = null
  },

  /**
   * Mutate Vuex Store to a success state for particulars data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} particulars
   *   A particulars object.
   */
  particulars_success (state, particulars) {
    // Update the particulars.
    state.particulars = particulars
    // Clear the failed state.
    state.particularsFailed = false
  },

  /**
   * Mutate Vuex Store to a failed state for particulars data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  particulars_failure (state) {
    // Set the failed flag.
    state.particularsFailed = true
    // Update the particulars.
    state.particulars = null
  },

  /**
   * Mutate Vuex Store to a success state for descent data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} descent
   *   A descent object.
   */
  descent_success (state, descent) {
    // Update the descent data.
    state.descent = descent
    // Clear the failed state.
    state.descentFailed = false
  },

  /**
   * Mutate Vuex Store to a failed state for descent data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  descent_failure (state) {
    // Set the failed flag.
    state.descentFailed = true
    // Update the descent data.
    state.descent = null
  },

  /**
   * Mutate Vuex Store to a success state for family data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   * @param {Object} family
   *   A family object.
   */
  family_success (state, family) {
    // Update the family data.
    state.family = family
    // Clear the failed state.
    state.familyFailed = false
  },

  /**
   * Mutate Vuex Store to a failed state for family data.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  family_failure (state) {
    // Set the failed flag.
    state.familyFailed = true
    // Update the family data.
    state.family = null
  },

  /**
   * Mutate Vuex Store to an initial state.
   *
   * @param {Object} state
   *   An object which represents the local module state.
   */
  reset (state) {
    state.particulars = null
    state.particularsFailed = false
    state.descent = null
    state.descentFailed = false
    state.family = null
    state.familyFailed = false
  }

}

export const actions = {

  /**
   * {@inheritdoc}
   */
  * nuxtServerInit ({ commit }, { req }) {
    // Get the current user.
    const user = yield req.auth.getUser()
    // Check whether an authenticated user session is available.
    if (user !== null) {
      // Create a PersonService instance.
      const service = req.app.make('App/Service/PersonService')

      // Get the cached test cases.
      const testCases = yield service.getTestCases().setCacheMode(2).exec()
      // Check whether the data could be resolved from cache.
      if (testCases !== null) {
        // Commit the test cases to store to prevent additional request overhead.
        commit('person/test_cases_success', testCases)
      }

      // Get the person particulars from cache only.
      const particulars = yield service.getParticulars(user.token).setCacheMode(2).exec()
      // Check whether the data could be resolved from cache.
      if (particulars !== null) {
        // Commit the person particulars to store to prevent additional request overhead.
        commit('person/particulars_success', particulars)
      }

      // Get the person descent from cache only.
      const descent = yield service.getDescent(user.token).setCacheMode(2).exec()
      // Check whether the data could be resolved from cache.
      if (descent !== null) {
        // Commit the person descent to store to prevent additional request overhead.
        commit('person/descent_success', descent)
      }

      // Get the person family from cache only.
      const family = yield service.getFamily(user.token).setCacheMode(2).exec()
      // Check whether the data could be resolved from cache.
      if (family !== null) {
        // Commit the person family to store to prevent additional request overhead.
        commit('person/family_success', family)
      }
    }
  },

  /**
   * Action for resolving the test cases.
   */
  testCases ({ getters, commit }) {
    // Create a promise to resolve the test cases.
    return new Promise((resolve, reject) => {
      // Check whether test cases have been resolved or failed.
      if (getters.testCasesResolved || getters.testCasesFailed) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/person/testCases')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit the Vuex Store to a success state.
              commit('test_cases_success', res.data.result)
            } else {
              // Commit the Vuex Store to a failure state.
              commit('test_cases_failure', res.data.result)
            }
            // Resolve the promise.
            resolve()
          })
          .catch((error) => {
            // Commit the Vuex Store to a failure state.
            commit('test_cases_failure', error.message)
            // Resolve the promise.
            resolve()
          })
      }
    })
  },

  /**
   * Action for resolving the person particulars.
   */
  particulars ({ getters, commit }) {
    // Create a promise to resolve the particulars.
    return new Promise((resolve, reject) => {
      // Check whether files have been resolved or failed.
      if (getters.particularsResolved) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/person/particulars')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit to Vuex Store as a success state.
              commit('particulars_success', res.data.result)
            } else {
              // Commit to Vuex Store as failure state.
              commit('particulars_failure', res.data.result)
            }
          })
          .then(() => { resolve() })
          .catch((error) => {
            // Commit to Vuex Store as a failure state.
            commit('particulars_failure', error.message)
            // Resolve the promise as a state has been reached.
            resolve()
          })
      }
    })
  },

  /**
   * Action for resolving the person descent.
   */
  descent ({ getters, commit }) {
    // Create a promise to resolve the descent.
    return new Promise((resolve, reject) => {
      // Check whether data has been resolved or failed.
      if (getters.descentResolved) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/person/descent')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit to Vuex Store as a success state.
              commit('descent_success', res.data.result)
            } else {
              // Commit to Vuex Store as failure state.
              commit('descent_failure', res.data.result)
            }
          })
          .then(() => { resolve() })
          .catch((error) => {
            // Commit to Vuex Store as a failure state.
            commit('descent_failure', error.message)
            // Resolve the promise as a state has been reached.
            resolve()
          })
      }
    })
  },

  /**
   * Action for resolving the person family.
   */
  family ({ getters, commit }) {
    // Create a promise to resolve the family.
    return new Promise((resolve, reject) => {
      // Check whether data has been resolved or failed.
      if (getters.familyResolved) {
        // Resolve the promise as no action is required.
        resolve()
      } else {
        // Resolve data using the Backend API.
        axios
          .get('/api/v1/person/family')
          .then((res) => {
            // Check whether the response is successful.
            if (res.data.success) {
              // Commit to Vuex Store as a success state.
              commit('family_success', res.data.result)
            } else {
              // Commit to Vuex Store as failure state.
              commit('family_failure', res.data.result)
            }
          })
          .then(() => { resolve() })
          .catch((error) => {
            // Commit to Vuex Store as a failure state.
            commit('family_failure', error.message)
            // Resolve the promise as a state has been reached.
            resolve()
          })
      }
    })
  },

  /**
   * Action which resets the local Vuex Store.
   */
  reset ({ commit }) {
    // Create a promise to reset the local Vuex Store.
    return new Promise((resolve, reject) => {
      // Commit initial state to Vuex Store.
      commit('reset')
      // Resolve the promise.
      resolve()
    })
  }

}
