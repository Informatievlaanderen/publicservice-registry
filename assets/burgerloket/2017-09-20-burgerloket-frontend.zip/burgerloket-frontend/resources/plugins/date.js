'use strict'

import Vue from 'vue'
import moment from 'moment'

// Possible granularities of dates
const YEAR = 'YEAR'
const MONTH = 'MONTH'
const DAY = 'DAY'
const TIME = 'TIME'

// @todo(adriaan): Move to config file or something
const config = {
  formats: {
    default: {
      [YEAR]: 'YYYY',
      [MONTH]: 'MM.YYYY',
      [DAY]: 'DD.MM.YYYY',
      [TIME]: 'DD.MM.YYYY [om] HH:mm',
      AT_TIME: ' [om] HH:mm'
    },
    long: {
      [YEAR]: 'YYYY',
      [MONTH]: 'MMMM YYYY',
      [DAY]: 'DD MMMM YYYY',
      [TIME]: 'DD MMMM YYYY'
    },
    short: {
      [MONTH]: 'D MMM',
      [DAY]: 'D MMM',
      [TIME]: 'D MMM'
    }
  }
}
config.moment = {
  months: 'januari_februari_maart_april_mei_juni_juli_augustus_september_oktober_november_december'.split('_'),
  monthsShort: 'jan_feb_maa_apr_mei_jun_jul_aug_sep_okt_nov_dec'.split('_'),
  weekdays: 'zondag_maandag_dinsdag_woensdag_donderdag_vrijdag_zaterdag'.split('_'),
  monthsParseExact: true,
  relativeTime: {
    future: 'in %s',
    past: '%s geleden',
    s: 'enkele seconden',
    m: 'een minuut',
    mm: '%d minuten',
    h: 'een uur',
    hh: '%d uren',
    d: 'een dag',
    dd: '%d dagen',
    M: 'een maand',
    MM: '%d maanden',
    y: 'een jaar',
    yy: '%d jaren'
  },
  calendar: {
    sameDay: '[vandaag]',
    nextDay: '[morgen]',
    lastDay: '[gisteren]',
    nextWeek: '[aanstaande] dddd',
    lastWeek: '[afgelopen] dddd',
    sameElse: config.formats.long[DAY]
  }
}

const formatters = {}

// Set up all formatters as defined in config object
Object.keys(config.formats).forEach(formatter => {
  const formats = config.formats[formatter]

  formatters[formatter] = ({ value, granularity }) => {
    const format = formats[granularity]
    if (!format) {
      return ''
    }
    return value.format(format)
  }
})

// Special formatter for relative time
formatters.relative = ({ value, granularity }) => {
  if (granularity === YEAR || granularity === MONTH) {
    return ''
  }

  const day = moment(value).startOf('day')
  const today = moment().startOf('day')
  const distanceInDays = Math.abs(day.diff(today, 'days'))
  const timeSuffix = (granularity === TIME) ? value.format(config.formats.default.AT_TIME) : ''

  /*
  if (distanceInDays === 0 && granularity === TIME) {
    return value.fromNow() // x minutes ago etc
  } else */
  if (distanceInDays <= 1) {
    return day.calendar() + timeSuffix // Today/yesterday/tomorrow [at x:y:z]
  } else {
    return value.format(config.formats.long[DAY]) + timeSuffix // Default format
  }
}

// @todo(adriaan): parseDate is duplicated from DateTimeDataMap; should be removed here
function parseDate (obj) {
  if (!obj) return null
  if (obj.value && obj.granularity) return obj

  // Date strings should be parsed according to API conventions.
  if (typeof obj === 'string') {
    if (/\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d/.test(obj)) {
      return { value: obj, granularity: TIME }
    } else if (/\d{4}-\d\d-\d\d/.test(obj)) {
      return { value: obj, granularity: DAY }
    } else if (/\d{4}-\d\d/.test(obj)) {
      return { value: obj, granularity: MONTH }
    } else if (/\d{4}/.test(obj)) {
      return { value: obj, granularity: YEAR }
    }

  // If obj is already a date, just assume datetime granularity.
  // If obj is a number, convert as if it's unix timestamp, assume datetime granularity.
  } else if (obj instanceof Date || typeof obj === 'number') {
    return { value: moment(obj).format(), granularity: TIME }
  }

  return null
}

/**
 * Stringify a date using the given preconfigured format.
 *
 * @param {object|string} date
 *   An instance of a date object (ideally as given by backend, ie with granularity).
 *   Can also be an ISO date string, a unix timestamp number or a javascript Date.
 * @param {string} format
 *   A key that defined which formatter function should be used on the date.
 *   The available formatter functions are preconfigured.
 */
function $date (date, format) {
  // Make sure we extract a value and granularity in case the date hasn't been formatted by backend yet
  let { value, granularity } = parseDate(date) || {}
  if (!value) return ''
  if (!granularity) granularity = TIME

  // Use preconfigured formatter functions to return formatted date
  const formatter = formatters[format] || formatters.default
  return formatter({ value: moment(value), granularity })
}

const plugin = {
  install (Vue, options) {
    Vue.prototype.$date = $date
  }
}

// Register the Date plugin (exposes $date function).
Vue.use(plugin)

// @todo(adriaan): Should be moved to i18n config
// Configure moment
moment.locale('nl-be', config.moment)

export { $date }
export default plugin
