/**
 * Standard components that are used throughout
 * the entire platform on every page and get loaded
 * on first project initialisation.
 */

// Import Vue instance.
import Vue from 'vue'

// Import the general components.
import BlMain from '~components/frame/main/Main.vue'
import BlRegion from '~components/frame/region/Region.vue'
import BlLayout from '~components/frame/layout/Layout.vue'
import BlGrid from '~components/frame/grid/Grid.vue'
import BlColumn from '~components/frame/column/Column.vue'
import BlH from '~components/typography/H.vue'
import BlTypography from '~components/typography/Typography.vue'
import BlButton from '~components/form-elements/button/Button.vue'
import SvgSprite from 'vue-svg-sprite'

// Define the components name.
const components = {
  BlMain,
  BlRegion,
  BlLayout,
  BlGrid,
  BlColumn,
  BlH,
  BlTypography,
  BlButton
}

Vue.use(SvgSprite, {
  url: '/svg/icons.svg'
})

// Iterate through them and add them to
// the global Vue scope.
Object.keys(components).forEach(key => {
  Vue.component(key, components[key])
})
