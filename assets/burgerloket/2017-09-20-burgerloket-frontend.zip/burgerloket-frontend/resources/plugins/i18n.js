
import Vue from 'vue'
import VueI18n from 'vue-i18n'

// Register the VueI18n plugin.
Vue.use(VueI18n)

// Export the VueI18n plugin instance.
export default new VueI18n({})
