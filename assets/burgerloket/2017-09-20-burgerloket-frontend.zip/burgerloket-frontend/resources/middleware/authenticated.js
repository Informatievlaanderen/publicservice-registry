'use strict'

/**
 * Middleware: Redirect an unauthenticated user session to the login page.
 *
 * Note: This middleware follows a different way of determining whether
 * the user session is authenticated on server vs client due to order in
 * which middleware and store are executed. (nuxtServerInit is called after
 * middleware)
 */
export default function (context) {
  // Create a promise to evaluate the authenticated state.
  return new Promise((resolve) => {
    /**
     * Resolve authenticated state.
     *
     * @param {Boolean} authenticated
     *   Flag which indicates whether current user session is authenticated.
     */
    function resolveAuthenticated (authenticated) {
      // Check whether user session is not authenticated.
      if (authenticated === false) {
        // Redirect browser to the login page.
        // @todo Provide a page for logout message!
        context.redirect('/')
      }
      // Resolve the promise so that next middleware can be invoked.
      resolve()
    }

    /**
     * Reject authenticated state.
     *
     * @param {Error} error
     *   An arror which describes the reason for rejection.
     */
    function rejectAuthenticated (/* error */) {
      // Invoke resolve authenticated but with an unauthenticated state.
      resolveAuthenticated(false)
    }

    // Check whether middleware is being executed server side.
    if (context.isServer) {
      // Require the "co" module. We place this here to prevent "co" from being
      // included in the client side bundle as we only is it on server side to
      // be able to convert generators into promises.
      require('co')(function * () { return yield context.req.auth.isAuthenticated() })
        .then(resolveAuthenticated)
        .catch(rejectAuthenticated)
    } else {
      // Use the session store to determine authenticated state.
      resolveAuthenticated(context.store.getters['session/authenticated'])
    }
  })
}
